ن<?php

echo '<pre>';

echo "PHP VERSION:\n";
echo phpversion();

echo "\n\nSAPI:\n";
echo php_sapi_name();

echo "\n\nPHP INI:\n";
echo php_ini_loaded_file();

echo "\n\nAdditional INI files:\n";
echo php_ini_scanned_files();

echo "\n\nmb_strlen:\n";

if (function_exists('mb_strlen')) {
    echo "ENABLED\n";
    echo "Test result: " . mb_strlen('درخواست تست', 'UTF-8') . "\n";
} else {
    echo "DISABLED\n";
}

echo "\n\nLoaded extensions:\n";
print_r(get_loaded_extensions());

echo '</pre>';
