<?php

require_once __DIR__ . "/auth/auth.php";


/*
 * خروج کامل از Session
 */

logout();


/*
 * بازگشت به صفحه ورود
 */

header("Location: /neal/login.php");

exit;

?>
