<?php

session_start();

session_destroy();

header("Location: /neal/login.php");

exit;

?>
