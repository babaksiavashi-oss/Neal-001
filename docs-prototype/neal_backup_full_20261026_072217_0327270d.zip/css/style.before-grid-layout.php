* {
    box-sizing: border-box;
}

body {
    margin: 0;
    direction: rtl;
    font-family: Tahoma, Arial, sans-serif;
    background: #f4f7fb;
    color: #333;
}

/* =========================
   Header
========================= */

.topbar {
    position: relative;
    top: auto;
    right: auto;
    left: auto;
    width: 100%;
    min-height: 125px;
    background: #0b1f3a;
    display: flex;
    align-items: center;
    padding: 10px 30px;
    color: white;
    z-index: 10;
}

.logo {
    width: 180px;
    height: auto;
    margin-left: 25px;
    object-fit: contain;
}

.title {
    font-size: 24px;
    font-weight: bold;
}

.title span {
    display: block;
    font-size: 13px;
    font-weight: normal;
    opacity: .8;
    margin-top: 5px;
}

.user-menu {
    margin-right: auto;
    padding-left: 20px;
    font-size: 14px;
    color: white;
}

.user-menu a {
    color: white;
    text-decoration: none;
    margin-right: 10px;
    padding: 7px 14px;
    border-radius: 7px;
    transition: .2s;
}

.user-menu a:hover {
    background: #1b4965;
}

/* =========================
   Sidebar
========================= */

.sidebar {
    float: right;
    position: relative;
    width: 240px;
    min-height: calc(100vh - 125px);
    background: #102a43;
    padding-top: 20px;
    z-index: 1;
}

.sidebar a {
    display: block;
    color: white;
    padding: 15px 25px;
    text-decoration: none;
    font-size: 15px;
    transition: .2s;
}

.sidebar a:hover {
    background: #1b4965;
    padding-right: 30px;
}

/* =========================
   Main Content
========================= */

.content {
    margin-right: 240px;
    padding: 30px 30px 80px 30px;
    text-align: right;
}

.content h1 {
    margin-top: 0;
    margin-bottom: 25px;
    color: #0b1f3a;
    font-size: 26px;
}

.content h2 {
    color: #0b1f3a;
    font-size: 19px;
    margin-top: 0;
    margin-bottom: 20px;
}

/* =========================
   Cards
========================= */

.card {
    background: white;
    border-radius: 14px;
    padding: 25px;
    margin-bottom: 22px;
    box-shadow: 0 4px 16px rgba(0,0,0,.07);
    text-align: right;
    border: 1px solid #e9eef5;
}

/* =========================
   Dashboard
========================= */

.dashboard-box {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    justify-content: flex-start;
    direction: rtl;
}

.stat {
    background: white;
    width: 180px;
    padding: 20px;
    border-radius: 12px;
    border-right: 5px solid #1b998b;
    box-shadow: 0 3px 10px rgba(0,0,0,.08);
    text-align: right;
}

/* =========================
   Forms
========================= */

.form-group {
    margin-bottom: 18px;
}

.form-group label {
    display: block;
    margin-bottom: 7px;
    font-weight: bold;
    color: #334e68;
}

.form-control {
    width: 100%;
    padding: 11px 13px;
    border: 1px solid #ccd6e0;
    border-radius: 8px;
    background: #fff;
    font-family: inherit;
    font-size: 14px;
    transition: .2s;
}

.form-control:focus {
    outline: none;
    border-color: #1b4965;
    box-shadow: 0 0 0 3px rgba(27,73,101,.10);
}

/* =========================
   Buttons
========================= */

.btn {
    display: inline-block;
    padding: 10px 20px;
    border: 0;
    border-radius: 8px;
    cursor: pointer;
    font-family: inherit;
    font-size: 14px;
    text-decoration: none;
    transition: .2s;
}

.btn-primary {
    background: #0b1f3a;
    color: white;
}

.btn-primary:hover {
    background: #163b63;
    transform: translateY(-1px);
}

.btn-success {
    background: #1b998b;
    color: white;
}

.btn-success:hover {
    background: #168274;
}

/* =========================
   Users Table
========================= */

.data-table {
    width: 100%;
    border-collapse: collapse;
    overflow: hidden;
}

.data-table thead {
    background: #0b1f3a;
    color: white;
}

.data-table th {
    padding: 13px;
    font-weight: bold;
}

.data-table td {
    padding: 13px;
    border-bottom: 1px solid #edf1f5;
}

.data-table tbody tr {
    transition: .2s;
}

.data-table tbody tr:hover {
    background: #f7fafc;
}

/* =========================
   Badges
========================= */

.badge {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.badge-admin {
    background: #e8f1fb;
    color: #0b1f3a;
}

/* =========================
   Messages
========================= */

.alert {
    padding: 13px 16px;
    border-radius: 9px;
    margin-bottom: 20px;
    font-weight: bold;
}

.alert-success {
    background: #e9f8f3;
    color: #16745f;
    border-right: 4px solid #1b998b;
}

.alert-error {
    background: #fff0f0;
    color: #b42318;
    border-right: 4px solid #d92d20;
}

/* =========================
   Tables
========================= */

table {
    width: 100%;
    text-align: right;
}

/* =========================
   Footer
========================= */

footer {
    position: relative;
    bottom: auto;
    right: auto;
    left: auto;
    width: 100%;
    min-height: 45px;
    background: #f4f7fb;
    text-align: center;
    padding: 12px;
    color: #777;
    z-index: 1;
}

/* =========================
   Responsive
========================= */

@media (max-width: 900px) {

    .sidebar {
        width: 200px;
    }

    .content {
        margin-right: 200px;
    }

    footer {
        right: 200px;
    }
}

@media (max-width: 700px) {

    .sidebar {
        width: 170px;
    }

    .content {
        margin-right: 170px;
        padding-left: 15px;
        padding-right: 15px;
    }

    footer {
        right: 170px;
    }

    .topbar {
        padding: 10px 15px;
    }

    .title {
        font-size: 19px;
    }

    .logo {
        width: 180px;
        height: auto;
        margin-left: 15px;
        object-fit: contain;
    }
}

/* =========================
   Danger Button
========================= */

.btn-danger {
    display: inline-block;
    padding: 8px 15px;
    border: 0;
    border-radius: 7px;
    background: #d92d20;
    color: white;
    cursor: pointer;
    font-family: inherit;
    font-size: 13px;
    text-decoration: none;
    transition: .2s;
}

.btn-danger:hover {
    background: #b42318;
    transform: translateY(-1px);
}

/* =========================
   BlackList Summary
========================= */

.blacklist-summary {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    background: #ffffff;
    border: 1px solid #e5eaf0;
    border-right: 4px solid #d92d20;
    border-radius: 10px;
    padding: 10px 16px;
    margin-bottom: 20px;
    box-shadow: 0 3px 10px rgba(0,0,0,.05);
    min-width: 190px;
}

.summary-icon {
    font-size: 22px;
}

.summary-text {
    display: flex;
    align-items: center;
    gap: 10px;
}

.summary-label {
    color: #667085;
    font-size: 13px;
}

.summary-text strong {
    color: #0b1f3a;
    font-size: 22px;
}

/* Dashboard - Compact 5 Status Cards */

.dashboard-box {
    display: flex;
    gap: 12px;
    flex-wrap: nowrap;
    justify-content: stretch;
    direction: rtl;
}

.dashboard-stat {
    flex: 1 1 0;
    width: auto;
    min-width: 0;
    padding: 14px 12px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.dashboard-stat .stat-icon {
    font-size: 25px;
    flex-shrink: 0;
}

.dashboard-stat .stat-content {
    min-width: 0;
}

.dashboard-stat .stat-label {
    display: block;
    font-size: 12px;
    color: #667085;
    margin-bottom: 5px;
    white-space: nowrap;
}

.dashboard-stat strong {
    display: block;
    font-size: 18px;
    color: #0b1f3a;
    white-space: nowrap;
}


/* Dashboard section headers */

.section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 18px;
}

.section-header h2 {
    margin: 0;
}


/* Top Sites */

.section-badge {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 20px;
    background: #fff3cd;
    color: #856404;
    font-size: 12px;
    font-weight: bold;
}

.rank-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: #eef2f7;
    color: #0b1f3a;
    font-weight: bold;
}

.site-status {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 20px;
    background: #fff3cd;
    color: #856404;
    font-size: 12px;
    font-weight: bold;
}


/* =========================================
   Logs Page
   ========================================= */

.logs-status-box {
    display: flex;
    gap: 12px;
    flex-wrap: nowrap;
    margin-bottom: 20px;
}

.logs-status-box .stat {
    flex: 1;
    min-width: 0;
    width: auto;
    padding: 14px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 0;
}

.logs-status-box .stat-icon {
    font-size: 25px;
    width: 42px;
    height: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f4f7fb;
    border-radius: 10px;
    flex-shrink: 0;
}

.logs-status-box .stat-content {
    min-width: 0;
}

.logs-status-box .stat-label {
    display: block;
    font-size: 12px;
    color: #777;
    margin-bottom: 4px;
}

.logs-status-box .stat-content strong {
    display: block;
    font-size: 15px;
    color: #263238;
}


/* Toolbar */

.log-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.log-toolbar p {
    margin: 5px 0 0;
    color: #777;
    font-size: 13px;
}


/* Log Viewer */

.log-viewer {
    background: #101820;
    color: #d9e2ec;
    border-radius: 10px;
    padding: 12px;
    max-height: 430px;
    overflow-y: auto;
    direction: ltr;
    text-align: left;
    box-shadow: inset 0 0 0 1px rgba(255,255,255,.05);
}

.log-line {
    font-family: "Courier New", Consolas, monospace;
    font-size: 12px;
    line-height: 1.7;
    padding: 3px 8px;
    border-bottom: 1px solid rgba(255,255,255,.04);
    white-space: pre-wrap;
    word-break: break-word;
}

.log-line:hover {
    background: rgba(255,255,255,.06);
}


/* Section Header */

.section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 18px;
}

.section-header h2 {
    margin: 0;
}

.section-badge {
    display: inline-block;
    background: #eef3f8;
    color: #52606d;
    padding: 5px 10px;
    border-radius: 6px;
    font-size: 11px;
    direction: ltr;
    text-align: left;
}


/* Primary Button */

.btn-primary {
    display: inline-block;
    padding: 9px 17px;
    border: 0;
    border-radius: 7px;
    background: #1b998b;
    color: white;
    text-decoration: none;
    font-size: 13px;
    cursor: pointer;
    transition: .2s;
}

.btn-primary:hover {
    background: #157a70;
    color: white;
}


/* Mobile */

@media (max-width: 900px) {

    .logs-status-box {
        flex-wrap: wrap;
    }

    .logs-status-box .stat {
        min-width: calc(50% - 6px);
    }

    .log-toolbar {
        align-items: flex-start;
        flex-direction: column;
    }

}

@media (max-width: 600px) {

    .logs-status-box .stat {
        min-width: 100%;
    }

}

/* =========================================
   Log Line Highlights
   ========================================= */

.log-line.log-error {
    color: #ff7b7b;
    background: rgba(220, 53, 69, 0.08);
    border-right: 3px solid #dc3545;
}

.log-line.log-warning {
    color: #ffc56d;
    background: rgba(255, 193, 7, 0.08);
    border-right: 3px solid #f0ad4e;
}

.log-line.log-success {
    color: #78e0b8;
    background: rgba(25, 135, 84, 0.07);
    border-right: 3px solid #198754;
}

.log-line.log-info {
    color: #82c9ff;
    background: rgba(13, 110, 253, 0.06);
    border-right: 3px solid #0d6efd;
}

.log-line.log-normal {
    color: #d9e2ec;
}

/* =========================================
   Cache Page - Final UI
   ========================================= */

.cache-stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-top: 20px;
}


.cache-stat-card {
    background: #ffffff;
    border: 1px solid #e3e8ed;
    border-radius: 10px;
    padding: 22px 20px;
    text-align: center;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
    transition: .2s;
}


.cache-stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 14px rgba(0, 0, 0, 0.08);
}


.cache-stat-title {
    display: block;
    color: #52606d;
    font-size: 13px;
    margin-bottom: 12px;
}


.cache-stat-value {
    display: block;
    color: #1f2933;
    font-size: 30px;
    font-weight: 700;
    line-height: 1.2;
    direction: ltr;
}


.cache-stat-unit {
    display: block;
    color: #7b8794;
    font-size: 12px;
    margin-top: 7px;
}


.cache-stat-hit {
    border-top: 4px solid #198754;
}


.cache-stat-miss {
    border-top: 4px solid #dc3545;
}


.cache-stat-total {
    border-top: 4px solid #0d6efd;
}


.cache-stat-rate {
    border-top: 4px solid #f0ad4e;
}


.cache-stat-hit .cache-stat-value {
    color: #198754;
}


.cache-stat-miss .cache-stat-value {
    color: #dc3545;
}


.cache-stat-rate .cache-stat-value {
    color: #d88900;
}


.cache-pattern-box {
    margin-top: 20px;
}


.cache-pattern-box pre {
    margin-top: 12px;
    white-space: pre-wrap;
    overflow-x: auto;
    direction: ltr;
    text-align: left;
    font-family: monospace;
    font-size: 13px;
    line-height: 1.8;
}


/* Cache page responsive */

@media (max-width: 1000px) {

    .cache-stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}


@media (max-width: 600px) {

    .cache-stats-grid {
        grid-template-columns: 1fr;
    }

    .cache-stat-card {
        padding: 18px;
    }

    .cache-stat-value {
        font-size: 26px;
    }

}

/* =========================================
   Dashboard - Live Proxy Status
   ========================================= */

.dashboard-live-card {
    margin-top: 20px;
}

.dashboard-live-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
    margin-top: 18px;
}

.dashboard-live-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    background: #f8fafc;
    border: 1px solid #e1e8ef;
    border-radius: 10px;
    transition: .2s;
}

.dashboard-live-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,.08);
}

.live-item-icon {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    background: #eef3f8;
    font-size: 23px;
    flex-shrink: 0;
}

.live-item-content {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.live-item-label {
    color: #687786;
    font-size: 12px;
}

.live-item-content strong {
    color: #198754;
    font-size: 18px;
    font-weight: 700;
}


/* Dashboard Live Responsive */

@media (max-width: 900px) {

    .dashboard-live-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}

@media (max-width: 600px) {

    .dashboard-live-grid {
        grid-template-columns: 1fr;
    }

    .dashboard-live-item {
        padding: 17px;
    }

}


/* =========================================
   Dashboard Proxy Activity Statistics
   ========================================= */

.dashboard-activity-card {
    margin-top: 20px;
}


.dashboard-activity-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-top: 20px;
}


.dashboard-activity-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    background: #f8fafc;
    border: 1px solid #e1e8ef;
    border-radius: 10px;
    transition: .2s;
    min-width: 0;
}


.dashboard-activity-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,.08);
}


.activity-icon {
    width: 48px;
    height: 48px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 10px;
    background: #eef3f8;

    font-size: 23px;
    flex-shrink: 0;
}


.activity-content {
    display: flex;
    flex-direction: column;
    gap: 5px;
    min-width: 0;
}


.activity-label {
    color: #687786;
    font-size: 12px;
}


.activity-content strong {
    color: #263746;
    font-size: 21px;
    font-weight: 700;
    line-height: 1.2;
}


.activity-content small {
    color: #8996a3;
    font-size: 11px;
}


/* Individual Activity Cards */

.activity-total {
    border-top: 4px solid #0d6efd;
}


.activity-auth {
    border-top: 4px solid #f0ad4e;
}


.activity-denied {
    border-top: 4px solid #dc3545;
}


.activity-https {
    border-top: 4px solid #198754;
}


.activity-total .activity-content strong {
    color: #0d6efd;
}


.activity-auth .activity-content strong {
    color: #d88900;
}


.activity-denied .activity-content strong {
    color: #dc3545;
}


.activity-https .activity-content strong {
    color: #198754;
}


/* =========================================
   Proxy Activity Responsive
   ========================================= */

@media (max-width: 1000px) {

    .dashboard-activity-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}


@media (max-width: 600px) {

    .dashboard-activity-grid {
        grid-template-columns: 1fr;
    }

    .dashboard-activity-item {
        padding: 17px;
    }

    .activity-content strong {
        font-size: 20px;
    }

}

/* =========================================
   Proxy Activity 24H Chart
   ========================================= */

.dashboard-chart-card {
    margin-top: 25px;
}

.proxy-chart {
    display: flex;
    align-items: flex-end;
    gap: 8px;
    height: 300px;
    padding: 30px 15px 10px;
    background: #f8fafc;
    border: 1px solid #e1e8ef;
    border-radius: 12px;
    overflow-x: auto;
}

.chart-column {
    flex: 1;
    min-width: 42px;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    align-items: center;
    position: relative;
}

.chart-value {
    min-height: 18px;
    margin-bottom: 6px;
    color: #687786;
    font-size: 10px;
    font-weight: 600;
    white-space: nowrap;
}

.chart-bar-area {
    width: 100%;
    height: 220px;
    display: flex;
    align-items: flex-end;
    justify-content: center;
}

.chart-bar {
    width: 70%;
    min-height: 3px;
    background: #0d6efd;
    border-radius: 6px 6px 2px 2px;
    transition: .25s ease;
    box-shadow: 0 3px 8px rgba(13,110,253,.18);
}

.chart-bar:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 14px rgba(13,110,253,.28);
}

.chart-hour {
    margin-top: 9px;
    color: #687786;
    font-size: 11px;
    font-weight: 600;
}


/* =========================================
   Proxy Chart Responsive
   ========================================= */

@media (max-width: 900px) {

    .proxy-chart {
        height: 270px;
    }

    .chart-bar-area {
        height: 190px;
    }

}


@media (max-width: 600px) {

    .proxy-chart {
        height: 240px;
        gap: 6px;
        padding: 25px 10px 10px;
    }

    .chart-column {
        min-width: 38px;
    }

    .chart-bar-area {
        height: 165px;
    }

    .chart-value {
        font-size: 9px;
    }

    .chart-hour {
        font-size: 10px;
    }

}


/* =========================================
   Proxy Chart Summary
   ========================================= */

.chart-summary-grid {

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 15px;

    margin-bottom: 22px;

}


.chart-summary-item {

    display: flex;

    align-items: center;

    gap: 14px;

    padding: 16px 18px;

    background: #ffffff;

    border-radius: 10px;

    border: 1px solid #e5e9ef;

    box-shadow: 0 2px 7px rgba(0,0,0,0.05);

}


.summary-icon {

    width: 44px;

    height: 44px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 10px;

    font-size: 22px;

    flex-shrink: 0;

}


.summary-content {

    display: flex;

    flex-direction: column;

    gap: 3px;

}


.summary-content span {

    font-size: 12px;

    color: #6c757d;

}


.summary-content strong {

    font-size: 20px;

    line-height: 1.2;

}


.summary-content small {

    font-size: 11px;

    color: #8996a3;

}


/* Summary Colors */

.summary-total {

    border-top: 3px solid #0d6efd;

}


.summary-total .summary-icon {

    background: #e8f1ff;

}


.summary-total .summary-content strong {

    color: #0d6efd;

}


.summary-peak {

    border-top: 3px solid #f0ad4e;

}


.summary-peak .summary-icon {

    background: #fff4df;

}


.summary-peak .summary-content strong {

    color: #d88900;

}


.summary-low {

    border-top: 3px solid #198754;

}


.summary-low .summary-icon {

    background: #e8f7ef;

}


.summary-low .summary-content strong {

    color: #198754;

}


/* Responsive */

@media (max-width: 900px) {

    .chart-summary-grid {

        grid-template-columns: 1fr;

    }

}


@media (max-width: 600px) {

    .chart-summary-item {

        padding: 14px;

    }

    .summary-content strong {

        font-size: 18px;

    }

}



/* =========================
   Proxy Multi Chart
   ========================= */

.proxy-multi-chart {

    display: flex;
    align-items: flex-end;
    gap: 8px;
    height: 320px;
    overflow-x: auto;
    padding: 20px 10px;

}


.multi-chart-column {

    min-width: 55px;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    align-items: center;

}


.multi-chart-bars {

    height: 260px;
    display: flex;
    align-items: flex-end;
    gap: 3px;

}


.multi-bar {

    width: 14px;
    min-height: 2px;
    border-radius: 4px 4px 0 0;
    position: relative;

}


.multi-bar span {

    display: none;

}


.total-bar {

    background: #0d6efd;

}


.denied-bar {

    background: #dc3545;

}


.https-bar {

    background: #198754;

}


.multi-chart-hour {

    margin-top: 10px;
    font-size: 12px;

}


.chart-legend {

    display: flex;
    gap: 25px;
    padding: 10px 20px;

}


.legend-item {

    display: flex;
    align-items: center;
    gap: 8px;

}


.legend-dot {

    width: 12px;
    height: 12px;
    border-radius: 50%;

}


.legend-total {

    background: #0d6efd;

}


.legend-denied {

    background: #dc3545;

}


.legend-https {

    background: #198754;

}

/* =========================================================
   Global Site Footer
   ========================================================= */

.site-footer {

    margin-top: 40px;

    padding: 18px 30px;

    background: #ffffff;

    border-top: 1px solid #e4e7ec;

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 18px;

    color: #667085;

    font-size: 12px;

}


.footer-brand {

    display: flex;

    align-items: center;

    justify-content: center;

}


.footer-brand img {

    width: 42px;

    height: 42px;

    object-fit: contain;

}


.footer-text {

    display: flex;

    flex-direction: column;

    align-items: flex-start;

    gap: 3px;

    direction: ltr;

    text-align: left;

}


.footer-text strong {

    color: #344054;

    font-size: 12px;

    font-weight: 700;

}


.footer-text span {

    color: #667085;

    font-size: 11px;

}


.footer-text small {

    color: #98a2b3;

    font-size: 10px;

}


@media (max-width: 600px) {

    .site-footer {

        flex-direction: column;

        text-align: center;

        padding: 20px;

    }


    .footer-text {

        align-items: center;

        text-align: center;

    }

}
