<?php include "includes/header.php"; ?>

<h1>لیست سایت‌های مسدود شده</h1>

<div class="card">

<p>
مدیریت Block List در این بخش قرار خواهد گرفت.
</p>

</div>

<?php include "includes/footer.php"; ?>
