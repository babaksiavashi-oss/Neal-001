<?php
declare(strict_types=1);

require_once __DIR__ . '/auth/auth.php';
check_login();

header('Content-Type: application/json; charset=UTF-8');

$backupRoot = '/usr/local/backups/neal';
$jobsDir = $backupRoot . '/jobs';
$filesDir = $backupRoot . '/files';

/*
 * همیشه از PHP CLI استفاده می‌کنیم.
 *
 * PHP_BINARY در اجرای Apache/PHP ممکن است به باینری
 * PHP-FPM یا SAPI وب اشاره کند و برای اجرای Worker مناسب نباشد.
 */
$phpCli = '/usr/local/bin/php';

$worker = __DIR__ . '/backup-worker.php';

function json_out(bool $ok, array $data = []): never
{
    echo json_encode(
        array_merge(['ok' => $ok], $data),
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    json_out(
        false,
        [
            'message' => 'درخواست نامعتبر است.'
        ]
    );

}


$csrf = (string)($_POST['csrf'] ?? '');

if (
    empty($_SESSION['backup_csrf']) ||
    !hash_equals($_SESSION['backup_csrf'], $csrf)
) {

    json_out(
        false,
        [
            'message' => 'اعتبار امنیتی درخواست منقضی شده است. صفحه را مجدداً باز کنید.'
        ]
    );

}


$type = (string)($_POST['type'] ?? '');

$allowed = [
    'files',
    'database',
    'full'
];


if (!in_array($type, $allowed, true)) {

    json_out(
        false,
        [
            'message' => 'نوع پشتیبان‌گیری نامعتبر است.'
        ]
    );

}


if (!is_file($worker)) {

    json_out(
        false,
        [
            'message' => 'فایل اجرای پشتیبان‌گیری پیدا نشد.'
        ]
    );

}


/*
 * بررسی PHP CLI
 */
if (!is_file($phpCli) || !is_executable($phpCli)) {

    json_out(
        false,
        [
            'message' => 'PHP CLI در مسیر مورد انتظار پیدا نشد.'
        ]
    );

}


if (!is_dir($jobsDir) && !@mkdir($jobsDir, 0750, true)) {

    json_out(
        false,
        [
            'message' => 'امکان ایجاد پوشه Job وجود ندارد.'
        ]
    );

}


if (!is_dir($filesDir) && !@mkdir($filesDir, 0750, true)) {

    json_out(
        false,
        [
            'message' => 'امکان ایجاد پوشه Backup وجود ندارد.'
        ]
    );

}


/*
 * جلوگیری از اجرای همزمان چند Backup
 */
foreach (glob($jobsDir . '/*.json') ?: [] as $jobFile) {

    $job = json_decode(
        (string)@file_get_contents($jobFile),
        true
    );

    if (
        is_array($job) &&
        in_array(
            ($job['status'] ?? ''),
            [
                'queued',
                'running'
            ],
            true
        )
    ) {

        json_out(
            false,
            [
                'message' => 'یک عملیات پشتیبان‌گیری دیگر در حال اجراست. لطفاً تا پایان آن صبر کنید.'
            ]
        );

    }

}


$jobId =
    date('Ymd_His') .
    '_' .
    bin2hex(random_bytes(4));


$filename =
    'neal_backup_' .
    $type .
    '_' .
    date('Ymd_His') .
    '_' .
    substr($jobId, -8) .
    '.zip';


$typeLabels = [

    'files' =>
        'فقط فایل‌های سایت',

    'database' =>
        'فقط دیتابیس',

    'full' =>
        'پشتیبان کامل'

];


$job = [

    'job_id' =>
        $jobId,

    'type' =>
        $type,

    'type_label' =>
        $typeLabels[$type],

    'filename' =>
        $filename,

    'status' =>
        'queued',

    'progress' =>
        0,

    'stage' =>
        'queued',

    'stage_label' =>
        'در صف اجرا',

    'message' =>
        'عملیات پشتیبان‌گیری در صف قرار گرفت.',

    'current_file' =>
        '',

    'created_at' =>
        date('Y-m-d H:i:s'),

    'created_by' =>
        (string)($_SESSION['username'] ?? 'admin'),

    'size' =>
        0

];


$jobFile =
    $jobsDir .
    '/' .
    $jobId .
    '.json';


if (
    @file_put_contents(
        $jobFile,
        json_encode(
            $job,
            JSON_UNESCAPED_UNICODE |
            JSON_PRETTY_PRINT
        ),
        LOCK_EX
    ) === false
) {

    json_out(
        false,
        [
            'message' =>
                'امکان ثبت عملیات پشتیبان‌گیری وجود ندارد.'
        ]
    );

}


/*
 * اجرای Worker با PHP CLI
 *
 * خروجی Worker عمداً به /dev/null می‌رود،
 * چون وضعیت Backup از طریق فایل Job خوانده می‌شود.
 */
$command =
    'nohup ' .
    escapeshellarg($phpCli) .
    ' ' .
    escapeshellarg($worker) .
    ' ' .
    escapeshellarg($jobId) .
    ' > /dev/null 2>&1 &';


@exec($command);


/*
 * کمی زمان می‌دهیم Worker شروع شود
 * تا وضعیت queued سریعاً به running تغییر کند.
 */
usleep(150000);


json_out(
    true,
    [
        'job_id' =>
            $jobId
    ]
);
