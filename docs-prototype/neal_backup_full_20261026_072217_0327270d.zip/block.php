<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>

<meta charset="UTF-8">

<title>دسترسی به سایت مسدود شد</title>

<link rel="stylesheet" href="css/style.css">

</head>

<body>

<div class="card">

<img src="images/logo.png" class="logo">

<h1>دسترسی به این وب‌سایت مجاز نیست</h1>

<p class="message">

دسترسی به این وب‌سایت بر اساس سیاست‌های امنیتی شرکت محدود شده است.

</p>

<hr>

<table>

<tr>

<td>کاربر</td>

<td id="user">---</td>

</tr>

<tr>

<td>آدرس IP</td>

<td id="ip">---</td>

</tr>

<tr>

<td>وب سایت</td>

<td id="site">---</td>

</tr>

<tr>

<td>زمان</td>

<td id="time"></td>

</tr>

</table>

<div class="footer">

واحد فناوری اطلاعات

</div>

</div>

<script>

document.getElementById("time").innerHTML=new Date().toLocaleString();

</script>

</body>

</html>
