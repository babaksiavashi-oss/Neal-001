<?php

require_once "auth/auth.php";

check_login();

$page_title = "درخواست خدمات IT";

require_once "includes/header.php";

?>

<div class="card service-request-page">

    <div class="service-request-header">

        <div>
            <h1>🎫 درخواست خدمات فناوری اطلاعات</h1>

            <p>
                برای ثبت درخواست پشتیبانی، اطلاعات زیر را تکمیل نمایید.
            </p>
        </div>

    </div>


    <form class="service-request-form" method="post" action="#">

        <!-- =========================
             Requester Information
        ========================== -->

        <div class="form-section">

            <h2>۱. اطلاعات درخواست‌کننده</h2>

            <div class="form-grid">

                <div class="form-group">

                    <label>نام و نام خانوادگی</label>

                    <input
                        type="text"
                        value=""
                        placeholder="نام و نام خانوادگی"
                    >

                </div>


                <div class="form-group">

                    <label>کد پرسنلی</label>

                    <input
                        type="text"
                        value=""
                        placeholder="کد پرسنلی"
                    >

                </div>


                <div class="form-group">

                    <label>واحد / دپارتمان</label>

                    <input
                        type="text"
                        value=""
                        placeholder="واحد سازمانی"
                    >

                </div>


                <div class="form-group">

                    <label>شماره تماس</label>

                    <input
                        type="text"
                        value=""
                        placeholder="شماره داخلی / موبایل"
                    >

                </div>

            </div>

        </div>


        <!-- =========================
             Request Type
        ========================== -->

        <div class="form-section">

            <h2>۲. نوع درخواست</h2>

            <div class="request-type-grid">

                <label class="request-type">

                    <input type="checkbox" name="request_type[]" value="hardware">

                    <span>🖥️</span>

                    <strong>پشتیبانی سخت‌افزار</strong>

                </label>


                <label class="request-type">

                    <input type="checkbox" name="request_type[]" value="software">

                    <span>💿</span>

                    <strong>پشتیبانی نرم‌افزار</strong>

                </label>


                <label class="request-type">

                    <input type="checkbox" name="request_type[]" value="install">

                    <span>⚙️</span>

                    <strong>نصب / به‌روزرسانی</strong>

                </label>


                <label class="request-type">

                    <input type="checkbox" name="request_type[]" value="access">

                    <span>🔐</span>

                    <strong>دسترسی سامانه / شبکه</strong>

                </label>


                <label class="request-type">

                    <input type="checkbox" name="request_type[]" value="network">

                    <span>🌐</span>

                    <strong>اینترنت / شبکه</strong>

                </label>


                <label class="request-type">

                    <input type="checkbox" name="request_type[]" value="equipment">

                    <span>🔧</span>

                    <strong>تعمیر / تعویض تجهیزات</strong>

                </label>


                <label class="request-type">

                    <input type="checkbox" name="request_type[]" value="security">

                    <span>🛡️</span>

                    <strong>امنیت / آنتی‌ویروس</strong>

                </label>


                <label class="request-type">

                    <input type="checkbox" name="request_type[]" value="backup">

                    <span>💾</span>

                    <strong>پشتیبان‌گیری / بازیابی</strong>

                </label>


                <label class="request-type request-type-other">

                    <input type="checkbox" name="request_type[]" value="other">

                    <span>📌</span>

                    <strong>سایر</strong>

                </label>

            </div>

        </div>


        <!-- =========================
             Priority
        ========================== -->

        <div class="form-section">

            <h2>۳. اولویت درخواست</h2>

            <div class="priority-grid">

                <label class="priority-option">

                    <input type="radio" name="priority" value="normal">

                    <span class="priority-box">

                        <strong>عادی</strong>

                        <small>بدون اختلال جدی</small>

                    </span>

                </label>


                <label class="priority-option">

                    <input type="radio" name="priority" value="important">

                    <span class="priority-box">

                        <strong>مهم</strong>

                        <small>نیازمند رسیدگی</small>

                    </span>

                </label>


                <label class="priority-option">

                    <input type="radio" name="priority" value="urgent">

                    <span class="priority-box">

                        <strong>فوری</strong>

                        <small>اختلال در کار</small>

                    </span>

                </label>


                <label class="priority-option">

                    <input type="radio" name="priority" value="critical">

                    <span class="priority-box">

                        <strong>بحرانی</strong>

                        <small>توقف فعالیت</small>

                    </span>

                </label>

            </div>

        </div>


        <!-- =========================
             Request Description
        ========================== -->

        <div class="form-section">

            <h2>۴. شرح درخواست</h2>

            <div class="form-group">

                <label>موضوع درخواست</label>

                <input
                    type="text"
                    name="subject"
                    placeholder="موضوع درخواست را وارد کنید"
                >

            </div>


            <div class="form-group">

                <label>شرح کامل درخواست</label>

                <textarea
                    name="description"
                    rows="7"
                    placeholder="لطفاً مشکل یا درخواست خود را با جزئیات توضیح دهید..."
                ></textarea>

            </div>

        </div>


        <!-- =========================
             Technical Information
        ========================== -->

        <div class="form-section">

            <h2>۵. اطلاعات فنی</h2>

            <div class="form-grid">

                <div class="form-group">

                    <label>نام دستگاه / کد اموال</label>

                    <input
                        type="text"
                        name="asset"
                        placeholder="در صورت وجود"
                    >

                </div>


                <div class="form-group">

                    <label>Hostname</label>

                    <input
                        type="text"
                        name="hostname"
                        placeholder="نام سیستم"
                    >

                </div>


                <div class="form-group">

                    <label>شماره IP</label>

                    <input
                        type="text"
                        name="ip"
                        placeholder="مثلاً 192.168.7.100"
                    >

                </div>


                <div class="form-group">

                    <label>محل استقرار</label>

                    <input
                        type="text"
                        name="location"
                        placeholder="ساختمان / اتاق / واحد"
                    >

                </div>


                <div class="form-group form-grid-full">

                    <label>نرم‌افزار / سامانه مرتبط</label>

                    <input
                        type="text"
                        name="software"
                        placeholder="در صورت وجود"
                    >

                </div>

            </div>

        </div>


        <!-- =========================
             Attachment
        ========================== -->

        <div class="form-section">

            <h2>۶. پیوست</h2>

            <div class="attachment-box">

                <div class="attachment-icon">
                    📎
                </div>

                <div>

                    <strong>پیوست فایل</strong>

                    <p>
                        در صورت نیاز می‌توانید تصویر خطا یا فایل مرتبط را پیوست کنید.
                    </p>

                </div>

                <input
                    type="file"
                    name="attachment"
                >

            </div>

        </div>


        <!-- =========================
             Submit
        ========================== -->

        <div class="form-actions">

            <button
                type="button"
                class="btn-secondary"
                onclick="window.history.back();"
            >
                انصراف
            </button>


            <button
                type="submit"
                class="btn-primary"
            >
                🎫 ثبت درخواست
            </button>

        </div>


        <div class="form-notice">

            ℹ️ پس از ثبت درخواست، شماره پیگیری برای شما ایجاد خواهد شد.

        </div>

    </form>

</div>


<style>

.service-request-page {
    max-width: 1200px;
    margin: 0 auto 30px auto;
}

.service-request-header {
    padding-bottom: 20px;
    margin-bottom: 25px;
    border-bottom: 1px solid #e5eaf0;
}

.service-request-header h1 {
    margin: 0 0 8px 0;
}

.service-request-header p {
    margin: 0;
    color: #667085;
    font-size: 14px;
}

.form-section {
    margin-bottom: 30px;
}

.form-section h2 {
    margin-bottom: 18px;
    padding-bottom: 10px;
    border-bottom: 1px solid #edf1f5;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 18px;
}

.form-grid-full {
    grid-column: 1 / -1;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.form-group label {
    font-size: 13px;
    font-weight: bold;
    color: #344054;
}

.form-group input,
.form-group textarea {
    width: 100%;
    border: 1px solid #d0d5dd;
    border-radius: 8px;
    padding: 11px 13px;
    font-family: Tahoma, Arial, sans-serif;
    font-size: 13px;
    background: #fff;
    transition: .2s;
}

.form-group textarea {
    resize: vertical;
    line-height: 1.8;
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #1b4965;
    box-shadow: 0 0 0 3px rgba(27,73,101,.10);
}

.request-type-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
}

.request-type {
    display: flex;
    align-items: center;
    gap: 10px;
    min-height: 65px;
    padding: 12px 15px;
    border: 1px solid #e0e6ed;
    border-radius: 10px;
    background: #fff;
    cursor: pointer;
    transition: .2s;
}

.request-type:hover {
    border-color: #1b4965;
    background: #f7fafc;
}

.request-type input {
    accent-color: #1b4965;
}

.request-type span {
    font-size: 20px;
}

.request-type strong {
    font-size: 13px;
}

.priority-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
}

.priority-option {
    cursor: pointer;
}

.priority-option input {
    display: none;
}

.priority-box {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 15px;
    border: 1px solid #e0e6ed;
    border-radius: 10px;
    background: #fff;
    transition: .2s;
}

.priority-box strong {
    font-size: 14px;
}

.priority-box small {
    color: #667085;
    font-size: 11px;
}

.priority-option:hover .priority-box {
    border-color: #1b4965;
}

.priority-option input:checked + .priority-box {
    border-color: #1b4965;
    background: #f0f6fa;
    box-shadow: 0 0 0 2px rgba(27,73,101,.08);
}

.attachment-box {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 18px;
    border: 1px dashed #b8c3d0;
    border-radius: 10px;
    background: #fafbfc;
}

.attachment-icon {
    font-size: 28px;
}

.attachment-box p {
    margin: 5px 0 0 0;
    color: #667085;
    font-size: 12px;
}

.attachment-box input[type="file"] {
    margin-right: auto;
    font-family: Tahoma, Arial, sans-serif;
    font-size: 12px;
}

.form-actions {
    display: flex;
    justify-content: flex-start;
    gap: 10px;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #edf1f5;
}

.btn-primary,
.btn-secondary {
    border: 0;
    border-radius: 8px;
    padding: 11px 22px;
    font-family: Tahoma, Arial, sans-serif;
    font-size: 13px;
    cursor: pointer;
    transition: .2s;
}

.btn-primary {
    background: #0b1f3a;
    color: white;
}

.btn-primary:hover {
    background: #1b4965;
}

.btn-secondary {
    background: #eef2f6;
    color: #344054;
}

.btn-secondary:hover {
    background: #e2e8f0;
}

.form-notice {
    margin-top: 15px;
    padding: 12px 15px;
    border-radius: 8px;
    background: #f4f7fb;
    color: #667085;
    font-size: 12px;
}

@media (max-width: 900px) {

    .request-type-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .priority-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}

@media (max-width: 700px) {

    .form-grid {
        grid-template-columns: 1fr;
    }

    .request-type-grid {
        grid-template-columns: 1fr;
    }

    .priority-grid {
        grid-template-columns: 1fr;
    }

    .attachment-box {
        flex-direction: column;
        align-items: flex-start;
    }

}

</style>


<?php

require_once "includes/footer.php";

?>
