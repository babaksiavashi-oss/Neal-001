<?php

require_once __DIR__ . '/auth/auth.php';
require_once __DIR__ . '/config/config.php';

check_login();

$db = new PDO('sqlite:' . __DIR__ . '/data/neal.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


/* =========================================================
   Ticket ID
   ========================================================= */

$request_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($request_id <= 0) {
    header('Location: /neal/tickets.php');
    exit;
}


/* =========================================================
   Labels
   ========================================================= */

$statusLabels = array(
    'new'          => 'جدید',
    'assigned'     => 'تخصیص داده شده',
    'in_progress'  => 'در حال بررسی',
    'waiting_user' => 'منتظر پاسخ کاربر',
    'resolved'     => 'حل شده',
    'closed'       => 'بسته شده',
    'cancelled'    => 'لغو شده'
);

$priorityLabels = array(
    'normal'    => 'عادی',
    'important' => 'مهم',
    'urgent'    => 'فوری',
    'critical'  => 'بحرانی'
);

$departmentLabels = array(
    'management'     => 'واحد مدیریت',
    'regulatory'     => 'واحد مسئول فنی و رگولاتوری',
    'administrative' => 'واحد اداری',
    'engineering'    => 'واحد فنی مهندسی',
    'finance'        => 'واحد مالی',
    'planning'       => 'واحد برنامه ریزی و انبار',
    'quality'        => 'واحد آزمایشگاه کنترل کیفیت',
    'commercial'     => 'واحد بازرگانی',
    'production'     => 'واحد تولید',
    'hse'            => 'واحد ایمنی و بهداشت'
);


/* =========================================================
   Helpers
   ========================================================= */

function jalaliDate($datetime)
{
    if (empty($datetime)) {
        return '-';
    }

    $timestamp = strtotime($datetime);

    if ($timestamp === false) {
        return $datetime;
    }

    $gy = (int)date('Y', $timestamp);
    $gm = (int)date('n', $timestamp);
    $gd = (int)date('j', $timestamp);

    $g_d_m = array(
        0, 31, 59, 90, 120, 151,
        181, 212, 243, 273, 304, 334
    );

    if ($gy > 1600) {
        $jy = 979;
        $gy -= 1600;
    } else {
        $jy = 0;
        $gy -= 621;
    }

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;

    $days = (365 * $gy)
        + (int)(($gy2 + 3) / 4)
        - (int)(($gy2 + 99) / 100)
        + (int)(($gy2 + 399) / 400)
        - 80
        + $gd
        + $g_d_m[$gm - 1];

    $jy += 33 * (int)($days / 12053);
    $days %= 12053;

    $jy += 4 * (int)($days / 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return sprintf(
        '%04d/%02d/%02d - %s',
        $jy,
        $jm,
        $jd,
        date('H:i', $timestamp)
    );
}


function persianNumber($number)
{
    return strtr(
        (string)$number,
        array(
            '0' => '۰',
            '1' => '۱',
            '2' => '۲',
            '3' => '۳',
            '4' => '۴',
            '5' => '۵',
            '6' => '۶',
            '7' => '۷',
            '8' => '۸',
            '9' => '۹'
        )
    );
}


/* =========================================================
   Load Ticket
   ========================================================= */

$stmt = $db->prepare("
    SELECT
        sr.*,
        a.username AS assigned_username
    FROM service_requests sr
    LEFT JOIN admins a
        ON a.id = sr.assigned_to
    WHERE sr.id = ?
    LIMIT 1
");

$stmt->execute(array($request_id));

$ticket = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$ticket) {
    header('Location: /neal/tickets.php');
    exit;
}


/* =========================================================
   POST Actions
   ========================================================= */

$action_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = isset($_POST['action'])
        ? trim($_POST['action'])
        : '';


    /* =====================================================
       Change Status
       ===================================================== */

    if ($action === 'change_status') {

        $new_status = isset($_POST['status'])
            ? trim($_POST['status'])
            : '';

        if (!isset($statusLabels[$new_status])) {

            $action_error = 'وضعیت انتخاب‌شده معتبر نیست.';

        } elseif ($new_status === $ticket['status']) {

            header(
                'Location: /neal/ticket-manage.php?id='
                . $request_id
                . '#management'
            );
            exit;

        } else {

            try {

                $db->beginTransaction();

                $old_status = $ticket['status'];

                $updateSql = "
                    UPDATE service_requests
                    SET
                        status = ?,
                        updated_at = CURRENT_TIMESTAMP
                ";

                $updateParams = array($new_status);


                if (
                    $new_status === 'assigned'
                    && empty($ticket['assigned_at'])
                ) {

                    $updateSql .= ",
                        assigned_at = CURRENT_TIMESTAMP
                    ";
                }


                if (
                    $new_status === 'in_progress'
                    && empty($ticket['started_at'])
                ) {

                    $updateSql .= ",
                        started_at = CURRENT_TIMESTAMP
                    ";
                }


                if (
                    $new_status === 'resolved'
                    && empty($ticket['resolved_at'])
                ) {

                    $updateSql .= ",
                        resolved_at = CURRENT_TIMESTAMP
                    ";
                }


                if (
                    $new_status === 'closed'
                    && empty($ticket['closed_at'])
                ) {

                    $updateSql .= ",
                        closed_at = CURRENT_TIMESTAMP
                    ";
                }


                $updateSql .= "
                    WHERE id = ?
                ";

                $updateParams[] = $request_id;

                $stmtUpdate = $db->prepare($updateSql);
                $stmtUpdate->execute($updateParams);


                $adminId = isset($_SESSION['admin_id'])
                    ? (int)$_SESSION['admin_id']
                    : null;

                $historyStmt = $db->prepare("
                    INSERT INTO ticket_status_history
                    (
                        request_id,
                        old_status,
                        new_status,
                        changed_by,
                        note
                    )
                    VALUES (?, ?, ?, ?, ?)
                ");

                $historyStmt->execute(
                    array(
                        $request_id,
                        $old_status,
                        $new_status,
                        $adminId,
                        null
                    )
                );


                $db->commit();

                header(
                    'Location: /neal/ticket-manage.php?id='
                    . $request_id
                    . '#management'
                );
                exit;

            } catch (Exception $e) {

                if ($db->inTransaction()) {
                    $db->rollBack();
                }

                $action_error =
                    'خطا در تغییر وضعیت: '
                    . $e->getMessage();
            }
        }
    }


    /* =====================================================
       Change Priority
       ===================================================== */

    elseif ($action === 'change_priority') {

        $new_priority = isset($_POST['priority'])
            ? trim($_POST['priority'])
            : '';

        if (!isset($priorityLabels[$new_priority])) {

            $action_error = 'اولویت انتخاب‌شده معتبر نیست.';

        } else {

            $stmtUpdate = $db->prepare("
                UPDATE service_requests
                SET
                    priority = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmtUpdate->execute(
                array(
                    $new_priority,
                    $request_id
                )
            );

            header(
                'Location: /neal/ticket-manage.php?id='
                . $request_id
                . '#management'
            );
            exit;
        }
    }


    /* =====================================================
       Assign Ticket
       ===================================================== */

    elseif ($action === 'assign_ticket') {

        $assigned_to = isset($_POST['assigned_to'])
            ? (int)$_POST['assigned_to']
            : 0;


        if ($assigned_to <= 0) {

            $stmtUpdate = $db->prepare("
                UPDATE service_requests
                SET
                    assigned_to = NULL,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmtUpdate->execute(
                array($request_id)
            );

        } else {

            $adminCheck = $db->prepare("
                SELECT id
                FROM admins
                WHERE id = ?
                LIMIT 1
            ");

            $adminCheck->execute(
                array($assigned_to)
            );

            if (!$adminCheck->fetchColumn()) {

                $action_error =
                    'کارشناس انتخاب‌شده معتبر نیست.';

            } else {

                $stmtUpdate = $db->prepare("
                    UPDATE service_requests
                    SET
                        assigned_to = ?,
                        assigned_at =
                            CASE
                                WHEN assigned_at IS NULL
                                THEN CURRENT_TIMESTAMP
                                ELSE assigned_at
                            END,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ");

                $stmtUpdate->execute(
                    array(
                        $assigned_to,
                        $request_id
                    )
                );

                header(
                    'Location: /neal/ticket-manage.php?id='
                    . $request_id
                    . '#management'
                );
                exit;
            }
        }

        if ($action_error === '') {

            header(
                'Location: /neal/ticket-manage.php?id='
                . $request_id
                . '#management'
            );
            exit;
        }
    }


    /* =====================================================
       User Reply
       ===================================================== */

    elseif ($action === 'user_reply') {

        $message = isset($_POST['message'])
            ? trim($_POST['message'])
            : '';

        if ($message === '') {

            $action_error =
                'متن پاسخ را وارد کنید.';

        } else {

            $senderAdminId =
                isset($_SESSION['admin_id'])
                    ? (int)$_SESSION['admin_id']
                    : null;

            $senderUsername =
                isset($_SESSION['username'])
                    ? $_SESSION['username']
                    : 'admin';


            $stmtMessage = $db->prepare("
                INSERT INTO ticket_messages
                (
                    request_id,
                    sender_admin_id,
                    sender_username,
                    message,
                    is_internal
                )
                VALUES (?, ?, ?, ?, 0)
            ");

            $stmtMessage->execute(
                array(
                    $request_id,
                    $senderAdminId,
                    $senderUsername,
                    $message
                )
            );


            $stmtUpdate = $db->prepare("
                UPDATE service_requests
                SET
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmtUpdate->execute(
                array($request_id)
            );


            header(
                'Location: /neal/ticket-manage.php?id='
                . $request_id
                . '#conversation'
            );
            exit;
        }
    }


    /* =====================================================
       Internal Note
       ===================================================== */

    elseif ($action === 'internal_note') {

        $message = isset($_POST['message'])
            ? trim($_POST['message'])
            : '';

        if ($message === '') {

            $action_error =
                'متن یادداشت داخلی را وارد کنید.';

        } else {

            $senderAdminId =
                isset($_SESSION['admin_id'])
                    ? (int)$_SESSION['admin_id']
                    : null;

            $senderUsername =
                isset($_SESSION['username'])
                    ? $_SESSION['username']
                    : 'admin';


            $stmtMessage = $db->prepare("
                INSERT INTO ticket_messages
                (
                    request_id,
                    sender_admin_id,
                    sender_username,
                    message,
                    is_internal
                )
                VALUES (?, ?, ?, ?, 1)
            ");

            $stmtMessage->execute(
                array(
                    $request_id,
                    $senderAdminId,
                    $senderUsername,
                    $message
                )
            );


            $stmtUpdate = $db->prepare("
                UPDATE service_requests
                SET
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmtUpdate->execute(
                array($request_id)
            );


            header(
                'Location: /neal/ticket-manage.php?id='
                . $request_id
                . '#internal-notes'
            );
            exit;
        }
    }
}


/* =========================================================
   Reload Ticket After POST
   ========================================================= */

$stmt = $db->prepare("
    SELECT
        sr.*,
        a.username AS assigned_username
    FROM service_requests sr
    LEFT JOIN admins a
        ON a.id = sr.assigned_to
    WHERE sr.id = ?
    LIMIT 1
");

$stmt->execute(array($request_id));

$ticket = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$ticket) {
    header('Location: /neal/tickets.php');
    exit;
}


/* =========================================================
   Request Types
   ========================================================= */

$stmt = $db->prepare("
    SELECT rt.name
    FROM service_request_types srt
    INNER JOIN request_types rt
        ON rt.id = srt.request_type_id
    WHERE srt.request_id = ?
    ORDER BY rt.id
");

$stmt->execute(array($request_id));

$requestTypes = $stmt->fetchAll(PDO::FETCH_COLUMN);


/* =========================================================
   User-visible Conversation
   ========================================================= */

$stmt = $db->prepare("
    SELECT
        tm.*,
        a.username AS admin_username
    FROM ticket_messages tm
    LEFT JOIN admins a
        ON a.id = tm.sender_admin_id
    WHERE tm.request_id = ?
      AND tm.is_internal = 0
    ORDER BY tm.created_at ASC, tm.id ASC
");

$stmt->execute(array($request_id));

$conversation = $stmt->fetchAll(PDO::FETCH_ASSOC);


/* =========================================================
   Internal Notes
   ========================================================= */

$stmt = $db->prepare("
    SELECT
        tm.*,
        a.username AS admin_username
    FROM ticket_messages tm
    LEFT JOIN admins a
        ON a.id = tm.sender_admin_id
    WHERE tm.request_id = ?
      AND tm.is_internal = 1
    ORDER BY tm.created_at ASC, tm.id ASC
");

$stmt->execute(array($request_id));

$internalNotes = $stmt->fetchAll(PDO::FETCH_ASSOC);


/* =========================================================
   Status History
   ========================================================= */

$stmt = $db->prepare("
    SELECT
        tsh.*,
        a.username AS changed_by_username
    FROM ticket_status_history tsh
    LEFT JOIN admins a
        ON a.id = tsh.changed_by
    WHERE tsh.request_id = ?
    ORDER BY tsh.created_at ASC, tsh.id ASC
");

$stmt->execute(array($request_id));

$statusHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);


/* =========================================================
   Attachments
   ========================================================= */

$stmt = $db->prepare("
    SELECT
        ta.*,
        a.username AS uploader_username
    FROM ticket_attachments ta
    LEFT JOIN admins a
        ON a.id = ta.uploaded_by
    WHERE ta.request_id = ?
    ORDER BY ta.created_at ASC, ta.id ASC
");

$stmt->execute(array($request_id));

$attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);


/* =========================================================
   Admin List
   ========================================================= */

$stmt = $db->query("
    SELECT id, username, role
    FROM admins
    ORDER BY username ASC
");

$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);


/* =========================================================
   Page Title
   ========================================================= */

$page_title =
    'مدیریت تیکت '
    . $ticket['tracking_number'];

?>


<?php require_once __DIR__ . '/includes/header.php'; ?>


<style>

/* =========================================================
   Ticket Management
   ========================================================= */

.ticket-manage {
    width: 100%;
}

.ticket-manage-title {
    margin-bottom: 20px;
}

.ticket-manage-title h1 {
    margin: 0 0 7px 0;
    font-size: 25px;
}

.ticket-manage-title p {
    margin: 0;
    color: #666;
    font-size: 14px;
}


/* Error */

.ticket-action-error {
    background: #fff1f1;
    border: 1px solid #e0b4b4;
    color: #a00000;
    border-radius: 7px;
    padding: 12px 15px;
    margin-bottom: 18px;
}


/* General Box */

.ticket-box {
    background: #ffffff;
    border: 1px solid #dddddd;
    border-radius: 8px;
    margin-bottom: 18px;
    overflow: hidden;
}

.ticket-box-title {
    background: #f4f6f8;
    border-bottom: 1px solid #dddddd;
    padding: 12px 16px;
    font-weight: 700;
    color: #333;
}

.ticket-box-body {
    padding: 16px;
}


/* Ticket Header */

.ticket-main-header {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 20px;
    align-items: center;
}

.ticket-tracking {
    font-size: 23px;
    font-weight: 700;
    margin-bottom: 7px;
}

.ticket-subject {
    font-size: 18px;
    color: #444;
}

.ticket-header-badges {
    display: flex;
    gap: 7px;
    flex-wrap: wrap;
    justify-content: flex-start;
}


/* Badges */

.ticket-badge {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 12px;
    font-size: 12px;
    white-space: nowrap;
}

.status-new {
    background: #e8f1ff;
    color: #1859a5;
}

.status-assigned {
    background: #eee8ff;
    color: #5d35a5;
}

.status-in_progress {
    background: #fff4d8;
    color: #8a6100;
}

.status-waiting_user {
    background: #fff0e5;
    color: #a24b00;
}

.status-resolved {
    background: #e4f7ea;
    color: #217a3a;
}

.status-closed {
    background: #eeeeee;
    color: #555;
}

.status-cancelled {
    background: #ffe7e7;
    color: #a00000;
}

.priority-normal {
    background: #eeeeee;
    color: #555;
}

.priority-important {
    background: #fff4d8;
    color: #8a6100;
}

.priority-urgent {
    background: #ffe7d6;
    color: #a63f00;
}

.priority-critical {
    background: #ffdede;
    color: #a00000;
    font-weight: 700;
}


/* Information Grid */

.ticket-info-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
}

.ticket-info-item {
    border: 1px solid #eeeeee;
    border-radius: 6px;
    padding: 11px 13px;
    background: #fafafa;
}

.ticket-info-label {
    font-size: 11px;
    color: #777;
    margin-bottom: 5px;
}

.ticket-info-value {
    font-size: 13px;
    color: #333;
    font-weight: 600;
    line-height: 1.7;
}


/* Description */

.ticket-description {
    white-space: pre-wrap;
    line-height: 2;
    font-size: 14px;
    color: #333;
}


/* Management Controls */

.ticket-management-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
}

.ticket-management-item label {
    display: block;
    margin-bottom: 6px;
    font-size: 13px;
    color: #555;
    font-weight: 600;
}

.ticket-management-item select {
    width: 100%;
    box-sizing: border-box;
    min-height: 40px;
    border: 1px solid #cccccc;
    border-radius: 5px;
    padding: 7px 10px;
    background: #fff;
    font-family: inherit;
    font-size: 13px;
}

.ticket-management-item button {
    min-height: 40px;
    margin-top: 22px;
    border: none;
    border-radius: 5px;
    padding: 0 18px;
    cursor: pointer;
    background: #1f5f8b;
    color: #fff;
    font-family: inherit;
    font-size: 13px;
}


/* Conversation */

.ticket-message {
    border: 1px solid #dddddd;
    border-radius: 7px;
    padding: 13px 15px;
    margin-bottom: 12px;
}

.ticket-message:last-child {
    margin-bottom: 0;
}

.ticket-message-admin {
    background: #f4f8fc;
}

.ticket-message-user {
    background: #fafafa;
}

.ticket-message-header {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 8px;
    font-size: 12px;
    color: #666;
}

.ticket-message-sender {
    font-weight: 700;
    color: #333;
}

.ticket-message-body {
    white-space: pre-wrap;
    line-height: 1.9;
    font-size: 13px;
    color: #333;
}


/* Forms */

.ticket-response-form textarea {
    width: 100%;
    min-height: 130px;
    box-sizing: border-box;
    resize: vertical;
    border: 1px solid #cccccc;
    border-radius: 6px;
    padding: 10px 12px;
    font-family: inherit;
    font-size: 13px;
    line-height: 1.8;
}

.ticket-response-form button {
    margin-top: 10px;
    min-height: 40px;
    border: none;
    border-radius: 5px;
    padding: 0 20px;
    cursor: pointer;
    font-family: inherit;
    font-size: 13px;
    color: #fff;
    background: #1f5f8b;
}

.ticket-internal-form button {
    background: #7b5a00;
}


/* Empty */

.ticket-empty {
    color: #777;
    text-align: center;
    padding: 30px 15px;
    font-size: 13px;
}


/* History */

.ticket-history {
    width: 100%;
    border-collapse: collapse;
}

.ticket-history th {
    background: #f7f7f7;
    font-size: 12px;
    padding: 10px;
    border-bottom: 1px solid #ddd;
    text-align: right;
}

.ticket-history td {
    padding: 10px;
    border-bottom: 1px solid #eee;
    font-size: 12px;
}

.ticket-history tr:last-child td {
    border-bottom: none;
}


/* Attachments */

.ticket-attachments {
    margin: 0;
    padding: 0;
    list-style: none;
}

.ticket-attachments li {
    padding: 9px 0;
    border-bottom: 1px solid #eeeeee;
    font-size: 13px;
}

.ticket-attachments li:last-child {
    border-bottom: none;
}

.ticket-attachment-name {
    font-weight: 600;
}


/* Buttons */

.ticket-back {
    display: inline-block;
    margin-bottom: 18px;
    padding: 8px 14px;
    border: 1px solid #cccccc;
    border-radius: 5px;
    background: #f5f5f5;
    color: #444;
    text-decoration: none;
    font-size: 13px;
}


/* Responsive */

@media (max-width: 1000px) {

    .ticket-info-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .ticket-management-grid {
        grid-template-columns: 1fr;
    }

}

@media (max-width: 700px) {

    .ticket-main-header {
        grid-template-columns: 1fr;
    }

    .ticket-info-grid {
        grid-template-columns: 1fr;
    }

    .ticket-message-header {
        flex-direction: column;
        gap: 5px;
    }

}

</style>


<div class="ticket-manage">

    <a
        href="tickets.php"
        class="ticket-back"
    >
        ← بازگشت به لیست درخواست‌ها
    </a>


    <div class="ticket-manage-title">

        <h1>
            🎫 مدیریت درخواست
        </h1>

        <p>
            مشاهده و مدیریت کامل درخواست پشتیبانی
        </p>

    </div>


    <?php if ($action_error !== ''): ?>

        <div class="ticket-action-error">

            <?php
            echo htmlspecialchars($action_error);
            ?>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         Main Ticket Header
         ===================================================== -->

    <div class="ticket-box">

        <div class="ticket-box-body">

            <div class="ticket-main-header">

                <div>

                    <div class="ticket-tracking">

                        <?php
                        echo htmlspecialchars(
                            $ticket['tracking_number']
                        );
                        ?>

                    </div>

                    <div class="ticket-subject">

                        <?php
                        echo htmlspecialchars(
                            $ticket['subject']
                        );
                        ?>

                    </div>

                </div>


                <div class="ticket-header-badges">

                    <?php
                    $statusClass =
                        'status-' . $ticket['status'];

                    $statusText =
                        isset(
                            $statusLabels[$ticket['status']]
                        )
                            ? $statusLabels[$ticket['status']]
                            : $ticket['status'];
                    ?>

                    <span
                        class="ticket-badge <?php echo $statusClass; ?>"
                    >
                        <?php
                        echo htmlspecialchars($statusText);
                        ?>
                    </span>


                    <?php
                    $priorityClass =
                        'priority-' . $ticket['priority'];

                    $priorityText =
                        isset(
                            $priorityLabels[$ticket['priority']]
                        )
                            ? $priorityLabels[$ticket['priority']]
                            : $ticket['priority'];
                    ?>

                    <span
                        class="ticket-badge <?php echo $priorityClass; ?>"
                    >
                        <?php
                        echo htmlspecialchars($priorityText);
                        ?>
                    </span>

                </div>

            </div>

        </div>

    </div>


    <!-- =====================================================
         Ticket Information
         ===================================================== -->

    <div class="ticket-box">

        <div class="ticket-box-title">
            اطلاعات درخواست
        </div>

        <div class="ticket-box-body">

            <div class="ticket-info-grid">


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        درخواست‌کننده
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo htmlspecialchars(
                            $ticket['fullname']
                        );
                        ?>

                        <br>

                        <small>
                            <?php
                            echo htmlspecialchars(
                                $ticket['requester_username']
                            );
                            ?>
                        </small>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        کد پرسنلی
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo !empty($ticket['personnel_code'])
                            ? htmlspecialchars(
                                $ticket['personnel_code']
                            )
                            : '-';
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        واحد
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo isset(
                            $departmentLabels[$ticket['department']]
                        )
                            ? htmlspecialchars(
                                $departmentLabels[$ticket['department']]
                            )
                            : htmlspecialchars(
                                $ticket['department']
                            );
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        تلفن
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo !empty($ticket['phone'])
                            ? htmlspecialchars(
                                $ticket['phone']
                            )
                            : '-';
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        سیستم مرتبط
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo !empty($ticket['related_system'])
                            ? htmlspecialchars(
                                $ticket['related_system']
                            )
                            : '-';
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        محل
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo !empty($ticket['location'])
                            ? htmlspecialchars(
                                $ticket['location']
                            )
                            : '-';
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        تجهیز / دارایی
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo !empty($ticket['asset'])
                            ? htmlspecialchars(
                                $ticket['asset']
                            )
                            : '-';
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        Hostname
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo !empty($ticket['hostname'])
                            ? htmlspecialchars(
                                $ticket['hostname']
                            )
                            : '-';
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        IP Address
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo !empty($ticket['ip_address'])
                            ? htmlspecialchars(
                                $ticket['ip_address']
                            )
                            : '-';
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        تاریخ ثبت
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo htmlspecialchars(
                            jalaliDate(
                                $ticket['created_at']
                            )
                        );
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        تخصیص
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo !empty($ticket['assigned_username'])
                            ? htmlspecialchars(
                                $ticket['assigned_username']
                            )
                            : 'تخصیص داده نشده';
                        ?>

                    </div>

                </div>


                <div class="ticket-info-item">

                    <div class="ticket-info-label">
                        آخرین بروزرسانی
                    </div>

                    <div class="ticket-info-value">

                        <?php
                        echo htmlspecialchars(
                            jalaliDate(
                                $ticket['updated_at']
                            )
                        );
                        ?>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- =====================================================
         Request Types
         ===================================================== -->

    <div class="ticket-box">

        <div class="ticket-box-title">
            نوع درخواست
        </div>

        <div class="ticket-box-body">

            <?php if (!empty($requestTypes)): ?>

                <?php foreach ($requestTypes as $type): ?>

                    <span class="ticket-badge status-new">
                        <?php
                        echo htmlspecialchars($type);
                        ?>
                    </span>

                <?php endforeach; ?>

            <?php else: ?>

                <span style="color:#777;">
                    ثبت نشده
                </span>

            <?php endif; ?>

        </div>

    </div>


    <!-- =====================================================
         Description
         ===================================================== -->

    <div class="ticket-box">

        <div class="ticket-box-title">
            شرح درخواست
        </div>

        <div class="ticket-box-body">

            <div class="ticket-description">

                <?php
                echo htmlspecialchars(
                    $ticket['description']
                );
                ?>

            </div>

        </div>

    </div>


    <!-- =====================================================
         Management
         ===================================================== -->

    <div
        class="ticket-box"
        id="management"
    >

        <div class="ticket-box-title">
            مدیریت درخواست
        </div>

        <div class="ticket-box-body">

            <div class="ticket-management-grid">


                <!-- Status -->

                <form
                    method="post"
                    class="ticket-management-item"
                >

                    <input
                        type="hidden"
                        name="action"
                        value="change_status"
                    >

                    <label>
                        وضعیت
                    </label>

                    <select name="status">

                        <?php foreach ($statusLabels as $key => $label): ?>

                            <option
                                value="<?php echo htmlspecialchars($key); ?>"
                                <?php
                                echo ($ticket['status'] === $key)
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                <?php
                                echo htmlspecialchars($label);
                                ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <button type="submit">
                        ذخیره وضعیت
                    </button>

                </form>


                <!-- Priority -->

                <form
                    method="post"
                    class="ticket-management-item"
                >

                    <input
                        type="hidden"
                        name="action"
                        value="change_priority"
                    >

                    <label>
                        اولویت
                    </label>

                    <select name="priority">

                        <?php foreach ($priorityLabels as $key => $label): ?>

                            <option
                                value="<?php echo htmlspecialchars($key); ?>"
                                <?php
                                echo ($ticket['priority'] === $key)
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                <?php
                                echo htmlspecialchars($label);
                                ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <button type="submit">
                        ذخیره اولویت
                    </button>

                </form>


                <!-- Assignment -->

                <form
                    method="post"
                    class="ticket-management-item"
                >

                    <input
                        type="hidden"
                        name="action"
                        value="assign_ticket"
                    >

                    <label>
                        تخصیص به کارشناس
                    </label>

                    <select name="assigned_to">

                        <option value="0">
                            بدون تخصیص
                        </option>

                        <?php foreach ($admins as $admin): ?>

                            <option
                                value="<?php echo (int)$admin['id']; ?>"
                                <?php
                                echo (
                                    (int)$ticket['assigned_to']
                                    ===
                                    (int)$admin['id']
                                )
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                <?php
                                echo htmlspecialchars(
                                    $admin['username']
                                );
                                ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <button type="submit">
                        ذخیره تخصیص
                    </button>

                </form>


            </div>

        </div>

    </div>


    <!-- =====================================================
         Conversation
         ===================================================== -->

    <div
        class="ticket-box"
        id="conversation"
    >

        <div class="ticket-box-title">
            💬 گفتگو با کاربر
        </div>

        <div class="ticket-box-body">


            <?php if (empty($conversation)): ?>

                <div class="ticket-empty">
                    هنوز پیامی در گفتگو ثبت نشده است.
                </div>

            <?php else: ?>

                <?php foreach ($conversation as $message): ?>

                    <div
                        class="ticket-message ticket-message-admin"
                    >

                        <div class="ticket-message-header">

                            <span class="ticket-message-sender">

                                <?php
                                if (
                                    !empty(
                                        $message['sender_admin_id']
                                    )
                                ) {
                                    echo 'کارشناس - '
                                        . htmlspecialchars(
                                            $message['sender_username']
                                        );
                                } else {
                                    echo 'کاربر - '
                                        . htmlspecialchars(
                                            $message['sender_username']
                                        );
                                }
                                ?>

                            </span>

                            <span>

                                <?php
                                echo htmlspecialchars(
                                    jalaliDate(
                                        $message['created_at']
                                    )
                                );
                                ?>

                            </span>

                        </div>

                        <div class="ticket-message-body">

                            <?php
                            echo htmlspecialchars(
                                $message['message']
                            );
                            ?>

                        </div>

                    </div>

                <?php endforeach; ?>

            <?php endif; ?>


            <form
                method="post"
                class="ticket-response-form"
                style="margin-top:18px;"
            >

                <input
                    type="hidden"
                    name="action"
                    value="user_reply"
                >

                <textarea
                    name="message"
                    placeholder="پاسخ قابل مشاهده برای کاربر را بنویسید..."
                    required
                ></textarea>

                <button type="submit">
                    ارسال پاسخ برای کاربر
                </button>

            </form>

        </div>

    </div>


    <!-- =====================================================
         Internal Notes
         ===================================================== -->

    <div
        class="ticket-box"
        id="internal-notes"
    >

        <div class="ticket-box-title">
            🔒 یادداشت‌های داخلی IT
        </div>

        <div class="ticket-box-body">


            <?php if (empty($internalNotes)): ?>

                <div class="ticket-empty">
                    هنوز یادداشت داخلی ثبت نشده است.
                </div>

            <?php else: ?>

                <?php foreach ($internalNotes as $note): ?>

                    <div
                        class="ticket-message"
                        style="background:#fffaf0;"
                    >

                        <div class="ticket-message-header">

                            <span class="ticket-message-sender">

                                <?php
                                echo htmlspecialchars(
                                    $note['sender_username']
                                );
                                ?>

                            </span>

                            <span>

                                <?php
                                echo htmlspecialchars(
                                    jalaliDate(
                                        $note['created_at']
                                    )
                                );
                                ?>

                            </span>

                        </div>

                        <div class="ticket-message-body">

                            <?php
                            echo htmlspecialchars(
                                $note['message']
                            );
                            ?>

                        </div>

                    </div>

                <?php endforeach; ?>

            <?php endif; ?>


            <form
                method="post"
                class="ticket-response-form ticket-internal-form"
                style="margin-top:18px;"
            >

                <input
                    type="hidden"
                    name="action"
                    value="internal_note"
                >

                <textarea
                    name="message"
                    placeholder="یادداشت داخلی برای سایر کارشناسان IT..."
                    required
                ></textarea>

                <button type="submit">
                    ثبت یادداشت داخلی
                </button>

            </form>

        </div>

    </div>


    <!-- =====================================================
         Status History
         ===================================================== -->

    <div class="ticket-box">

        <div class="ticket-box-title">
            🕘 تاریخچه وضعیت
        </div>

        <div class="ticket-box-body">

            <?php if (empty($statusHistory)): ?>

                <div class="ticket-empty">
                    تاریخچه‌ای ثبت نشده است.
                </div>

            <?php else: ?>

                <table class="ticket-history">

                    <thead>

                        <tr>

                            <th>
                                وضعیت قبلی
                            </th>

                            <th>
                                وضعیت جدید
                            </th>

                            <th>
                                تغییر توسط
                            </th>

                            <th>
                                تاریخ
                            </th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php foreach ($statusHistory as $history): ?>

                        <tr>

                            <td>

                                <?php
                                echo !empty(
                                    $history['old_status']
                                )
                                    ? htmlspecialchars(
                                        isset(
                                            $statusLabels[
                                                $history['old_status']
                                            ]
                                        )
                                            ? $statusLabels[
                                                $history['old_status']
                                            ]
                                            : $history['old_status']
                                    )
                                    : '-';
                                ?>

                            </td>

                            <td>

                                <?php
                                echo htmlspecialchars(
                                    isset(
                                        $statusLabels[
                                            $history['new_status']
                                        ]
                                    )
                                        ? $statusLabels[
                                            $history['new_status']
                                        ]
                                        : $history['new_status']
                                );
                                ?>

                            </td>

                            <td>

                                <?php
                                echo !empty(
                                    $history['changed_by_username']
                                )
                                    ? htmlspecialchars(
                                        $history[
                                            'changed_by_username'
                                        ]
                                    )
                                    : '-';
                                ?>

                            </td>

                            <td>

                                <?php
                                echo htmlspecialchars(
                                    jalaliDate(
                                        $history['created_at']
                                    )
                                );
                                ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            <?php endif; ?>

        </div>

    </div>


    <!-- =====================================================
         Attachments
         ===================================================== -->

    <div class="ticket-box">

        <div class="ticket-box-title">
            📎 پیوست‌ها
        </div>

        <div class="ticket-box-body">

            <?php if (empty($attachments)): ?>

                <div class="ticket-empty">
                    فایل پیوستی برای این درخواست ثبت نشده است.
                </div>

            <?php else: ?>

                <ul class="ticket-attachments">

                    <?php foreach ($attachments as $attachment): ?>

                        <li>

                            <span class="ticket-attachment-name">

                                <?php
                                echo htmlspecialchars(
                                    $attachment['original_name']
                                );
                                ?>

                            </span>

                            <?php if (!empty($attachment['file_size'])): ?>

                                <small style="color:#777;">

                                    -
                                    <?php
                                    echo persianNumber(
                                        round(
                                            $attachment['file_size']
                                            / 1024
                                        )
                                    );
                                    ?>
                                    KB

                                </small>

                            <?php endif; ?>

                            <br>

                            <small style="color:#777;">

                                <?php
                                echo htmlspecialchars(
                                    jalaliDate(
                                        $attachment['created_at']
                                    )
                                );
                                ?>

                                <?php if (
                                    !empty(
                                        $attachment[
                                            'uploader_username'
                                        ]
                                    )
                                ): ?>

                                    -
                                    <?php
                                    echo htmlspecialchars(
                                        $attachment[
                                            'uploader_username'
                                        ]
                                    );
                                    ?>

                                <?php endif; ?>

                            </small>

                        </li>

                    <?php endforeach; ?>

                </ul>

            <?php endif; ?>

        </div>

    </div>


</div>


<?php require_once __DIR__ . '/includes/footer.php'; ?>
