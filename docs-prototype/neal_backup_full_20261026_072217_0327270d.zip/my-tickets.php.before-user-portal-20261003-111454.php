<?php

$portal_mode = true;

require_once "auth/auth.php";
require_once "config/config.php";

check_login();

$page_title = "درخواست‌های من";

$db = new PDO(
    "sqlite:" . __DIR__ . "/data/neal.db"
);

$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$admin_id = (int)$_SESSION['admin_id'];


/*
 * تبدیل تاریخ میلادی دیتابیس به تاریخ شمسی
 */
function jalaliDate($datetime)
{
    if (empty($datetime)) {
        return '---';
    }

    $timestamp = strtotime($datetime);

    if ($timestamp === false) {
        return '---';
    }

    $gy = (int)date('Y', $timestamp);
    $gm = (int)date('n', $timestamp);
    $gd = (int)date('j', $timestamp);

    $g_d_m = array(
        0,
        31,
        59,
        90,
        120,
        151,
        181,
        212,
        243,
        273,
        304,
        334
    );

    if ($gy > 1600) {
        $jy = 979;
        $gy -= 1600;
    } else {
        $jy = 0;
        $gy -= 621;
    }

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;

    $days =
        (365 * $gy)
        + (int)(($gy2 + 3) / 4)
        - (int)(($gy2 + 99) / 100)
        + (int)(($gy2 + 399) / 400)
        - 80
        + $gd
        + $g_d_m[$gm - 1];

    $jy += 33 * (int)($days / 12053);
    $days %= 12053;

    $jy += 4 * (int)($days / 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return sprintf(
        '%04d/%02d/%02d - %s',
        $jy,
        $jm,
        $jd,
        date('H:i', $timestamp)
    );
}


/*
 * اعداد فارسی
 */
function persianNumber($number)
{
    return strtr(
        (string)$number,
        array(
            '0' => '۰',
            '1' => '۱',
            '2' => '۲',
            '3' => '۳',
            '4' => '۴',
            '5' => '۵',
            '6' => '۶',
            '7' => '۷',
            '8' => '۸',
            '9' => '۹'
        )
    );
}


/*
 * وضعیت‌ها
 */
$statusLabels = array(
    'new' => 'جدید',
    'assigned' => 'تخصیص داده شده',
    'in_progress' => 'در حال بررسی',
    'waiting_user' => 'منتظر پاسخ شما',
    'resolved' => 'حل شده',
    'closed' => 'بسته شده',
    'cancelled' => 'لغو شده'
);


/*
 * اولویت‌ها
 */
$priorityLabels = array(
    'normal' => 'عادی',
    'important' => 'مهم',
    'urgent' => 'فوری',
    'critical' => 'بحرانی'
);


/*
 * آمار درخواست‌های کاربر
 */
$stmt = $db->prepare("
    SELECT
        COUNT(*) AS total,

        SUM(
            CASE
                WHEN status IN ('new', 'assigned', 'in_progress')
                THEN 1
                ELSE 0
            END
        ) AS in_progress,

        SUM(
            CASE
                WHEN status = 'waiting_user'
                THEN 1
                ELSE 0
            END
        ) AS waiting_user,

        SUM(
            CASE
                WHEN status IN ('closed', 'resolved')
                THEN 1
                ELSE 0
            END
        ) AS closed

    FROM service_requests

    WHERE requester_admin_id = ?
");

$stmt->execute(array($admin_id));

$stats = $stmt->fetch(PDO::FETCH_ASSOC);


/*
 * درخواست‌های کاربر
 */
$stmt = $db->prepare("
    SELECT
        sr.*,
        GROUP_CONCAT(rt.name, '، ') AS request_types

    FROM service_requests sr

    LEFT JOIN service_request_types srt
        ON srt.request_id = sr.id

    LEFT JOIN request_types rt
        ON rt.id = srt.request_type_id

    WHERE sr.requester_admin_id = ?

    GROUP BY sr.id

    ORDER BY sr.created_at DESC
");

$stmt->execute(array($admin_id));

$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<?php include "includes/header.php"; ?>


<div class="ticket-page">

    <!-- Page Header -->

    <div class="ticket-page-header">

        <div>

            <h1>
                درخواست‌های من
            </h1>

            <p>
                مشاهده و پیگیری درخواست‌های ثبت‌شده
            </p>

        </div>


        <a
            href="service-request.php"
            class="ticket-new-btn"
        >
            ＋ درخواست جدید
        </a>

    </div>


    <!-- Statistics -->

    <div class="ticket-stats">


        <div class="ticket-stat">

            <div class="ticket-stat-icon">
                📥
            </div>

            <div>

                <span>
                    کل درخواست‌ها
                </span>

                <strong>
                    <?php echo persianNumber((int)$stats['total']); ?>
                </strong>

            </div>

        </div>



        <div class="ticket-stat">

            <div class="ticket-stat-icon">
                🟡
            </div>

            <div>

                <span>
                    در حال بررسی
                </span>

                <strong>
                    <?php echo persianNumber((int)$stats['in_progress']); ?>
                </strong>

            </div>

        </div>



        <div class="ticket-stat">

            <div class="ticket-stat-icon">
                🔵
            </div>

            <div>

                <span>
                    منتظر پاسخ
                </span>

                <strong>
                    <?php echo persianNumber((int)$stats['waiting_user']); ?>
                </strong>

            </div>

        </div>



        <div class="ticket-stat">

            <div class="ticket-stat-icon">
                🟢
            </div>

            <div>

                <span>
                    بسته‌شده
                </span>

                <strong>
                    <?php echo persianNumber((int)$stats['closed']); ?>
                </strong>

            </div>

        </div>


    </div>


    <!-- Ticket List -->

    <div class="card ticket-list-card">


        <div class="ticket-list-header">

            <div>

                <h2>
                    لیست درخواست‌ها
                </h2>

                <span>
                    درخواست‌های ثبت‌شده توسط شما
                </span>

            </div>

        </div>



        <?php if (count($tickets) === 0): ?>


            <!-- Empty -->

            <div class="ticket-empty">

                <div class="ticket-empty-icon">
                    🎫
                </div>

                <h3>
                    هنوز درخواستی ثبت نشده است
                </h3>

                <p>
                    اگر مشکلی دارید یا به خدمات واحد فناوری اطلاعات نیاز دارید،
                    می‌توانید یک درخواست جدید ثبت کنید.
                </p>

                <a
                    href="service-request.php"
                    class="ticket-new-btn"
                >
                    ＋ ثبت درخواست جدید
                </a>

            </div>


        <?php else: ?>


            <!-- Tickets -->

            <div class="ticket-list">


                <?php foreach ($tickets as $ticket): ?>


                    <?php

                    $status = $ticket['status'];

                    $priority = $ticket['priority'];

                    $statusText =
                        isset($statusLabels[$status])
                        ? $statusLabels[$status]
                        : $status;

                    $priorityText =
                        isset($priorityLabels[$priority])
                        ? $priorityLabels[$priority]
                        : $priority;

                    ?>


                    <div class="ticket-item">


                        <!-- Ticket Header -->

                        <div class="ticket-item-header">


                            <div class="ticket-number">

                                <span>
                                    شماره پیگیری
                                </span>

                                <strong>
                                    <?php
                                    echo htmlspecialchars(
                                        $ticket['tracking_number']
                                    );
                                    ?>
                                </strong>

                            </div>


                            <div class="ticket-badges">

                                <span
                                    class="ticket-badge ticket-status-<?php echo htmlspecialchars($status); ?>"
                                >
                                    <?php
                                    echo htmlspecialchars($statusText);
                                    ?>
                                </span>


                                <span
                                    class="ticket-badge ticket-priority-<?php echo htmlspecialchars($priority); ?>"
                                >
                                    <?php
                                    echo htmlspecialchars($priorityText);
                                    ?>
                                </span>

                            </div>


                        </div>



                        <!-- Subject -->

                        <div class="ticket-subject">

                            <h3>
                                <?php
                                echo htmlspecialchars(
                                    $ticket['subject']
                                );
                                ?>
                            </h3>

                        </div>



                        <!-- Information -->

                        <div class="ticket-info-grid">


                            <div class="ticket-info-box">

                                <span>
                                    نوع درخواست
                                </span>

                                <strong>
                                    <?php
                                    echo htmlspecialchars(
                                        $ticket['request_types']
                                        ?: '---'
                                    );
                                    ?>
                                </strong>

                            </div>



                            <div class="ticket-info-box">

                                <span>
                                    تاریخ ثبت
                                </span>

                                <strong dir="ltr">

                                    <?php
                                    echo persianNumber(
                                        jalaliDate(
                                            $ticket['created_at']
                                        )
                                    );
                                    ?>

                                </strong>

                            </div>



                            <div class="ticket-info-box">

                                <span>
                                    واحد
                                </span>

                                <strong>
                                    <?php
                                    echo htmlspecialchars(
                                        $ticket['department']
                                    );
                                    ?>
                                </strong>

                            </div>


                        </div>



                        <!-- Footer -->

                        <div class="ticket-item-footer">


                            <div class="ticket-item-id">

                                <span>
                                    ثبت‌شده در سیستم
                                </span>

                                <strong>
                                    #<?php
                                    echo persianNumber(
                                        $ticket['id']
                                    );
                                    ?>
                                </strong>

                            </div>


                            <a
                                href="ticket-view.php?id=<?php echo (int)$ticket['id']; ?>"
                                class="ticket-view-btn"
                            >
                                مشاهده درخواست
                                ←
                            </a>


                        </div>


                    </div>


                <?php endforeach; ?>


            </div>


        <?php endif; ?>


    </div>


</div>



<style>


/* =========================================================
   Page
   ========================================================= */

.ticket-page {

    max-width: 1400px;

    margin: 0 auto;

}


/* =========================================================
   Header
   ========================================================= */

.ticket-page-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;

    margin-bottom: 25px;

}


.ticket-page-header h1 {

    margin: 0 0 8px 0;

}


.ticket-page-header p {

    margin: 0;

    color: #718096;

    font-size: 14px;

}


/* =========================================================
   New Ticket Button
   ========================================================= */

.ticket-new-btn {

    display: inline-block;

    background: #0b1f3a;

    color: white;

    text-decoration: none;

    padding: 11px 20px;

    border-radius: 8px;

    font-size: 14px;

    transition: .2s;

}


.ticket-new-btn:hover {

    background: #1b4965;

    transform: translateY(-1px);

}


/* =========================================================
   Statistics
   ========================================================= */

.ticket-stats {

    display: grid;

    grid-template-columns: repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 25px;

}


.ticket-stat {

    background: white;

    border: 1px solid #e9eef5;

    border-radius: 12px;

    padding: 20px;

    display: flex;

    align-items: center;

    gap: 15px;

    box-shadow: 0 3px 12px rgba(0,0,0,.04);

}


.ticket-stat-icon {

    width: 45px;

    height: 45px;

    border-radius: 10px;

    background: #f4f7fb;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 21px;

}


.ticket-stat span {

    display: block;

    color: #718096;

    font-size: 13px;

    margin-bottom: 6px;

}


.ticket-stat strong {

    display: block;

    color: #0b1f3a;

    font-size: 22px;

}


/* =========================================================
   List Card
   ========================================================= */

.ticket-list-card {

    min-height: 400px;

}


.ticket-list-header {

    border-bottom: 1px solid #edf1f5;

    padding-bottom: 18px;

    margin-bottom: 0;

}


.ticket-list-header h2 {

    margin: 0 0 6px 0;

}


.ticket-list-header span {

    color: #718096;

    font-size: 13px;

}


/* =========================================================
   Ticket List
   ========================================================= */

.ticket-list {

    padding: 20px 0 0 0;

    display: flex;

    flex-direction: column;

    gap: 18px;

}


.ticket-item {

    background: #ffffff;

    border: 1px solid #e4eaf1;

    border-radius: 14px;

    padding: 22px;

    box-shadow: 0 3px 12px rgba(0,0,0,.035);

    transition: .2s;

}


.ticket-item:hover {

    border-color: #cbd7e5;

    box-shadow: 0 6px 18px rgba(0,0,0,.06);

}


/* =========================================================
   Ticket Header
   ========================================================= */

.ticket-item-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    padding-bottom: 16px;

    border-bottom: 1px solid #edf1f5;

}


.ticket-number {

    display: flex;

    flex-direction: column;

    gap: 4px;

}


.ticket-number span {

    color: #718096;

    font-size: 12px;

}


.ticket-number strong {

    color: #0b1f3a;

    font-size: 17px;

    letter-spacing: .3px;

}


/* =========================================================
   Badges
   ========================================================= */

.ticket-badges {

    display: flex;

    align-items: center;

    gap: 8px;

    flex-wrap: wrap;

}


.ticket-badge {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    padding: 6px 11px;

    border-radius: 20px;

    font-size: 12px;

    font-weight: 600;

    white-space: nowrap;

}


/* Status */

.ticket-status-new {

    background: #eaf2ff;

    color: #1d4ed8;

}


.ticket-status-assigned {

    background: #eef2ff;

    color: #4338ca;

}


.ticket-status-in_progress {

    background: #fff7db;

    color: #9a6700;

}


.ticket-status-waiting_user {

    background: #e8f5ff;

    color: #0369a1;

}


.ticket-status-resolved {

    background: #eaf8ef;

    color: #15803d;

}


.ticket-status-closed {

    background: #e8f5ed;

    color: #166534;

}


.ticket-status-cancelled {

    background: #f3f4f6;

    color: #6b7280;

}


/* Priority */

.ticket-priority-normal {

    background: #f3f4f6;

    color: #4b5563;

}


.ticket-priority-important {

    background: #fff7db;

    color: #92400e;

}


.ticket-priority-urgent {

    background: #fff0e6;

    color: #c2410c;

}


.ticket-priority-critical {

    background: #ffe8e8;

    color: #b91c1c;

}


/* =========================================================
   Subject
   ========================================================= */

.ticket-subject {

    padding: 18px 0 15px 0;

}


.ticket-subject h3 {

    margin: 0;

    color: #0b1f3a;

    font-size: 18px;

    font-weight: 700;

}


/* =========================================================
   Information Boxes
   ========================================================= */

.ticket-info-grid {

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 12px;

}


.ticket-info-box {

    background: #f8fafc;

    border: 1px solid #edf1f5;

    border-radius: 9px;

    padding: 12px 14px;

    min-height: 65px;

}


.ticket-info-box span {

    display: block;

    color: #718096;

    font-size: 11px;

    margin-bottom: 7px;

}


.ticket-info-box strong {

    display: block;

    color: #334155;

    font-size: 13px;

    line-height: 1.7;

}


/* =========================================================
   Footer
   ========================================================= */

.ticket-item-footer {

    margin-top: 18px;

    padding-top: 15px;

    border-top: 1px solid #edf1f5;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

}


.ticket-item-id {

    display: flex;

    align-items: center;

    gap: 8px;

}


.ticket-item-id span {

    color: #94a3b8;

    font-size: 11px;

}


.ticket-item-id strong {

    color: #64748b;

    font-size: 12px;

}


.ticket-view-btn {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 6px;

    background: #0b1f3a;

    color: #ffffff;

    text-decoration: none;

    padding: 9px 16px;

    border-radius: 7px;

    font-size: 12px;

    transition: .2s;

}


.ticket-view-btn:hover {

    background: #1b4965;

    transform: translateY(-1px);

}


/* =========================================================
   Empty State
   ========================================================= */

.ticket-empty {

    min-height: 330px;

    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;

    text-align: center;

    padding: 40px;

}


.ticket-empty-icon {

    width: 70px;

    height: 70px;

    border-radius: 50%;

    background: #f4f7fb;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 32px;

    margin-bottom: 18px;

}


.ticket-empty h3 {

    margin: 0 0 10px 0;

    color: #0b1f3a;

}


.ticket-empty p {

    max-width: 600px;

    color: #718096;

    line-height: 1.9;

    font-size: 13px;

    margin-bottom: 20px;

}


/* =========================================================
   Responsive
   ========================================================= */

@media (max-width: 900px) {

    .ticket-stats {

        grid-template-columns: repeat(2, 1fr);

    }

    .ticket-info-grid {

        grid-template-columns: 1fr;

    }

}


@media (max-width: 650px) {

    .ticket-page-header {

        flex-direction: column;

        align-items: stretch;

    }

    .ticket-new-btn {

        text-align: center;

    }

    .ticket-stats {

        grid-template-columns: 1fr;

    }

    .ticket-item-header {

        flex-direction: column;

        align-items: flex-start;

    }

    .ticket-item-footer {

        flex-direction: column;

        align-items: stretch;

    }

    .ticket-view-btn {

        width: 100%;

    }

}

</style>


<?php

require_once "includes/footer.php";

?>
