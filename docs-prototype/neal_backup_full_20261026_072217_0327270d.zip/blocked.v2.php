<?php

include "includes/header.php";

$file = "/usr/local/etc/squid/blocked_sites.txt";

$message = "";


// Add new domain

if(isset($_POST['add'])) {

    $domain = trim($_POST['domain']);

    if($domain != "") {

        if($domain[0] != ".") {
            $domain = "." . $domain;
        }

        $sites = file(
            $file,
            FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
        );

        if(!in_array($domain, $sites)) {

            file_put_contents(
                $file,
                $domain . PHP_EOL,
                FILE_APPEND
            );

            $message = "سایت با موفقیت اضافه شد";

        } else {

            $message = "این سایت قبلاً در لیست وجود دارد";

        }

    }

}



// Delete domain

if(isset($_GET['delete'])) {

    $delete = $_GET['delete'];

    $lines = file(
        $file,
        FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
    );


    $new = array();


    foreach($lines as $line){

        if(trim($line) != trim($delete)){

            $new[] = $line;

        }

    }


    file_put_contents(
        $file,
        implode(PHP_EOL,$new) . PHP_EOL
    );


    $message = "سایت حذف شد";
    header("Location: blocked.php");
    exit;

}



// Reload Squid

if(isset($_POST['reload'])) {

    shell_exec("service squid reload");

    $message = "تنظیمات Squid با موفقیت Reload شد";
    header("Location: blocked.php");
    exit;
}



$sites = file(
    $file,
    FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
);

?>


<h1>مدیریت سایت‌های مسدود شده</h1>



<?php if($message != ""): ?>

<div class="card">

<p>
<?php echo htmlspecialchars($message); ?>
</p>

</div>

<?php endif; ?>



<div class="card">

<h2>
تعداد سایت‌های مسدود شده:
<?php echo count($sites); ?>
</h2>


<form method="post">

<input 
type="text"
name="domain"
placeholder=".example.com">


<button name="add">
افزودن سایت
</button>

</form>


</div>





<div class="card">

<h2>
اعمال تغییرات در Squid
</h2>


<form method="post">

<button name="reload">
Reload Squid
</button>

</form>


</div>





<div class="card">

<h2>
لیست سایت‌های مسدود شده
</h2>


<?php foreach($sites as $site): ?>


<p>

<?php echo htmlspecialchars($site); ?>


<a href="?delete=<?php echo urlencode($site); ?>">
حذف
</a>


</p>


<?php endforeach; ?>


</div>



<?php

include "includes/footer.php";

?>
