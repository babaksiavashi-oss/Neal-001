<?php

session_start();


/*
 * Session idle timeout
 * 1 hour = 3600 seconds
 */

$session_timeout = 3600;


/*
 * Check idle time
 */

if (
    isset($_SESSION['admin_id']) &&
    isset($_SESSION['last_activity'])
) {

    $idle_time = time() - $_SESSION['last_activity'];


    if ($idle_time >= $session_timeout) {

        session_unset();

        session_destroy();

        header("Location: /neal/login.php?timeout=1");

        exit;

    }

}


/*
 * Update last activity
 */

if (isset($_SESSION['admin_id'])) {

    $_SESSION['last_activity'] = time();

}



function check_login()
{

    if (!isset($_SESSION['admin_id'])) {

        header("Location: /neal/login.php");

        exit;

    }

}



function logout()
{

    session_unset();

    session_destroy();

}

?>
