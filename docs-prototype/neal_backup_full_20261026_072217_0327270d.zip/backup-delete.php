<?php
declare(strict_types=1);

require_once __DIR__ . '/auth/auth.php';
check_login();

header('Content-Type: application/json; charset=UTF-8');

function delete_out(bool $ok, array $data = []): never
{
    echo json_encode(array_merge(['ok'=>$ok], $data), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    delete_out(false, ['message'=>'درخواست نامعتبر است.']);
}

$csrf = (string)($_POST['csrf'] ?? '');
if (empty($_SESSION['backup_csrf']) || !hash_equals($_SESSION['backup_csrf'], $csrf)) {
    delete_out(false, ['message'=>'اعتبار امنیتی درخواست منقضی شده است.']);
}

$filename = basename((string)($_POST['file'] ?? ''));

if ($filename === '' || !preg_match('/^neal_backup_(files|database|full)_[0-9]{8}_[0-9]{6}_[A-Za-z0-9]+\.zip$/', $filename)) {
    delete_out(false, ['message'=>'نام فایل نامعتبر است.']);
}

$backupFile = '/usr/local/backups/neal/files/' . $filename;
$metaFile = '/usr/local/backups/neal/jobs/' . preg_replace('/\.zip$/i', '', $filename) . '.json';

if (!is_file($backupFile)) {
    delete_out(false, ['message'=>'فایل پشتیبان پیدا نشد.']);
}

if (!@unlink($backupFile)) {
    delete_out(false, ['message'=>'حذف فایل پشتیبان انجام نشد.']);
}

if (is_file($metaFile)) {
    @unlink($metaFile);
}

delete_out(true, ['message'=>'پشتیبان با موفقیت حذف شد.']);
