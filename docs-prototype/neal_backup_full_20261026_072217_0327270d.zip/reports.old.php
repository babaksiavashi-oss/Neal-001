<?php include "includes/header.php"; ?>

<h1>گزارش‌ها</h1>

<div class="card">

<p>
گزارش‌های SARG در این بخش نمایش داده خواهد شد.
</p>

</div>

<?php include "includes/footer.php"; ?>
