<?php

session_start();

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $db = new PDO(
        "sqlite:" . __DIR__ . "/data/neal.db"
    );

    $stmt = $db->prepare(
        "SELECT * FROM admins WHERE username=?"
    );

    $stmt->execute([
        $_POST['username']
    ]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (
        $user &&
        password_verify(
            $_POST['password'],
            $user['password']
        )
    ) {

        $_SESSION['admin_id'] = $user['id'];

        $_SESSION['username'] = $user['username'];

        $_SESSION['role'] = $user['role'];

        header("Location: /neal/");

        exit;

    } else {

        $error = "نام کاربری یا رمز عبور اشتباه است";

    }

}

?>

<!DOCTYPE html>

<html lang="fa" dir="rtl">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>NEAL Proxy Manager - Login</title>


<style>

* {
    box-sizing: border-box;
}


html,
body {

    margin: 0;

    min-height: 100%;

}


body {

    direction: rtl;

    font-family: Tahoma, Arial, sans-serif;

    background:
        linear-gradient(
            135deg,
            #f4f7fb 0%,
            #eef3f9 100%
        );

    color: #344054;

    min-height: 100vh;

    display: flex;

    flex-direction: column;

}


/* =========================================================
   Login Header
   ========================================================= */

.login-header {

    width: 100%;

    padding: 24px 40px;

    background: #ffffff;

    border-bottom: 1px solid #e4e7ec;

    display: flex;

    align-items: center;

    justify-content: center;

}


.login-header img {

    width: 220px;

    height: auto;

    object-fit: contain;

}


/* =========================================================
   Login Area
   ========================================================= */

.login-wrapper {

    flex: 1;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 40px 20px;

}


.login {

    width: 390px;

    max-width: 100%;

    background: #ffffff;

    padding: 34px;

    border-radius: 16px;

    box-shadow:
        0 10px 30px rgba(16, 24, 40, 0.08),
        0 2px 8px rgba(16, 24, 40, 0.04);

    border: 1px solid #eaecf0;

}


/* =========================================================
   Login Title
   ========================================================= */

.login-title {

    text-align: center;

    margin-bottom: 28px;

}


.login-title h1 {

    margin: 0;

    color: #0b1f3a;

    font-size: 22px;

    font-weight: 700;

}


.login-title span {

    display: block;

    margin-top: 7px;

    color: #667085;

    font-size: 12px;

}


/* =========================================================
   Form
   ========================================================= */

.form-group {

    margin-bottom: 16px;

}


.form-group label {

    display: block;

    margin-bottom: 7px;

    color: #344054;

    font-size: 12px;

    font-weight: 600;

}


input {

    width: 100%;

    padding: 12px 13px;

    border: 1px solid #d0d5dd;

    border-radius: 8px;

    background: #ffffff;

    color: #101828;

    font-family: Tahoma, Arial, sans-serif;

    font-size: 13px;

    outline: none;

    transition:
        border-color .15s ease,
        box-shadow .15s ease;

}


input:focus {

    border-color: #0b1f3a;

    box-shadow:
        0 0 0 3px rgba(11, 31, 58, 0.08);

}


input::placeholder {

    color: #98a2b3;

}


/* =========================================================
   Login Button
   ========================================================= */

button {

    width: 100%;

    margin-top: 8px;

    padding: 12px;

    background: #0b1f3a;

    color: #ffffff;

    border: 0;

    border-radius: 8px;

    font-family: Tahoma, Arial, sans-serif;

    font-size: 13px;

    font-weight: 600;

    cursor: pointer;

    transition:
        background .15s ease,
        transform .1s ease;

}


button:hover {

    background: #16365f;

}


button:active {

    transform: translateY(1px);

}


/* =========================================================
   Error
   ========================================================= */

.error {

    margin: 0 0 18px;

    padding: 10px 12px;

    border-radius: 8px;

    background: #fef3f2;

    border: 1px solid #fecdca;

    color: #b42318;

    font-size: 12px;

    text-align: center;

}


/* =========================================================
   Login Footer
   ========================================================= */

.login-footer {

    padding: 18px 20px;

    background: #ffffff;

    border-top: 1px solid #e4e7ec;

    text-align: center;

    direction: ltr;

}


.login-footer strong {

    display: block;

    color: #344054;

    font-size: 11px;

    margin-bottom: 4px;

}


.login-footer span {

    display: block;

    color: #667085;

    font-size: 10px;

    margin-bottom: 3px;

}


.login-footer small {

    display: block;

    color: #98a2b3;

    font-size: 9px;

}


/* =========================================================
   Responsive
   ========================================================= */

@media (max-width: 600px) {

    .login-header {

        padding: 18px;

    }


    .login-header img {
        width: 180px;
        height: auto;
    }


    .login {

        padding: 26px 22px;

    }

}

</style>

</head>


<body>


<!-- =========================================================
     Login Header
     ========================================================= -->

<header class="login-header">

    <img
        src="/neal/images/logo.png"
        alt="Neal Pharmed"
    >

</header>


<!-- =========================================================
     Login
     ========================================================= -->

<main class="login-wrapper">

    <div class="login">


        <div class="login-title">

            <h1>
                NEAL Proxy Manager
            </h1>

            <span>
                Squid Proxy Management System
            </span>

        </div>


        <?php if ($error != ""): ?>

            <div class="error">

                <?php
                echo htmlspecialchars($error);
                ?>

            </div>

        <?php endif; ?>


        <form method="post">


            <div class="form-group">

                <label for="username">
                    نام کاربری
                </label>

                <input
                    type="text"
                    id="username"
                    name="username"
                    placeholder="نام کاربری خود را وارد کنید"
                    autocomplete="username"
                    required
                >

            </div>


            <div class="form-group">

                <label for="password">
                    رمز عبور
                </label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="رمز عبور خود را وارد کنید"
                    autocomplete="current-password"
                    required
                >

            </div>


            <button type="submit">

                ورود به سامانه

            </button>


        </form>


    </div>

</main>


<!-- =========================================================
     Copyright
     ========================================================= -->

<footer class="login-footer">

    <strong>
        NEAL Proxy Manager
    </strong>

    <span>
        Neal Pharmed Pharmaceutical Company
    </span>

    <small>
        © <?php echo date("Y"); ?> Neal Pharmed Pharmaceutical Company.
        All rights reserved.
    </small>

</footer>


</body>

</html>
