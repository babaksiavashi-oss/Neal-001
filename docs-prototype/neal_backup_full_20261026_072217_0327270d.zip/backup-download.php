<?php
declare(strict_types=1);

require_once __DIR__ . '/auth/auth.php';
check_login();

$filename = basename((string)($_GET['file'] ?? ''));

if ($filename === '' || !preg_match('/^neal_backup_(files|database|full)_[0-9]{8}_[0-9]{6}_[A-Za-z0-9]+\.zip$/', $filename)) {
    http_response_code(400);
    exit('Invalid backup file.');
}

$backupFile = '/usr/local/backups/neal/files/' . $filename;
$metaFile = '/usr/local/backups/neal/jobs/' . preg_replace('/\.zip$/i', '', $filename) . '.json';

if (!is_file($backupFile) || !is_readable($backupFile)) {
    http_response_code(404);
    exit('Backup file not found.');
}

if (is_file($metaFile)) {
    $meta = json_decode((string)@file_get_contents($metaFile), true);
    if (is_array($meta) && ($meta['status'] ?? '') !== 'success') {
        http_response_code(403);
        exit('Backup is not ready.');
    }
}

$size = (int)(@filesize($backupFile) ?: 0);

header('Content-Type: application/zip');
header('Content-Length: ' . $size);
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, no-cache, must-revalidate');

$fp = @fopen($backupFile, 'rb');
if (!$fp) {
    http_response_code(500);
    exit('Unable to open backup.');
}

while (!feof($fp)) {
    echo fread($fp, 1024 * 1024);
    flush();
}
fclose($fp);
exit;
