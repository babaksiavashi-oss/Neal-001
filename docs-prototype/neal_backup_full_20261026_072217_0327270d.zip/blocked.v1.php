<?php

include "includes/header.php";

$file = "/usr/local/etc/squid/blocked_sites.txt";


// Add new domain

if(isset($_POST['add'])) {

    $domain = trim($_POST['domain']);

    if($domain != "") {

        if($domain[0] != ".") {
            $domain = "." . $domain;
        }

        file_put_contents(
            $file,
            $domain . PHP_EOL,
            FILE_APPEND
        );

    }

}


// Delete domain

if(isset($_GET['delete'])) {

    $delete = $_GET['delete'];

    $lines = file(
        $file,
        FILE_IGNORE_NEW_LINES
    );


    $new = array();


    foreach($lines as $line){

        if(trim($line) != trim($delete)){

            $new[] = $line;

        }

    }


    file_put_contents(
        $file,
        implode(PHP_EOL,$new) . PHP_EOL
    );

}


$sites = file(
    $file,
    FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
);

?>


<h1>مدیریت سایت‌های مسدود شده</h1>


<div class="card">

<h2>
تعداد سایت‌های مسدود شده:
<?php echo count($sites); ?>
</h2>


<form method="post">

<input 
type="text"
name="domain"
placeholder=".example.com">


<button name="add">
افزودن
</button>

</form>

</div>



<div class="card">

<h2>لیست سایت‌ها</h2>


<?php foreach($sites as $site): ?>

<p>

<?php echo htmlspecialchars($site); ?>

<a href="?delete=<?php echo urlencode($site); ?>">
حذف
</a>

</p>


<?php endforeach; ?>


</div>


<?php

include "includes/footer.php";

?>
