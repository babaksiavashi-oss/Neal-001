<?php

include "includes/header.php";

?>

<h1>داشبورد</h1>

<div class="card">

<h2>به پنل مدیریت پروکسی شرکت خوش آمدید</h2>

<p>

این پنل برای مدیریت Squid Proxy طراحی شده است.

</p>

</div>

<?php

include "includes/footer.php";

?>
