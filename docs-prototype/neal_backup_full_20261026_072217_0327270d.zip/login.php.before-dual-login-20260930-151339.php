<?php

session_start();


/*
 * =========================================================
 * NEAL Proxy Manager
 * Login
 * =========================================================
 */

$error = "";

$success = "";


/*
 * =========================================================
 * Already Logged In
 * =========================================================
 */

if (isset($_SESSION['admin_id'])) {

    header("Location: /neal/");

    exit;

}


if (isset($_SESSION['user_id'])) {

    header("Location: /neal/portal.php");

    exit;

}


/*
 * =========================================================
 * Timeout Message
 * =========================================================
 */

if (isset($_GET['timeout'])) {

    $success = "به دلیل عدم فعالیت، نشست شما منقضی شد. لطفاً مجدداً وارد شوید.";

}


/*
 * =========================================================
 * Login Processing
 * =========================================================
 */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $login_type = isset($_POST['login_type'])
        ? trim($_POST['login_type'])
        : "";

    $username = isset($_POST['username'])
        ? trim($_POST['username'])
        : "";

    $password = isset($_POST['password'])
        ? $_POST['password']
        : "";


    if ($username === "" || $password === "") {

        $error = "نام کاربری و رمز عبور را وارد کنید.";

    }


    elseif ($login_type === "admin") {

        /*
         * =================================================
         * Management / Expert Login
         * =================================================
         */

        $db = new PDO(
            "sqlite:" . __DIR__ . "/data/neal.db"
        );

        $db->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );


        $stmt = $db->prepare(
            "SELECT *
             FROM admins
             WHERE username = ?
             LIMIT 1"
        );


        $stmt->execute([
            $username
        ]);


        $user = $stmt->fetch(PDO::FETCH_ASSOC);


        if (
            $user &&
            password_verify(
                $password,
                $user['password']
            )
        ) {

            /*
             * جلوگیری از Session Fixation
             */

            session_regenerate_id(true);


            /*
             * پاک کردن Session اطلاعات قبلی
             */

            unset(
                $_SESSION['user_id'],
                $_SESSION['user_username'],
                $_SESSION['user_fullname'],
                $_SESSION['user_personnel_code'],
                $_SESSION['user_department'],
                $_SESSION['user_phone'],
                $_SESSION['user_last_activity']
            );


            /*
             * Admin Session
             */

            $_SESSION['admin_id'] = $user['id'];

            $_SESSION['username'] = $user['username'];

            $_SESSION['role'] = $user['role'];

            $_SESSION['last_activity'] = time();


            /*
             * Admin → Dashboard
             */

            header("Location: /neal/");

            exit;

        }


        else {

            $error = "نام کاربری یا رمز عبور مدیریت/کارشناس اشتباه است.";

        }

    }


    elseif ($login_type === "user") {

        /*
         * =================================================
         * Normal User Login
         * =================================================
         */

        $db = new PDO(
            "sqlite:" . __DIR__ . "/data/neal.db"
        );

        $db->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );


        $stmt = $db->prepare(
            "SELECT
                u.*,
                d.name AS department_name
             FROM users u
             LEFT JOIN departments d
                ON d.code = u.department
             WHERE u.username = ?
               AND u.is_active = 1
             LIMIT 1"
        );


        $stmt->execute([
            $username
        ]);


        $user = $stmt->fetch(PDO::FETCH_ASSOC);


        if (
            $user &&
            password_verify(
                $password,
                $user['password']
            )
        ) {

            /*
             * جلوگیری از Session Fixation
             */

            session_regenerate_id(true);


            /*
             * پاک کردن Session اطلاعات قبلی
             */

            unset(
                $_SESSION['admin_id'],
                $_SESSION['username'],
                $_SESSION['role'],
                $_SESSION['last_activity']
            );


            /*
             * Normal User Session
             */

            $_SESSION['user_id'] = $user['id'];

            $_SESSION['user_username'] = $user['username'];

            $_SESSION['user_fullname'] = $user['fullname'];

            $_SESSION['user_personnel_code'] =
                $user['personnel_code'];

            $_SESSION['user_department'] =
                $user['department'];

            $_SESSION['user_department_name'] =
                $user['department_name'];

            $_SESSION['user_phone'] =
                $user['phone'];

            $_SESSION['user_last_activity'] =
                time();


            /*
             * Normal User → Portal
             */

            header("Location: /neal/portal.php");

            exit;

        }


        else {

            $error = "نام کاربری یا رمز عبور کاربر اشتباه است.";

        }

    }


    else {

        $error = "نوع ورود نامعتبر است.";

    }

}

?>
<!DOCTYPE html>

<html lang="fa" dir="rtl">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>ورود به NEAL Proxy Manager</title>


<style>

* {
    box-sizing: border-box;
}


body {

    margin:0;

    min-height:100vh;

    font-family:
        Tahoma,
        Arial,
        sans-serif;

    background:
        linear-gradient(
            135deg,
            #eef3f8 0%,
            #f8fafc 50%,
            #e9eef5 100%
        );

    display:flex;

    align-items:center;

    justify-content:center;

    padding:30px;

    color:#1d2939;
}


.login-wrapper {

    width:100%;

    max-width:900px;

}


.login-header {

    text-align:center;

    margin-bottom:30px;
}


.login-header h1 {

    margin:0;

    color:#0b1f3a;

    font-size:30px;

}


.login-header p {

    margin:10px 0 0;

    color:#667085;

    font-size:14px;

}


.login-card {

    background:#ffffff;

    border-radius:22px;

    box-shadow:
        0 20px 60px
        rgba(16,24,40,.12);

    padding:30px;

}


.login-options {

    display:grid;

    grid-template-columns:
        repeat(2,minmax(0,1fr));

    gap:22px;
}


.login-option {

    border:1px solid #e4e7ec;

    border-radius:18px;

    padding:25px;

    background:
        linear-gradient(
            145deg,
            #ffffff 0%,
            #f8fafc 100%
        );

    transition:
        transform .2s ease,
        box-shadow .2s ease,
        border-color .2s ease;
}


.login-option:hover {

    transform:translateY(-3px);

    box-shadow:
        0 12px 30px
        rgba(16,24,40,.08);

    border-color:#cfd5dd;
}


.option-icon {

    width:58px;

    height:58px;

    border-radius:15px;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:28px;

    margin-bottom:16px;
}


.admin-icon {

    background:#eef4ff;
}


.user-icon {

    background:#ecfdf3;
}


.login-option h2 {

    margin:0;

    font-size:18px;

    color:#101828;
}


.login-option-description {

    margin:8px 0 20px;

    color:#667085;

    font-size:12px;

    line-height:1.8;

}


.form-group {

    margin-bottom:14px;
}


.form-group label {

    display:block;

    margin-bottom:7px;

    color:#344054;

    font-size:12px;

    font-weight:600;
}


.form-group input {

    width:100%;

    height:44px;

    border:1px solid #d0d5dd;

    border-radius:9px;

    padding:0 12px;

    font-family:inherit;

    font-size:13px;

    outline:none;

    transition:
        border-color .15s ease,
        box-shadow .15s ease;
}


.form-group input:focus {

    border-color:#5b7dbb;

    box-shadow:
        0 0 0 3px
        rgba(91,125,187,.12);
}


.login-button {

    width:100%;

    height:44px;

    border:none;

    border-radius:9px;

    color:#ffffff;

    font-family:inherit;

    font-size:13px;

    font-weight:700;

    cursor:pointer;

    margin-top:5px;

    transition:
        transform .15s ease,
        opacity .15s ease;
}


.login-button:hover {

    transform:translateY(-1px);

    opacity:.94;
}


.admin-button {

    background:#3159a6;
}


.user-button {

    background:#16805b;
}


.alert {

    border-radius:10px;

    padding:12px 15px;

    margin-bottom:20px;

    font-size:12px;

    line-height:1.8;
}


.alert-error {

    background:#fef3f2;

    color:#b42318;

    border:1px solid #fecdca;
}


.alert-success {

    background:#ecfdf3;

    color:#027a48;

    border:1px solid #abefc6;
}


.login-footer {

    text-align:center;

    margin-top:20px;

    color:#98a2b3;

    font-size:11px;
}


@media (max-width:700px) {

    body {

        padding:15px;

    }


    .login-card {

        padding:20px;

    }


    .login-options {

        grid-template-columns:1fr;

    }


    .login-header h1 {

        font-size:24px;

    }

}

</style>

</head>


<body>


<div class="login-wrapper">


    <div class="login-header">

        <h1>
            NEAL Proxy Manager
        </h1>

        <p>
            سامانه مدیریت و پشتیبانی فناوری اطلاعات
        </p>

    </div>


    <div class="login-card">


        <?php if ($error !== ""): ?>

            <div class="alert alert-error">

                <?php
                echo htmlspecialchars(
                    $error,
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>

            </div>

        <?php endif; ?>


        <?php if ($success !== ""): ?>

            <div class="alert alert-success">

                <?php
                echo htmlspecialchars(
                    $success,
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>

            </div>

        <?php endif; ?>


        <div class="login-options">


            <!-- =================================================
                 MANAGEMENT / EXPERT
                 ================================================= -->

            <div class="login-option">

                <div class="option-icon admin-icon">
                    🛠️
                </div>

                <h2>
                    مدیریت / کارشناسان
                </h2>

                <div class="login-option-description">

                    ورود مدیران و کارشناسان واحد فناوری اطلاعات
                    برای مدیریت درخواست‌ها، Proxy، کاربران و گزارش‌ها.

                </div>


                <form
                    method="POST"
                    action=""
                >

                    <input
                        type="hidden"
                        name="login_type"
                        value="admin"
                    >


                    <div class="form-group">

                        <label>
                            نام کاربری
                        </label>

                        <input
                            type="text"
                            name="username"
                            autocomplete="username"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            رمز عبور
                        </label>

                        <input
                            type="password"
                            name="password"
                            autocomplete="current-password"
                            required
                        >

                    </div>


                    <button
                        type="submit"
                        class="login-button admin-button"
                    >
                        ورود به بخش مدیریت
                    </button>

                </form>

            </div>


            <!-- =================================================
                 NORMAL USER
                 ================================================= -->

            <div class="login-option">

                <div class="option-icon user-icon">
                    👤
                </div>

                <h2>
                    کاربران
                </h2>

                <div class="login-option-description">

                    ورود کاربران سازمان برای ثبت درخواست،
                    پیگیری درخواست‌های ثبت‌شده و مشاهده پاسخ کارشناسان.

                </div>


                <form
                    method="POST"
                    action=""
                >

                    <input
                        type="hidden"
                        name="login_type"
                        value="user"
                    >


                    <div class="form-group">

                        <label>
                            نام کاربری
                        </label>

                        <input
                            type="text"
                            name="username"
                            autocomplete="username"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            رمز عبور
                        </label>

                        <input
                            type="password"
                            name="password"
                            autocomplete="current-password"
                            required
                        >

                    </div>


                    <button
                        type="submit"
                        class="login-button user-button"
                    >
                        ورود به پورتال کاربران
                    </button>

                </form>

            </div>


        </div>


        <div class="login-footer">

            NEAL Pharmed Pharmaceutical Company

        </div>


    </div>


</div>


</body>

</html>
