<?php

require_once "auth/auth.php";

check_login();

$page_title = "Users";

$message = "";
$message_type = "";


/* Database */

$db = new PDO(
    "sqlite:" . __DIR__ . "/data/neal.db"
);

$db->setAttribute(
    PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION
);


/* Add User */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm_password = $_POST["confirm_password"] ?? "";
    $role = $_POST["role"] ?? "admin";


    if ($username === "" || $password === "" || $confirm_password === "") {

        $message = "لطفاً تمام فیلدها را تکمیل کنید.";
        $message_type = "error";

    } elseif ($password !== $confirm_password) {

        $message = "رمز عبور و تکرار رمز عبور یکسان نیستند.";
        $message_type = "error";

    } elseif (strlen($password) < 6) {

        $message = "رمز عبور باید حداقل ۶ کاراکتر باشد.";
        $message_type = "error";

    } else {

        $check = $db->prepare(
            "SELECT id FROM admins WHERE username = ?"
        );

        $check->execute([$username]);

        if ($check->fetch()) {

            $message = "این نام کاربری قبلاً وجود دارد.";
            $message_type = "error";

        } else {

            $hashed_password = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $stmt = $db->prepare(
                "INSERT INTO admins
                (username, password, role)
                VALUES (?, ?, ?)"
            );

            $stmt->execute([
                $username,
                $hashed_password,
                $role
            ]);

            $message = "کاربر با موفقیت ایجاد شد.";
            $message_type = "success";
        }
    }
}


/* Get Users */

$stmt = $db->query(
    "SELECT id, username, role, created_at
     FROM admins
     ORDER BY id ASC"
);

$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);


include "includes/header.php";

?>


<h1>مدیریت کاربران</h1>


<?php if ($message !== ""): ?>

<div class="alert <?php echo $message_type === "success" ? "alert-success" : "alert-error"; ?>">

<?php echo htmlspecialchars($message); ?>

</div>

<?php endif; ?>


<div class="card">

<h2>➕ افزودن کاربر جدید</h2>


<form method="post">


<div class="form-group">

<label for="username">
نام کاربری
</label>

<input
    id="username"
    class="form-control"
    type="text"
    name="username"
    required
    autocomplete="off"
    placeholder="نام کاربری جدید"
>

</div>


<div class="form-group">

<label for="password">
رمز عبور
</label>

<input
    id="password"
    class="form-control"
    type="password"
    name="password"
    required
    autocomplete="new-password"
    placeholder="حداقل ۶ کاراکتر"
>

</div>


<div class="form-group">

<label for="confirm_password">
تکرار رمز عبور
</label>

<input
    id="confirm_password"
    class="form-control"
    type="password"
    name="confirm_password"
    required
    autocomplete="new-password"
    placeholder="تکرار رمز عبور"
>

</div>


<div class="form-group">

<label for="role">
سطح دسترسی
</label>

<select
    id="role"
    class="form-control"
    name="role"
>

<option value="admin">
Admin
</option>

</select>

</div>


<button
    type="submit"
    class="btn btn-primary"
>

➕ ایجاد کاربر

</button>


</form>

</div>


<div class="card">

<h2>👥 کاربران پنل</h2>


<table class="data-table">

<thead>

<tr>

<th>شناسه</th>

<th>نام کاربری</th>

<th>سطح دسترسی</th>

<th>تاریخ ایجاد</th>

</tr>

</thead>


<tbody>

<?php foreach ($admins as $admin): ?>

<tr>

<td>
<?php echo htmlspecialchars($admin["id"]); ?>
</td>

<td>
<?php echo htmlspecialchars($admin["username"]); ?>
</td>

<td>

<span class="badge badge-admin">

<?php echo htmlspecialchars($admin["role"]); ?>

</span>

</td>

<td>
<?php echo htmlspecialchars($admin["created_at"]); ?>
</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>


<?php include "includes/footer.php"; ?>
