<?php

require_once "auth/auth.php";

check_login();

$page_title = "مدیریت کاربران";

$message = "";
$message_type = "";


/* =========================================================
 * Database
 * ========================================================= */

$db = new PDO(
    "sqlite:" . __DIR__ . "/data/neal.db"
);

$db->setAttribute(
    PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION
);


/* =========================================================
 * Departments
 * ========================================================= */

$departments = [
    "management" => "واحد مدیریت",
    "regulatory" => "واحد مسئول فنی و رگولاتوری",
    "administrative" => "واحد اداری",
    "engineering" => "واحد فنی مهندسی",
    "finance" => "واحد مالی",
    "planning" => "واحد برنامه ریزی و انبار",
    "quality" => "واحد آزمایشگاه کنترل کیفیت",
    "commercial" => "واحد بازرگانی",
    "production" => "واحد تولید",
    "hse" => "واحد ایمنی و بهداشت"
];


/* =========================================================
 * POST Actions
 * ========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "";


    /* =====================================================
     * Add Admin / Expert
     * ===================================================== */

    if ($action === "add_admin") {

        $username = trim($_POST["admin_username"] ?? "");
        $password = $_POST["admin_password"] ?? "";
        $confirm_password = $_POST["admin_confirm_password"] ?? "";
        $role = $_POST["admin_role"] ?? "admin";


        if (
            $username === ""
            ||
            $password === ""
            ||
            $confirm_password === ""
        ) {

            $message =
                "لطفاً تمام فیلدهای حساب مدیریت / کارشناس را تکمیل کنید.";

            $message_type = "error";

        } elseif ($password !== $confirm_password) {

            $message =
                "رمز عبور و تکرار رمز عبور یکسان نیستند.";

            $message_type = "error";

        } elseif (strlen($password) < 6) {

            $message =
                "رمز عبور باید حداقل ۶ کاراکتر باشد.";

            $message_type = "error";

        } else {

            $check_admin = $db->prepare(
                "SELECT id FROM admins WHERE username = ?"
            );

            $check_admin->execute([
                $username
            ]);

            $check_user = $db->prepare(
                "SELECT id FROM users WHERE username = ?"
            );

            $check_user->execute([
                $username
            ]);


            if ($check_admin->fetch()) {

                $message =
                    "این نام کاربری قبلاً در حساب‌های مدیریت وجود دارد.";

                $message_type = "error";

            } elseif ($check_user->fetch()) {

                $message =
                    "این نام کاربری قبلاً برای یک کاربر عادی ثبت شده است.";

                $message_type = "error";

            } else {

                $hashed_password = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $stmt = $db->prepare(
                    "INSERT INTO admins
                    (username, password, role)
                    VALUES (?, ?, ?)"
                );

                $stmt->execute([
                    $username,
                    $hashed_password,
                    $role
                ]);

                $message =
                    "حساب مدیریت / کارشناس با موفقیت ایجاد شد.";

                $message_type = "success";
            }
        }
    }


    /* =====================================================
     * Add Normal User
     * ===================================================== */

    elseif ($action === "add_user") {

        $username = trim($_POST["user_username"] ?? "");
        $password = $_POST["user_password"] ?? "";
        $confirm_password = $_POST["user_confirm_password"] ?? "";

        $fullname = trim($_POST["fullname"] ?? "");
        $personnel_code = trim($_POST["personnel_code"] ?? "");
        $department = trim($_POST["department"] ?? "");
        $phone = trim($_POST["phone"] ?? "");


        if (
            $username === ""
            ||
            $password === ""
            ||
            $confirm_password === ""
            ||
            $fullname === ""
            ||
            $personnel_code === ""
            ||
            $department === ""
        ) {

            $message =
                "لطفاً تمام اطلاعات کاربر را تکمیل کنید.";

            $message_type = "error";

        } elseif (!isset($departments[$department])) {

            $message =
                "واحد / دپارتمان انتخاب‌شده معتبر نیست.";

            $message_type = "error";

        } elseif ($password !== $confirm_password) {

            $message =
                "رمز عبور و تکرار رمز عبور یکسان نیستند.";

            $message_type = "error";

        } elseif (strlen($password) < 6) {

            $message =
                "رمز عبور باید حداقل ۶ کاراکتر باشد.";

            $message_type = "error";

        } else {

            $check_admin = $db->prepare(
                "SELECT id FROM admins WHERE username = ?"
            );

            $check_admin->execute([
                $username
            ]);

            $check_user = $db->prepare(
                "SELECT id FROM users WHERE username = ?"
            );

            $check_user->execute([
                $username
            ]);

            $check_personnel = $db->prepare(
                "SELECT id FROM users WHERE personnel_code = ?"
            );

            $check_personnel->execute([
                $personnel_code
            ]);


            if ($check_admin->fetch()) {

                $message =
                    "این نام کاربری قبلاً برای حساب مدیریت / کارشناس استفاده شده است.";

                $message_type = "error";

            } elseif ($check_user->fetch()) {

                $message =
                    "این نام کاربری قبلاً وجود دارد.";

                $message_type = "error";

            } elseif ($check_personnel->fetch()) {

                $message =
                    "این کد پرسنلی قبلاً برای یک کاربر ثبت شده است.";

                $message_type = "error";

            } else {

                $hashed_password = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $stmt = $db->prepare(
                    "INSERT INTO users
                    (
                        username,
                        password,
                        fullname,
                        personnel_code,
                        department,
                        phone,
                        is_active
                    )
                    VALUES (?, ?, ?, ?, ?, ?, 1)"
                );

                $stmt->execute([
                    $username,
                    $hashed_password,
                    $fullname,
                    $personnel_code,
                    $department,
                    $phone
                ]);

                $message =
                    "کاربر عادی با موفقیت ایجاد شد.";

                $message_type = "success";
            }
        }
    }
}


/* =========================================================
 * Get Admins / Experts
 * ========================================================= */

$stmt = $db->query(
    "SELECT
        id,
        username,
        role,
        created_at
     FROM admins
     ORDER BY id ASC"
);

$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);


/* =========================================================
 * Get Normal Users
 * ========================================================= */

$stmt = $db->query(
    "SELECT
        id,
        username,
        fullname,
        personnel_code,
        department,
        phone,
        is_active,
        created_at
     FROM users
     ORDER BY id ASC"
);

$users = $stmt->fetchAll(PDO::FETCH_ASSOC);


/* =========================================================
 * Header
 * ========================================================= */

include "includes/header.php";

?>

<h1>مدیریت کاربران</h1>


<?php if ($message !== ""): ?>

<div class="alert <?php echo $message_type === "success"
    ? "alert-success"
    : "alert-error"; ?>">

    <?php echo htmlspecialchars($message); ?>

</div>

<?php endif; ?>


<!-- =======================================================
     Management / Experts
======================================================== -->

<div class="card">

    <h2>👨‍💼 مدیریت و کارشناسان</h2>

    <p style="color:#666; margin-bottom:20px;">
        حساب‌های دسترسی به بخش مدیریت و کارشناسی سیستم.
    </p>


    <form method="post">

        <input
            type="hidden"
            name="action"
            value="add_admin"
        >


        <div class="form-group">

            <label for="admin_username">
                نام کاربری
            </label>

            <input
                id="admin_username"
                class="form-control"
                type="text"
                name="admin_username"
                required
                autocomplete="off"
                placeholder="نام کاربری مدیریت / کارشناس"
            >

        </div>


        <div class="form-group">

            <label for="admin_password">
                رمز عبور
            </label>

            <input
                id="admin_password"
                class="form-control"
                type="password"
                name="admin_password"
                required
                autocomplete="new-password"
                placeholder="حداقل ۶ کاراکتر"
            >

        </div>


        <div class="form-group">

            <label for="admin_confirm_password">
                تکرار رمز عبور
            </label>

            <input
                id="admin_confirm_password"
                class="form-control"
                type="password"
                name="admin_confirm_password"
                required
                autocomplete="new-password"
                placeholder="تکرار رمز عبور"
            >

        </div>


        <div class="form-group">

            <label for="admin_role">
                سطح دسترسی
            </label>

            <select
                id="admin_role"
                class="form-control"
                name="admin_role"
            >

                <option value="admin">
                    Admin
                </option>

            </select>

        </div>


        <button
            type="submit"
            class="btn btn-primary"
        >
            ➕ ایجاد حساب مدیریت / کارشناس
        </button>


    </form>

</div>


<div class="card">

    <h2>👥 حساب‌های مدیریت / کارشناسان</h2>


    <table class="data-table">

        <thead>

            <tr>

                <th>شناسه</th>

                <th>نام کاربری</th>

                <th>سطح دسترسی</th>

                <th>تاریخ ایجاد</th>

            </tr>

        </thead>


        <tbody>

        <?php foreach ($admins as $admin): ?>

            <tr>

                <td>
                    <?php
                    echo htmlspecialchars(
                        $admin["id"]
                    );
                    ?>
                </td>


                <td>
                    <?php
                    echo htmlspecialchars(
                        $admin["username"]
                    );
                    ?>
                </td>


                <td>

                    <span class="badge badge-admin">

                        <?php
                        echo htmlspecialchars(
                            $admin["role"]
                        );
                        ?>

                    </span>

                </td>


                <td>
                    <?php
                    echo htmlspecialchars(
                        $admin["created_at"]
                    );
                    ?>
                </td>

            </tr>

        <?php endforeach; ?>

        </tbody>

    </table>

</div>


<!-- =======================================================
     Normal Users
======================================================== -->

<div class="card">

    <h2>👤 ایجاد کاربر عادی</h2>

    <p style="color:#666; margin-bottom:20px;">
        این حساب‌ها برای ورود کاربران معمولی و ثبت و پیگیری درخواست‌های IT استفاده خواهند شد.
    </p>


    <form method="post">

        <input
            type="hidden"
            name="action"
            value="add_user"
        >


        <div class="form-group">

            <label for="user_username">
                نام کاربری
            </label>

            <input
                id="user_username"
                class="form-control"
                type="text"
                name="user_username"
                required
                autocomplete="off"
                placeholder="نام کاربری کاربر"
            >

        </div>


        <div class="form-group">

            <label for="fullname">
                نام و نام خانوادگی
            </label>

            <input
                id="fullname"
                class="form-control"
                type="text"
                name="fullname"
                required
                placeholder="نام و نام خانوادگی"
            >

        </div>


        <div class="form-group">

            <label for="personnel_code">
                کد پرسنلی
            </label>

            <input
                id="personnel_code"
                class="form-control"
                type="text"
                name="personnel_code"
                required
                placeholder="کد پرسنلی"
            >

        </div>


        <div class="form-group">

            <label for="department">
                واحد / دپارتمان
            </label>

            <select
                id="department"
                class="form-control"
                name="department"
                required
            >

                <option value="" selected disabled>
                    واحد / دپارتمان را انتخاب کنید
                </option>

                <?php foreach ($departments as $code => $name): ?>

                    <option
                        value="<?php echo htmlspecialchars($code); ?>"
                    >
                        <?php echo htmlspecialchars($name); ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="form-group">

            <label for="phone">
                شماره تماس
            </label>

            <input
                id="phone"
                class="form-control"
                type="text"
                name="phone"
                placeholder="شماره داخلی / موبایل"
            >

        </div>


        <div class="form-group">

            <label for="user_password">
                رمز عبور
            </label>

            <input
                id="user_password"
                class="form-control"
                type="password"
                name="user_password"
                required
                autocomplete="new-password"
                placeholder="حداقل ۶ کاراکتر"
            >

        </div>


        <div class="form-group">

            <label for="user_confirm_password">
                تکرار رمز عبور
            </label>

            <input
                id="user_confirm_password"
                class="form-control"
                type="password"
                name="user_confirm_password"
                required
                autocomplete="new-password"
                placeholder="تکرار رمز عبور"
            >

        </div>


        <button
            type="submit"
            class="btn btn-primary"
        >
            ➕ ایجاد کاربر عادی
        </button>


    </form>

</div>


<div class="card">

    <h2>👤 کاربران عادی</h2>


    <table class="data-table">

        <thead>

            <tr>

                <th>شناسه</th>

                <th>نام کاربری</th>

                <th>نام و نام خانوادگی</th>

                <th>کد پرسنلی</th>

                <th>واحد</th>

                <th>شماره تماس</th>

                <th>وضعیت</th>

                <th>تاریخ ایجاد</th>

            </tr>

        </thead>


        <tbody>

        <?php if (empty($users)): ?>

            <tr>

                <td
                    colspan="8"
                    style="text-align:center; color:#777;"
                >
                    هنوز کاربر عادی ایجاد نشده است.
                </td>

            </tr>

        <?php else: ?>

            <?php foreach ($users as $user): ?>

                <tr>

                    <td>
                        <?php
                        echo htmlspecialchars(
                            $user["id"]
                        );
                        ?>
                    </td>


                    <td>
                        <?php
                        echo htmlspecialchars(
                            $user["username"]
                        );
                        ?>
                    </td>


                    <td>
                        <?php
                        echo htmlspecialchars(
                            $user["fullname"]
                        );
                        ?>
                    </td>


                    <td>
                        <?php
                        echo htmlspecialchars(
                            $user["personnel_code"]
                        );
                        ?>
                    </td>


                    <td>
                        <?php
                        echo htmlspecialchars(
                            $departments[$user["department"]]
                            ?? $user["department"]
                        );
                        ?>
                    </td>


                    <td>
                        <?php
                        echo htmlspecialchars(
                            $user["phone"] ?: "-"
                        );
                        ?>
                    </td>


                    <td>

                        <?php if ((int)$user["is_active"] === 1): ?>

                            <span class="badge badge-admin">
                                فعال
                            </span>

                        <?php else: ?>

                            <span class="badge">
                                غیرفعال
                            </span>

                        <?php endif; ?>

                    </td>


                    <td>
                        <?php
                        echo htmlspecialchars(
                            $user["created_at"]
                        );
                        ?>
                    </td>

                </tr>

            <?php endforeach; ?>

        <?php endif; ?>

        </tbody>

    </table>

</div>


<?php include "includes/footer.php"; ?>
