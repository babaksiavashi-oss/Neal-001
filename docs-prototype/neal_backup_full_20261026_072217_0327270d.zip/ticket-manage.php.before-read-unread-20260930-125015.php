<?php

require_once __DIR__ . '/auth/auth.php';
require_once __DIR__ . '/config/config.php';

check_login();

$db = new PDO(
    'sqlite:' . __DIR__ . '/data/neal.db',
    null,
    null,
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]
);

$request_id = (int)($_GET['id'] ?? $_POST['request_id'] ?? 0);

if ($request_id <= 0) {
    http_response_code(400);
    exit('شناسه درخواست نامعتبر است.');
}

$current_admin_id = (int)$_SESSION['admin_id'];
$current_username = $_SESSION['username'] ?? 'کارشناس';

/*
 * ------------------------------------------------------------
 * Helpers
 * ------------------------------------------------------------
 */

function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function jalali_datetime($datetime)
{
    if (!$datetime) {
        return '-';
    }

    $timestamp = strtotime($datetime);

    if (!$timestamp) {
        return h($datetime);
    }

    $gy = (int)date('Y', $timestamp);
    $gm = (int)date('n', $timestamp);
    $gd = (int)date('j', $timestamp);

    $g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334];

    if ($gy > 1600) {
        $jy = 979;
        $gy -= 1600;
    } else {
        $jy = 0;
        $gy -= 621;
    }

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;

    $days =
        (365 * $gy)
        + (int)(($gy2 + 3) / 4)
        - (int)(($gy2 + 99) / 100)
        + (int)(($gy2 + 399) / 400)
        - 80
        + $gd
        + $g_d_m[$gm - 1];

    $jy += 33 * (int)($days / 12053);
    $days %= 12053;

    $jy += 4 * (int)($days / 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return sprintf(
        '%04d/%02d/%02d %s',
        $jy,
        $jm,
        $jd,
        date('H:i', $timestamp)
    );
}

function status_label($status)
{
    return [
        'new'          => 'جدید',
        'assigned'     => 'تخصیص داده شده',
        'in_progress'  => 'در حال بررسی',
        'waiting_user' => 'منتظر پاسخ کاربر',
        'resolved'     => 'حل شده',
        'closed'       => 'بسته شده',
        'cancelled'    => 'لغو شده'
    ][$status] ?? $status;
}

function priority_label($priority)
{
    return [
        'normal'    => 'عادی',
        'important' => 'مهم',
        'urgent'    => 'فوری',
        'critical' => 'بحرانی'
    ][$priority] ?? $priority;
}

function status_class($status)
{
    return [
        'new'          => 'status-new',
        'assigned'     => 'status-assigned',
        'in_progress'  => 'status-progress',
        'waiting_user' => 'status-waiting',
        'resolved'     => 'status-resolved',
        'closed'       => 'status-closed',
        'cancelled'    => 'status-cancelled'
    ][$status] ?? '';
}

function priority_class($priority)
{
    return [
        'normal'    => 'priority-normal',
        'important' => 'priority-important',
        'urgent'    => 'priority-urgent',
        'critical'  => 'priority-critical'
    ][$priority] ?? '';
}

/*
 * ------------------------------------------------------------
 * Load ticket
 * ------------------------------------------------------------
 */

$stmt = $db->prepare("
    SELECT
        sr.*,
        a.username AS assigned_username
    FROM service_requests sr
    LEFT JOIN admins a
        ON a.id = sr.assigned_to
    WHERE sr.id = ?
");

$stmt->execute([$request_id]);

$ticket = $stmt->fetch();

if (!$ticket) {
    http_response_code(404);
    exit('درخواست مورد نظر پیدا نشد.');
}

/*
 * ------------------------------------------------------------
 * POST actions
 * ------------------------------------------------------------
 */

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    try {

        /*
         * ----------------------------------------------------
         * Change status
         * ----------------------------------------------------
         */

        if ($action === 'change_status') {

            $new_status = trim($_POST['status'] ?? '');

            $allowed_statuses = [
                'new',
                'assigned',
                'in_progress',
                'waiting_user',
                'resolved',
                'closed',
                'cancelled'
            ];

            if (!in_array($new_status, $allowed_statuses, true)) {
                throw new RuntimeException('وضعیت انتخاب‌شده معتبر نیست.');
            }

            if ($ticket['status'] === 'closed') {
                throw new RuntimeException(
                    'درخواست بسته‌شده مستقیماً قابل تغییر وضعیت نیست.'
                );
            }

            $old_status = $ticket['status'];

            if ($old_status !== $new_status) {

                $db->beginTransaction();

                $assigned_at = $ticket['assigned_at'];
                $started_at  = $ticket['started_at'];
                $resolved_at = $ticket['resolved_at'];
                $closed_at   = $ticket['closed_at'];

                if (
                    in_array(
                        $new_status,
                        ['assigned', 'in_progress', 'waiting_user', 'resolved', 'closed'],
                        true
                    )
                    && !$assigned_at
                ) {
                    $assigned_at = date('Y-m-d H:i:s');
                }

                if (
                    in_array(
                        $new_status,
                        ['in_progress', 'waiting_user', 'resolved', 'closed'],
                        true
                    )
                    && !$started_at
                ) {
                    $started_at = date('Y-m-d H:i:s');
                }

                if (
                    in_array(
                        $new_status,
                        ['resolved', 'closed'],
                        true
                    )
                    && !$resolved_at
                ) {
                    $resolved_at = date('Y-m-d H:i:s');
                }

                if ($new_status === 'closed') {
                    $closed_at = date('Y-m-d H:i:s');
                }

                $stmt = $db->prepare("
                    UPDATE service_requests
                    SET
                        status = ?,
                        assigned_at = ?,
                        started_at = ?,
                        resolved_at = ?,
                        closed_at = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ");

                $stmt->execute([
                    $new_status,
                    $assigned_at,
                    $started_at,
                    $resolved_at,
                    $closed_at,
                    $request_id
                ]);

                $stmt = $db->prepare("
                    INSERT INTO ticket_status_history
                    (
                        request_id,
                        old_status,
                        new_status,
                        changed_by,
                        note
                    )
                    VALUES (?, ?, ?, ?, ?)
                ");

                $stmt->execute([
                    $request_id,
                    $old_status,
                    $new_status,
                    $current_admin_id,
                    'تغییر وضعیت توسط ' . $current_username
                ]);

                $db->commit();

                $success = 'وضعیت درخواست با موفقیت تغییر کرد.';
            }
        }

        /*
         * ----------------------------------------------------
         * Change priority
         * ----------------------------------------------------
         */

        elseif ($action === 'change_priority') {

            $priority = trim($_POST['priority'] ?? '');

            $allowed_priorities = [
                'normal',
                'important',
                'urgent',
                'critical'
            ];

            if (!in_array($priority, $allowed_priorities, true)) {
                throw new RuntimeException('اولویت انتخاب‌شده معتبر نیست.');
            }

            if ($priority !== $ticket['priority']) {

                $stmt = $db->prepare("
                    UPDATE service_requests
                    SET
                        priority = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ");

                $stmt->execute([
                    $priority,
                    $request_id
                ]);

                $stmt = $db->prepare("
                    INSERT INTO ticket_status_history
                    (
                        request_id,
                        old_status,
                        new_status,
                        changed_by,
                        note
                    )
                    VALUES (?, ?, ?, ?, ?)
                ");

                $stmt->execute([
                    $request_id,
                    $ticket['status'],
                    $ticket['status'],
                    $current_admin_id,
                    'اولویت به «' . priority_label($priority) . '» تغییر کرد.'
                ]);

                $success = 'اولویت درخواست تغییر کرد.';
            }
        }

        /*
         * ----------------------------------------------------
         * Assign / reassign
         * ----------------------------------------------------
         */

        elseif ($action === 'assign_ticket') {

            $new_admin_id = (int)($_POST['assigned_to'] ?? 0);
            $note = trim($_POST['assignment_note'] ?? '');

            if ($new_admin_id <= 0) {
                throw new RuntimeException('کارشناس مقصد را انتخاب کنید.');
            }

            $stmt = $db->prepare("
                SELECT id, username
                FROM admins
                WHERE id = ?
            ");

            $stmt->execute([$new_admin_id]);

            $new_admin = $stmt->fetch();

            if (!$new_admin) {
                throw new RuntimeException('کارشناس انتخاب‌شده پیدا نشد.');
            }

            $old_admin_id = $ticket['assigned_to']
                ? (int)$ticket['assigned_to']
                : null;

            if ($old_admin_id === $new_admin_id) {
                throw new RuntimeException(
                    'این درخواست هم‌اکنون به همین کارشناس تخصیص داده شده است.'
                );
            }

            $db->beginTransaction();

            $stmt = $db->prepare("
                UPDATE service_requests
                SET
                    assigned_to = ?,
                    assigned_at = COALESCE(assigned_at, CURRENT_TIMESTAMP),
                    status = CASE
                        WHEN status = 'new' THEN 'assigned'
                        ELSE status
                    END,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmt->execute([
                $new_admin_id,
                $request_id
            ]);

            $stmt = $db->prepare("
                INSERT INTO ticket_assignments
                (
                    request_id,
                    from_admin_id,
                    to_admin_id,
                    assigned_by,
                    note
                )
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $request_id,
                $old_admin_id,
                $new_admin_id,
                $current_admin_id,
                $note !== ''
                    ? $note
                    : 'ارجاع درخواست به کارشناس جدید'
            ]);

            $stmt = $db->prepare("
                INSERT INTO ticket_status_history
                (
                    request_id,
                    old_status,
                    new_status,
                    changed_by,
                    note
                )
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $request_id,
                $ticket['status'],
                $ticket['status'],
                $current_admin_id,
                'درخواست به کارشناس «' . $new_admin['username'] . '» ارجاع شد.'
            ]);

            $db->commit();

            $success = 'درخواست با موفقیت به کارشناس جدید ارجاع شد.';
        }

        /*
         * ----------------------------------------------------
         * User-visible reply
         * ----------------------------------------------------
         */

        elseif ($action === 'user_reply') {

            if ($ticket['status'] === 'closed') {
                throw new RuntimeException(
                    'این درخواست بسته شده است و امکان ارسال پیام جدید ندارد.'
                );
            }

            $message = trim($_POST['message'] ?? '');

            if ($message === '') {
                throw new RuntimeException('متن پیام را وارد کنید.');
            }

            $stmt = $db->prepare("
                INSERT INTO ticket_messages
                (
                    request_id,
                    sender_admin_id,
                    sender_username,
                    message,
                    is_internal
                )
                VALUES (?, ?, ?, ?, 0)
            ");

            $stmt->execute([
                $request_id,
                $current_admin_id,
                $current_username,
                $message
            ]);

            $db->prepare("
                UPDATE service_requests
                SET
                    status = CASE
                        WHEN status = 'waiting_user'
                            THEN 'in_progress'
                        ELSE status
                    END,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ")->execute([$request_id]);

            $success = 'پاسخ برای کاربر ثبت شد.';
        }

        /*
         * ----------------------------------------------------
         * Internal note
         * ----------------------------------------------------
         */

        elseif ($action === 'internal_note') {

            $message = trim($_POST['message'] ?? '');

            if ($message === '') {
                throw new RuntimeException(
                    'متن یادداشت داخلی را وارد کنید.'
                );
            }

            $stmt = $db->prepare("
                INSERT INTO ticket_messages
                (
                    request_id,
                    sender_admin_id,
                    sender_username,
                    message,
                    is_internal
                )
                VALUES (?, ?, ?, ?, 1)
            ");

            $stmt->execute([
                $request_id,
                $current_admin_id,
                $current_username,
                $message
            ]);

            $db->prepare("
                UPDATE service_requests
                SET updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ")->execute([$request_id]);

            $success = 'یادداشت داخلی ثبت شد.';
        }

        /*
         * ----------------------------------------------------
         * Waiting for user
         * ----------------------------------------------------
         */

        elseif ($action === 'waiting_user') {

            if ($ticket['status'] === 'closed') {
                throw new RuntimeException(
                    'درخواست بسته شده است.'
                );
            }

            $db->beginTransaction();

            $stmt = $db->prepare("
                UPDATE service_requests
                SET
                    status = 'waiting_user',
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmt->execute([$request_id]);

            $stmt = $db->prepare("
                INSERT INTO ticket_status_history
                (
                    request_id,
                    old_status,
                    new_status,
                    changed_by,
                    note
                )
                VALUES (?, ?, 'waiting_user', ?, ?)
            ");

            $stmt->execute([
                $request_id,
                $ticket['status'],
                $current_admin_id,
                'منتظر پاسخ کاربر'
            ]);

            $db->commit();

            $success = 'درخواست در وضعیت «منتظر پاسخ کاربر» قرار گرفت.';
        }

        /*
         * ----------------------------------------------------
         * Close ticket with resolution
         * ----------------------------------------------------
         */

        elseif ($action === 'close_ticket') {

            $resolution_note = trim(
                $_POST['resolution_note'] ?? ''
            );

            if ($ticket['status'] === 'closed') {
                throw new RuntimeException(
                    'این درخواست قبلاً بسته شده است.'
                );
            }

            if ($resolution_note === '') {
                throw new RuntimeException(
                    'برای بستن درخواست، درج نتیجه و توضیحات الزامی است.'
                );
            }

            if (mb_strlen($resolution_note, 'UTF-8') < 5) {
                throw new RuntimeException(
                    'توضیحات نتیجه نهایی باید حداقل چند کلمه باشد.'
                );
            }

            $db->beginTransaction();

            $now = date('Y-m-d H:i:s');

            $stmt = $db->prepare("
                UPDATE service_requests
                SET
                    status = 'closed',
                    resolution_note = ?,
                    resolved_at = COALESCE(resolved_at, ?),
                    closed_at = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmt->execute([
                $resolution_note,
                $now,
                $now,
                $request_id
            ]);

            $stmt = $db->prepare("
                INSERT INTO ticket_status_history
                (
                    request_id,
                    old_status,
                    new_status,
                    changed_by,
                    note
                )
                VALUES (?, ?, 'closed', ?, ?)
            ");

            $stmt->execute([
                $request_id,
                $ticket['status'],
                $current_admin_id,
                $resolution_note
            ]);

            /*
             * Final visible message for requester.
             * Internal notes are never exposed here.
             */

            $final_message =
                "درخواست شما توسط واحد پشتیبانی بررسی و بسته شد.\n\n"
                . "نتیجه و توضیحات:\n"
                . $resolution_note;

            $stmt = $db->prepare("
                INSERT INTO ticket_messages
                (
                    request_id,
                    sender_admin_id,
                    sender_username,
                    message,
                    is_internal
                )
                VALUES (?, ?, ?, ?, 0)
            ");

            $stmt->execute([
                $request_id,
                $current_admin_id,
                $current_username,
                $final_message
            ]);

            $db->commit();

            header(
                'Location: ticket-manage.php?id='
                . $request_id
                . '&closed=1#resolution'
            );

            exit;
        }

        else {
            throw new RuntimeException(
                'عملیات درخواست‌شده معتبر نیست.'
            );
        }

        /*
         * Refresh ticket after action.
         */

        $stmt = $db->prepare("
            SELECT
                sr.*,
                a.username AS assigned_username
            FROM service_requests sr
            LEFT JOIN admins a
                ON a.id = sr.assigned_to
            WHERE sr.id = ?
        ");

        $stmt->execute([$request_id]);

        $ticket = $stmt->fetch();

    } catch (Throwable $e) {

        if ($db->inTransaction()) {
            $db->rollBack();
        }

        $errors[] = $e->getMessage();
    }
}

if (isset($_GET['closed']) && $_GET['closed'] === '1') {
    $success = 'درخواست با موفقیت بسته شد و از صف درخواست‌های در حال اجرا خارج شد.';
}

/*
 * ------------------------------------------------------------
 * Request types
 * ------------------------------------------------------------
 */

$stmt = $db->prepare("
    SELECT rt.name
    FROM service_request_types srt
    INNER JOIN request_types rt
        ON rt.id = srt.request_type_id
    WHERE srt.request_id = ?
    ORDER BY rt.id
");

$stmt->execute([$request_id]);

$request_types = $stmt->fetchAll();

/*
 * ------------------------------------------------------------
 * Visible conversation
 * ------------------------------------------------------------
 */

$stmt = $db->prepare("
    SELECT tm.*
    FROM ticket_messages tm
    WHERE tm.request_id = ?
      AND tm.is_internal = 0
    ORDER BY tm.created_at ASC, tm.id ASC
");

$stmt->execute([$request_id]);

$conversation = $stmt->fetchAll();

/*
 * ------------------------------------------------------------
 * Internal notes
 * ------------------------------------------------------------
 */

$stmt = $db->prepare("
    SELECT tm.*
    FROM ticket_messages tm
    WHERE tm.request_id = ?
      AND tm.is_internal = 1
    ORDER BY tm.created_at ASC, tm.id ASC
");

$stmt->execute([$request_id]);

$internal_notes = $stmt->fetchAll();

/*
 * ------------------------------------------------------------
 * Status history
 * ------------------------------------------------------------
 */

$stmt = $db->prepare("
    SELECT
        tsh.*,
        a.username
    FROM ticket_status_history tsh
    LEFT JOIN admins a
        ON a.id = tsh.changed_by
    WHERE tsh.request_id = ?
    ORDER BY tsh.created_at DESC, tsh.id DESC
");

$stmt->execute([$request_id]);

$status_history = $stmt->fetchAll();

/*
 * ------------------------------------------------------------
 * Assignment history
 * ------------------------------------------------------------
 */

$stmt = $db->prepare("
    SELECT
        ta.*,
        fa.username AS from_username,
        toa.username AS to_username,
        ba.username AS assigned_by_username
    FROM ticket_assignments ta
    LEFT JOIN admins fa
        ON fa.id = ta.from_admin_id
    LEFT JOIN admins toa
        ON toa.id = ta.to_admin_id
    LEFT JOIN admins ba
        ON ba.id = ta.assigned_by
    WHERE ta.request_id = ?
    ORDER BY ta.created_at DESC, ta.id DESC
");

$stmt->execute([$request_id]);

$assignment_history = $stmt->fetchAll();

/*
 * ------------------------------------------------------------
 * Attachments
 * ------------------------------------------------------------
 */

$stmt = $db->prepare("
    SELECT ta.*, a.username AS uploader_username
    FROM ticket_attachments ta
    LEFT JOIN admins a
        ON a.id = ta.uploaded_by
    WHERE ta.request_id = ?
    ORDER BY ta.created_at ASC, ta.id ASC
");

$stmt->execute([$request_id]);

$attachments = $stmt->fetchAll();

/*
 * ------------------------------------------------------------
 * Admins
 * ------------------------------------------------------------
 */

$admins = $db->query("
    SELECT id, username, role
    FROM admins
    ORDER BY username COLLATE NOCASE
")->fetchAll();

$page_title = 'مدیریت درخواست ' . $ticket['tracking_number'];

require_once __DIR__ . '/includes/header.php';

?>

<div class="ticket-manage-page">

    <div class="ticket-manage-header">

        <div>
            <div class="ticket-breadcrumb">
                <a href="tickets.php">درخواست‌ها</a>
                <span>←</span>
                <span><?php echo h($ticket['tracking_number']); ?></span>
            </div>

            <h1>
                🎫 <?php echo h($ticket['subject']); ?>
            </h1>

            <div class="ticket-header-meta">
                <span class="tracking-number">
                    <?php echo h($ticket['tracking_number']); ?>
                </span>

                <span class="status-badge <?php echo h(status_class($ticket['status'])); ?>">
                    <?php echo h(status_label($ticket['status'])); ?>
                </span>

                <span class="priority-badge <?php echo h(priority_class($ticket['priority'])); ?>">
                    <?php echo h(priority_label($ticket['priority'])); ?>
                </span>

                <?php if ($ticket['assigned_username']): ?>
                    <span class="assigned-badge">
                        👤 <?php echo h($ticket['assigned_username']); ?>
                    </span>
                <?php else: ?>
                    <span class="unassigned-badge">
                        بدون کارشناس
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <a href="tickets.php" class="back-button">
            ← بازگشت به درخواست‌ها
        </a>

    </div>


    <?php if ($success): ?>

        <div class="alert alert-success">
            ✅ <?php echo h($success); ?>
        </div>

    <?php endif; ?>


    <?php if (count($errors) > 0): ?>

        <div class="alert alert-error">

            <?php foreach ($errors as $error): ?>

                <div>
                    ⚠️ <?php echo h($error); ?>
                </div>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>


    <div class="ticket-grid">


        <!-- =====================================================
             Main column
        ====================================================== -->

        <div class="ticket-main">


            <section class="manage-card">

                <div class="manage-card-title">
                    <span>📋</span>
                    <h2>اطلاعات درخواست</h2>
                </div>

                <div class="info-grid">

                    <div>
                        <span>درخواست‌کننده</span>
                        <strong><?php echo h($ticket['fullname']); ?></strong>
                    </div>

                    <div>
                        <span>نام کاربری</span>
                        <strong><?php echo h($ticket['requester_username']); ?></strong>
                    </div>

                    <div>
                        <span>کد پرسنلی</span>
                        <strong><?php echo h($ticket['personnel_code'] ?: '-'); ?></strong>
                    </div>

                    <div>
                        <span>واحد</span>
                        <strong><?php echo h($ticket['department']); ?></strong>
                    </div>

                    <div>
                        <span>شماره تماس</span>
                        <strong><?php echo h($ticket['phone'] ?: '-'); ?></strong>
                    </div>

                    <div>
                        <span>محل</span>
                        <strong><?php echo h($ticket['location'] ?: '-'); ?></strong>
                    </div>

                    <div>
                        <span>سیستم مرتبط</span>
                        <strong><?php echo h($ticket['related_system'] ?: '-'); ?></strong>
                    </div>

                    <div>
                        <span>نام سیستم / Hostname</span>
                        <strong><?php echo h($ticket['hostname'] ?: '-'); ?></strong>
                    </div>

                    <div>
                        <span>IP</span>
                        <strong><?php echo h($ticket['ip_address'] ?: '-'); ?></strong>
                    </div>

                    <div>
                        <span>تاریخ ثبت</span>
                        <strong><?php echo h(jalali_datetime($ticket['created_at'])); ?></strong>
                    </div>

                </div>

            </section>


            <section class="manage-card">

                <div class="manage-card-title">
                    <span>🏷️</span>
                    <h2>نوع درخواست</h2>
                </div>

                <div class="type-list">

                    <?php if ($request_types): ?>

                        <?php foreach ($request_types as $type): ?>

                            <span class="type-badge">
                                <?php echo h($type['name']); ?>
                            </span>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <span class="muted">ثبت نشده</span>

                    <?php endif; ?>

                </div>

            </section>


            <section class="manage-card">

                <div class="manage-card-title">
                    <span>📝</span>
                    <h2>شرح درخواست</h2>
                </div>

                <div class="description-box">
                    <?php echo nl2br(h($ticket['description'])); ?>
                </div>

            </section>


            <?php if ($attachments): ?>

                <section class="manage-card">

                    <div class="manage-card-title">
                        <span>📎</span>
                        <h2>پیوست‌ها</h2>
                    </div>

                    <div class="attachment-list">

                        <?php foreach ($attachments as $attachment): ?>

                            <div class="attachment-item">

                                <span>📄</span>

                                <div>
                                    <strong>
                                        <?php echo h($attachment['original_name']); ?>
                                    </strong>

                                    <small>
                                        <?php echo h($attachment['uploader_username'] ?: '-'); ?>
                                        -
                                        <?php echo h(jalali_datetime($attachment['created_at'])); ?>
                                    </small>
                                </div>

                            </div>

                        <?php endforeach; ?>

                    </div>

                </section>

            <?php endif; ?>


            <!-- =================================================
                 Conversation
            ================================================== -->

            <section class="manage-card" id="conversation">

                <div class="manage-card-title">
                    <span>💬</span>
                    <h2>گفتگو با کاربر</h2>
                </div>

                <?php if (!$conversation): ?>

                    <div class="empty-box">
                        هنوز پیامی در گفتگو ثبت نشده است.
                    </div>

                <?php else: ?>

                    <div class="conversation-list">

                        <?php foreach ($conversation as $message): ?>

                            <div class="conversation-message admin-message">

                                <div class="message-head">

                                    <strong>
                                        👤 <?php echo h($message['sender_username']); ?>
                                    </strong>

                                    <span>
                                        <?php echo h(jalali_datetime($message['created_at'])); ?>
                                    </span>

                                </div>

                                <div class="message-body">
                                    <?php echo nl2br(h($message['message'])); ?>
                                </div>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>


                <?php if ($ticket['status'] !== 'closed'): ?>

                    <form method="post" class="message-form">

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?php echo (int)$request_id; ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="user_reply"
                        >

                        <label>
                            پاسخ برای کاربر
                        </label>

                        <textarea
                            name="message"
                            rows="5"
                            placeholder="پیام خود را برای کاربر وارد کنید..."
                        ></textarea>

                        <button type="submit" class="primary-button">
                            ارسال پاسخ
                        </button>

                    </form>

                <?php endif; ?>

            </section>


            <!-- =================================================
                 Internal notes
            ================================================== -->

            <section class="manage-card internal-card">

                <div class="manage-card-title">
                    <span>🔒</span>
                    <h2>یادداشت داخلی کارشناسان</h2>
                </div>

                <div class="internal-warning">
                    🔒 این بخش فقط برای کارشناسان قابل مشاهده است و برای کاربر نمایش داده نمی‌شود.
                </div>

                <?php if ($internal_notes): ?>

                    <div class="conversation-list">

                        <?php foreach ($internal_notes as $message): ?>

                            <div class="conversation-message internal-message">

                                <div class="message-head">

                                    <strong>
                                        🔒 <?php echo h($message['sender_username']); ?>
                                    </strong>

                                    <span>
                                        <?php echo h(jalali_datetime($message['created_at'])); ?>
                                    </span>

                                </div>

                                <div class="message-body">
                                    <?php echo nl2br(h($message['message'])); ?>
                                </div>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php else: ?>

                    <div class="empty-box">
                        هنوز یادداشت داخلی ثبت نشده است.
                    </div>

                <?php endif; ?>


                <?php if ($ticket['status'] !== 'closed'): ?>

                    <form method="post" class="message-form">

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?php echo (int)$request_id; ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="internal_note"
                        >

                        <label>
                            یادداشت داخلی جدید
                        </label>

                        <textarea
                            name="message"
                            rows="4"
                            placeholder="یادداشت داخلی برای سایر کارشناسان..."
                        ></textarea>

                        <button type="submit" class="secondary-button">
                            ثبت یادداشت داخلی
                        </button>

                    </form>

                <?php endif; ?>

            </section>


            <!-- =================================================
                 Resolution
            ================================================== -->

            <section class="manage-card resolution-card" id="resolution">

                <div class="manage-card-title">
                    <span>✅</span>
                    <h2>نتیجه و بستن درخواست</h2>
                </div>

                <?php if ($ticket['status'] === 'closed'): ?>

                    <div class="closed-result">

                        <div class="closed-result-title">
                            🟢 این درخواست بسته شده است.
                        </div>

                        <div class="closed-result-meta">
                            بسته شده در:
                            <?php echo h(jalali_datetime($ticket['closed_at'])); ?>
                        </div>

                        <div class="resolution-text">
                            <?php
                            echo nl2br(
                                h(
                                    $ticket['resolution_note']
                                    ?: 'توضیحات نتیجه نهایی ثبت نشده است.'
                                )
                            );
                            ?>
                        </div>

                    </div>

                <?php else: ?>

                    <div class="resolution-warning">
                        ⚠️ قبل از بستن درخواست، نتیجه اقدامات انجام‌شده و راه‌حل نهایی را کامل ثبت کنید.
                    </div>

                    <form method="post">

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?php echo (int)$request_id; ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="close_ticket"
                        >

                        <label class="resolution-label">
                            نتیجه اقدامات انجام‌شده
                            <span>*</span>
                        </label>

                        <textarea
                            name="resolution_note"
                            class="resolution-textarea"
                            rows="7"
                            required
                            placeholder="مثلاً: مشکل اتصال سیستم به شبکه بررسی شد. تنظیمات کارت شبکه اصلاح و اتصال مجدداً برقرار شد."
                        ></textarea>

                        <button
                            type="submit"
                            class="close-ticket-button"
                            onclick="return confirm('آیا از حل شدن مشکل و بستن این درخواست مطمئن هستید؟');"
                        >
                            ✓ حل شد و بستن درخواست
                        </button>

                    </form>

                <?php endif; ?>

            </section>


            <!-- =================================================
                 Status history
            ================================================== -->

            <section class="manage-card">

                <div class="manage-card-title">
                    <span>🕘</span>
                    <h2>تاریخچه وضعیت</h2>
                </div>

                <?php if ($status_history): ?>

                    <div class="history-list">

                        <?php foreach ($status_history as $history): ?>

                            <div class="history-item">

                                <div class="history-dot"></div>

                                <div class="history-content">

                                    <strong>
                                        <?php echo h(status_label($history['new_status'])); ?>
                                    </strong>

                                    <span>
                                        <?php echo h(jalali_datetime($history['created_at'])); ?>
                                    </span>

                                    <?php if ($history['username']): ?>

                                        <small>
                                            توسط <?php echo h($history['username']); ?>
                                        </small>

                                    <?php endif; ?>

                                    <?php if ($history['note']): ?>

                                        <p>
                                            <?php echo nl2br(h($history['note'])); ?>
                                        </p>

                                    <?php endif; ?>

                                </div>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php else: ?>

                    <div class="empty-box">
                        تاریخچه‌ای ثبت نشده است.
                    </div>

                <?php endif; ?>

            </section>


            <!-- =================================================
                 Assignment history
            ================================================== -->

            <section class="manage-card">

                <div class="manage-card-title">
                    <span>🔄</span>
                    <h2>تاریخچه ارجاع</h2>
                </div>

                <?php if ($assignment_history): ?>

                    <div class="history-list">

                        <?php foreach ($assignment_history as $assignment): ?>

                            <div class="history-item">

                                <div class="history-dot assignment-dot"></div>

                                <div class="history-content">

                                    <strong>
                                        <?php
                                        echo h(
                                            $assignment['to_username']
                                            ?: 'نامشخص'
                                        );
                                        ?>
                                    </strong>

                                    <span>
                                        <?php echo h(jalali_datetime($assignment['created_at'])); ?>
                                    </span>

                                    <small>
                                        <?php if ($assignment['from_username']): ?>
                                            از <?php echo h($assignment['from_username']); ?>
                                            ←
                                        <?php endif; ?>

                                        ارجاع توسط
                                        <?php echo h($assignment['assigned_by_username'] ?: '-'); ?>
                                    </small>

                                    <?php if ($assignment['note']): ?>

                                        <p>
                                            <?php echo nl2br(h($assignment['note'])); ?>
                                        </p>

                                    <?php endif; ?>

                                </div>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php else: ?>

                    <div class="empty-box">
                        هنوز ارجاعی برای این درخواست ثبت نشده است.
                    </div>

                <?php endif; ?>

            </section>

        </div>


        <!-- =====================================================
             Side management
        ====================================================== -->

        <aside class="ticket-sidebar">


            <section class="manage-card">

                <div class="manage-card-title">
                    <span>⚙️</span>
                    <h2>مدیریت درخواست</h2>
                </div>


                <?php if ($ticket['status'] !== 'closed'): ?>

                    <form method="post" class="side-form">

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?php echo (int)$request_id; ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="change_status"
                        >

                        <label>وضعیت</label>

                        <select name="status">

                            <?php
                            $statuses = [
                                'new'          => 'جدید',
                                'assigned'     => 'تخصیص داده شده',
                                'in_progress'  => 'در حال بررسی',
                                'waiting_user' => 'منتظر پاسخ کاربر',
                                'resolved'     => 'حل شده',
                                'closed'       => 'بسته شده',
                                'cancelled'    => 'لغو شده'
                            ];
                            ?>

                            <?php foreach ($statuses as $value => $label): ?>

                                <option
                                    value="<?php echo h($value); ?>"
                                    <?php echo $ticket['status'] === $value ? 'selected' : ''; ?>
                                >
                                    <?php echo h($label); ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                        <button type="submit" class="secondary-button full-width">
                            ذخیره وضعیت
                        </button>

                    </form>


                    <form method="post" class="side-form">

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?php echo (int)$request_id; ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="change_priority"
                        >

                        <label>اولویت</label>

                        <select name="priority">

                            <?php
                            $priorities = [
                                'normal'    => 'عادی',
                                'important' => 'مهم',
                                'urgent'    => 'فوری',
                                'critical'  => 'بحرانی'
                            ];
                            ?>

                            <?php foreach ($priorities as $value => $label): ?>

                                <option
                                    value="<?php echo h($value); ?>"
                                    <?php echo $ticket['priority'] === $value ? 'selected' : ''; ?>
                                >
                                    <?php echo h($label); ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                        <button type="submit" class="secondary-button full-width">
                            ذخیره اولویت
                        </button>

                    </form>

                <?php endif; ?>


                <form method="post" class="side-form">

                    <input
                        type="hidden"
                        name="request_id"
                        value="<?php echo (int)$request_id; ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="assign_ticket"
                    >

                    <label>کارشناس مسئول</label>

                    <select name="assigned_to" required>

                        <option value="">
                            انتخاب کارشناس
                        </option>

                        <?php foreach ($admins as $admin): ?>

                            <option
                                value="<?php echo (int)$admin['id']; ?>"
                                <?php
                                echo (
                                    (int)$ticket['assigned_to']
                                    === (int)$admin['id']
                                )
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                <?php echo h($admin['username']); ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <label>
                        توضیح ارجاع
                    </label>

                    <textarea
                        name="assignment_note"
                        rows="3"
                        placeholder="اختیاری؛ مثلاً نیاز به بررسی سخت‌افزار"
                    ></textarea>

                    <button type="submit" class="primary-button full-width">
                        🔄 ارجاع به کارشناس
                    </button>

                </form>


                <?php if ($ticket['status'] !== 'closed'): ?>

                    <form method="post" class="side-form waiting-form">

                        <input
                            type="hidden"
                            name="request_id"
                            value="<?php echo (int)$request_id; ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="waiting_user"
                        >

                        <button
                            type="submit"
                            class="waiting-button full-width"
                        >
                            ⏳ منتظر پاسخ کاربر
                        </button>

                    </form>

                <?php endif; ?>

            </section>


            <section class="manage-card quick-info-card">

                <div class="manage-card-title">
                    <span>📊</span>
                    <h2>وضعیت زمانی</h2>
                </div>

                <div class="quick-info">

                    <div>
                        <span>ثبت درخواست</span>
                        <strong>
                            <?php echo h(jalali_datetime($ticket['created_at'])); ?>
                        </strong>
                    </div>

                    <div>
                        <span>تخصیص</span>
                        <strong>
                            <?php echo h(jalali_datetime($ticket['assigned_at'])); ?>
                        </strong>
                    </div>

                    <div>
                        <span>شروع بررسی</span>
                        <strong>
                            <?php echo h(jalali_datetime($ticket['started_at'])); ?>
                        </strong>
                    </div>

                    <div>
                        <span>حل</span>
                        <strong>
                            <?php echo h(jalali_datetime($ticket['resolved_at'])); ?>
                        </strong>
                    </div>

                    <div>
                        <span>بسته شدن</span>
                        <strong>
                            <?php echo h(jalali_datetime($ticket['closed_at'])); ?>
                        </strong>
                    </div>

                </div>

            </section>


        </aside>

    </div>

</div>


<style>

.ticket-manage-page {
    max-width: 1500px;
    margin: 0 auto;
}

.ticket-manage-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    margin-bottom: 24px;
}

.ticket-breadcrumb {
    display: flex;
    gap: 8px;
    color: #718096;
    font-size: 13px;
    margin-bottom: 10px;
}

.ticket-breadcrumb a {
    color: #1b4965;
    text-decoration: none;
}

.ticket-manage-header h1 {
    margin: 0 0 12px 0;
    color: #0b1f3a;
}

.ticket-header-meta {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
}

.tracking-number {
    color: #718096;
    font-size: 13px;
    font-weight: 700;
}

.status-badge,
.priority-badge,
.assigned-badge,
.unassigned-badge {
    display: inline-flex;
    align-items: center;
    padding: 6px 10px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
}

.status-new {
    background: #edf2f7;
    color: #4a5568;
}

.status-assigned {
    background: #ebf8ff;
    color: #2b6cb0;
}

.status-progress {
    background: #fff8dc;
    color: #8a6800;
}

.status-waiting {
    background: #fff4e5;
    color: #b45309;
}

.status-resolved,
.status-closed {
    background: #e9f8ef;
    color: #18794e;
}

.status-cancelled {
    background: #fdecec;
    color: #b42318;
}

.priority-normal {
    background: #edf8ef;
    color: #24753b;
}

.priority-important {
    background: #fff7df;
    color: #8a6800;
}

.priority-urgent {
    background: #fff0e8;
    color: #b54708;
}

.priority-critical {
    background: #fde8e8;
    color: #b42318;
}

.assigned-badge {
    background: #eef4fb;
    color: #315a82;
}

.unassigned-badge {
    background: #f7f7f7;
    color: #777;
}

.back-button {
    text-decoration: none;
    background: #fff;
    border: 1px solid #dfe6ef;
    color: #0b1f3a;
    padding: 10px 15px;
    border-radius: 8px;
    white-space: nowrap;
}

.alert {
    padding: 13px 16px;
    border-radius: 9px;
    margin-bottom: 20px;
    font-size: 14px;
}

.alert-success {
    background: #edf9f1;
    border: 1px solid #b9e2c6;
    color: #196b37;
}

.alert-error {
    background: #fff1f1;
    border: 1px solid #e4b7b7;
    color: #a52323;
}

.ticket-grid {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 360px;
    gap: 20px;
    align-items: start;
}

.ticket-main {
    min-width: 0;
}

.ticket-sidebar {
    position: sticky;
    top: 15px;
}

.manage-card {
    background: #fff;
    border: 1px solid #e5ebf2;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 3px 12px rgba(0,0,0,.035);
}

.manage-card-title {
    display: flex;
    align-items: center;
    gap: 10px;
    border-bottom: 1px solid #edf1f5;
    padding-bottom: 14px;
    margin-bottom: 18px;
}

.manage-card-title span {
    font-size: 20px;
}

.manage-card-title h2 {
    margin: 0;
    font-size: 17px;
    color: #0b1f3a;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.info-grid > div {
    background: #f8fafc;
    border-radius: 8px;
    padding: 12px;
}

.info-grid span,
.quick-info span {
    display: block;
    color: #718096;
    font-size: 12px;
    margin-bottom: 6px;
}

.info-grid strong,
.quick-info strong {
    color: #26364a;
    font-size: 13px;
}

.type-list {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.type-badge {
    background: #edf4fb;
    color: #315a82;
    border-radius: 7px;
    padding: 7px 10px;
    font-size: 13px;
}

.description-box {
    background: #f8fafc;
    border: 1px solid #edf1f5;
    border-radius: 9px;
    padding: 17px;
    line-height: 1.9;
    color: #354052;
    white-space: normal;
}

.empty-box {
    background: #f8fafc;
    border: 1px dashed #dce4ee;
    color: #718096;
    border-radius: 9px;
    padding: 22px;
    text-align: center;
    font-size: 13px;
}

.conversation-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.conversation-message {
    border-radius: 10px;
    padding: 14px;
}

.admin-message {
    background: #f1f7fc;
    border-right: 4px solid #315a82;
}

.internal-message {
    background: #fff8e7;
    border-right: 4px solid #d99a18;
}

.message-head {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 9px;
    font-size: 12px;
}

.message-head strong {
    color: #26364a;
}

.message-head span {
    color: #718096;
}

.message-body {
    line-height: 1.9;
    color: #354052;
    font-size: 14px;
}

.message-form,
.side-form {
    margin-top: 18px;
}

.message-form label,
.side-form label,
.resolution-label {
    display: block;
    font-size: 13px;
    font-weight: 700;
    color: #354052;
    margin-bottom: 7px;
}

.message-form textarea,
.side-form textarea,
.side-form select,
.resolution-textarea {
    width: 100%;
    box-sizing: border-box;
    border: 1px solid #d8e0e9;
    border-radius: 8px;
    padding: 11px 12px;
    font-family: inherit;
    font-size: 13px;
    resize: vertical;
    background: #fff;
}

.message-form textarea:focus,
.side-form textarea:focus,
.side-form select:focus,
.resolution-textarea:focus {
    outline: none;
    border-color: #6d8eae;
    box-shadow: 0 0 0 3px rgba(49,90,130,.08);
}

.primary-button,
.secondary-button,
.waiting-button,
.close-ticket-button {
    border: 0;
    border-radius: 8px;
    padding: 10px 15px;
    font-family: inherit;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
}

.primary-button {
    margin-top: 10px;
    background: #0b1f3a;
    color: #fff;
}

.primary-button:hover {
    background: #17385d;
}

.secondary-button {
    margin-top: 10px;
    background: #eef3f8;
    color: #27445f;
}

.secondary-button:hover {
    background: #e2eaf2;
}

.waiting-button {
    background: #fff4df;
    color: #9a6200;
    border: 1px solid #efd49f;
}

.waiting-button:hover {
    background: #ffedc8;
}

.close-ticket-button {
    width: 100%;
    margin-top: 14px;
    background: #23824d;
    color: #fff;
    padding: 13px 16px;
    font-size: 14px;
}

.close-ticket-button:hover {
    background: #1c6d40;
}

.full-width {
    width: 100%;
}

.internal-card {
    border-color: #ead9aa;
}

.internal-warning {
    background: #fff8e7;
    border: 1px solid #f0dda9;
    color: #806000;
    border-radius: 8px;
    padding: 10px 12px;
    font-size: 12px;
    margin-bottom: 15px;
}

.resolution-card {
    border: 2px solid #d5e8dc;
}

.resolution-warning {
    background: #f1f9f3;
    color: #386b48;
    border: 1px solid #cfe5d5;
    border-radius: 8px;
    padding: 11px 13px;
    margin-bottom: 15px;
    font-size: 13px;
}

.resolution-label span {
    color: #c00000;
}

.resolution-textarea {
    min-height: 150px;
}

.closed-result {
    background: #f1f9f3;
    border: 1px solid #cce4d3;
    border-radius: 10px;
    padding: 17px;
}

.closed-result-title {
    color: #18794e;
    font-weight: 800;
    margin-bottom: 7px;
}

.closed-result-meta {
    color: #718096;
    font-size: 12px;
    margin-bottom: 15px;
}

.resolution-text {
    background: #fff;
    border-radius: 8px;
    padding: 14px;
    line-height: 1.9;
    color: #354052;
}

.history-list {
    display: flex;
    flex-direction: column;
}

.history-item {
    position: relative;
    display: flex;
    gap: 13px;
    padding: 0 0 18px 0;
}

.history-dot {
    flex: 0 0 10px;
    width: 10px;
    height: 10px;
    margin-top: 5px;
    border-radius: 50%;
    background: #315a82;
}

.assignment-dot {
    background: #8a6b00;
}

.history-content {
    min-width: 0;
}

.history-content strong {
    color: #26364a;
    font-size: 13px;
}

.history-content > span {
    color: #718096;
    font-size: 11px;
    margin-right: 8px;
}

.history-content small {
    display: block;
    color: #718096;
    margin-top: 4px;
}

.history-content p {
    background: #f8fafc;
    border-radius: 7px;
    padding: 9px 11px;
    margin: 8px 0 0;
    color: #4a5568;
    font-size: 12px;
    line-height: 1.8;
}

.attachment-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.attachment-item {
    display: flex;
    gap: 10px;
    align-items: center;
    background: #f8fafc;
    border-radius: 8px;
    padding: 11px;
}

.attachment-item > span {
    font-size: 22px;
}

.attachment-item strong {
    display: block;
    font-size: 13px;
}

.attachment-item small {
    display: block;
    color: #718096;
    font-size: 11px;
    margin-top: 4px;
}

.quick-info {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.quick-info > div {
    background: #f8fafc;
    border-radius: 8px;
    padding: 10px;
}

.muted {
    color: #718096;
    font-size: 13px;
}

@media (max-width: 1050px) {

    .ticket-grid {
        grid-template-columns: 1fr;
    }

    .ticket-sidebar {
        position: static;
    }

}

@media (max-width: 800px) {

    .ticket-manage-header {
        flex-direction: column;
    }

    .info-grid {
        grid-template-columns: 1fr 1fr;
    }

}

@media (max-width: 520px) {

    .info-grid {
        grid-template-columns: 1fr;
    }

}

</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
