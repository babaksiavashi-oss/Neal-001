<?php

require_once __DIR__ . "/../config/config.php";


// Check Squid Status

function squid_status()
{

    $status = shell_exec("service squid status 2>&1");

    if (strpos($status, "is running") !== false) {

        return "Running";

    }

    return "Stopped";

}



// Count Blocked Sites

function blocked_sites_count()
{

    if (file_exists(BLOCK_LIST)) {

        $lines = file(BLOCK_LIST, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        return count($lines);

    }

    return 0;

}



// Check SARG

function sarg_status()
{

    if (is_dir(SARG_PATH)) {

        return "Active";

    }

    return "Inactive";

}



// Last SARG Report

function last_sarg_report()
{

    $path = SARG_PATH . "/2026";

    if (!is_dir($path)) {

        return "-";

    }


    $files = scandir($path, SCANDIR_SORT_DESCENDING);


    foreach ($files as $file) {

        if ($file != "." && $file != "..") {

            return $file;

        }

    }


    return "-";

}

// Check Squid Proxy Port

function squid_proxy_port_status()
{

    $output = shell_exec(
        "sockstat -4 -l 2>/dev/null | grep ':3128'"
    );

    if (!empty(trim($output))) {

        return "Active";

    }

    return "Inactive";

}



// Check Squid Access Log

function squid_access_log_status()
{

    $log = "/var/log/squid/access.log";

    if (!file_exists($log)) {

        return "Inactive";

    }

    if (filesize($log) <= 0) {

        return "Empty";

    }

    return "Active";

}



// Get Squid Cache Hit Rate

function squid_cache_hit_rate()
{

    $log = "/var/log/squid/access.log";

    if (!file_exists($log)) {

        return 0;

    }


    $hit = 0;
    $miss = 0;


    $handle = @fopen($log, "r");

    if (!$handle) {

        return 0;

    }


    while (($line = fgets($handle)) !== false) {

        $parts = preg_split('/\s+/', trim($line));

        if (!isset($parts[3])) {

            continue;

        }


        $status = $parts[3];


        if (
            preg_match(
                '/^TCP_(HIT|MEM_HIT|REFRESH_UNMODIFIED)/',
                $status
            )
        ) {

            $hit++;

        }


        elseif (
            preg_match(
                '/^TCP_(MISS|REFRESH_MODIFIED)/',
                $status
            )
        ) {

            $miss++;

        }

    }


    fclose($handle);


    $total = $hit + $miss;


    if ($total == 0) {

        return 0;

    }


    return round(
        ($hit / $total) * 100,
        2
    );

}

// Proxy Activity Statistics

function proxy_activity_stats()
{
    $log_file = "/var/log/squid/access.log";

    $stats = array(
        "total" => 0,
        "auth_required" => 0,
        "denied" => 0,
        "https_tunnel" => 0
    );

    if (!file_exists($log_file)) {
        return $stats;
    }

    $handle = fopen($log_file, "r");

    if (!$handle) {
        return $stats;
    }

    $cutoff = time() - (24 * 60 * 60);

    while (($line = fgets($handle)) !== false) {

        $parts = preg_split('/\s+/', trim($line));

        if (!isset($parts[0], $parts[3])) {
            continue;
        }

        $timestamp = (float) $parts[0];

        if ($timestamp < $cutoff) {
            continue;
        }

        $status = $parts[3];

        if (strpos($status, "TCP_") !== 0) {
            continue;
        }

        $stats["total"]++;

        if ($status === "TCP_DENIED/407") {
            $stats["auth_required"]++;
        }

        if ($status === "TCP_DENIED/403") {
            $stats["denied"]++;
        }

        if ($status === "TCP_TUNNEL/200") {
            $stats["https_tunnel"]++;
        }
    }

    fclose($handle);

    return $stats;
}

/* Proxy Activity - Hourly Statistics */

function proxy_activity_hourly()
{
    $log_file = "/var/log/squid/access.log";

    $hours = array();

    for ($i = 23; $i >= 0; $i--) {
        $hour = date("H", time() - ($i * 3600));
        $hours[$hour] = 0;
    }

    if (!file_exists($log_file)) {
        return $hours;
    }

    $handle = fopen($log_file, "r");

    if (!$handle) {
        return $hours;
    }

    $cutoff = time() - (24 * 60 * 60);

    while (($line = fgets($handle)) !== false) {

        $parts = preg_split('/\s+/', trim($line));

        if (!isset($parts[0], $parts[3])) {
            continue;
        }

        $timestamp = (float) $parts[0];

        if ($timestamp < $cutoff) {
            continue;
        }

        $status = $parts[3];

        if (strpos($status, "TCP_") !== 0) {
            continue;
        }

        $hour = date("H", (int) $timestamp);

        if (isset($hours[$hour])) {
            $hours[$hour]++;
        }
    }

    fclose($handle);

    return $hours;
}


/* Proxy Activity - Hourly Detailed Statistics */

function proxy_activity_hourly_detail()
{
    $log_file = "/var/log/squid/access.log";

    $hours = array();

    for ($i = 23; $i >= 0; $i--) {

        $hour = date("H", time() - ($i * 3600));

        $hours[$hour] = array(
            "total" => 0,
            "denied" => 0,
            "https" => 0
        );
    }

    if (!file_exists($log_file)) {
        return $hours;
    }

    $handle = fopen($log_file, "r");

    if (!$handle) {
        return $hours;
    }

    $cutoff = time() - (24 * 60 * 60);

    while (($line = fgets($handle)) !== false) {

        $parts = preg_split('/\s+/', trim($line));

        if (!isset($parts[0], $parts[3])) {
            continue;
        }

        $timestamp = (float) $parts[0];

        if ($timestamp < $cutoff) {
            continue;
        }

        $status = $parts[3];

        if (strpos($status, "TCP_") !== 0) {
            continue;
        }

        $hour = date("H", (int) $timestamp);

        if (!isset($hours[$hour])) {
            continue;
        }

        $hours[$hour]["total"]++;

        if ($status === "TCP_DENIED/403") {
            $hours[$hour]["denied"]++;
        }

        if ($status === "TCP_TUNNEL/200") {
            $hours[$hour]["https"]++;
        }
    }

    fclose($handle);

    return $hours;
}

?>
