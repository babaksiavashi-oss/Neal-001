<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>

<meta charset="UTF-8">

<title>
<?php
echo isset($page_title)
? "NEAL Proxy Manager - " . $page_title
: "NEAL Proxy Manager";
?>
</title>

<link rel="stylesheet" href="css/style.css">

</head>


<body>


<div class="topbar">


    <img src="images/logo.png" class="logo">


    <div class="title">

        NEAL Proxy Manager

        <span>Squid Proxy Management System</span>

    </div>


    <div class="user-menu">

        <?php

        if(isset($_SESSION['username'])) {

            echo "👤 " . htmlspecialchars($_SESSION['username']);

            echo ' | <a href="/neal/logout.php">↪ خروج</a>';

        }

        ?>

    </div>


</div>


<div class="portal-body">

<?php include "menu.php"; ?>


<div class="content">
