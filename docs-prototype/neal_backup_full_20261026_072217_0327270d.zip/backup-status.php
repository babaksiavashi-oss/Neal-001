<?php
declare(strict_types=1);

require_once __DIR__ . '/auth/auth.php';
check_login();

header('Content-Type: application/json; charset=UTF-8');

function status_out(bool $ok, array $data = []): never
{
    echo json_encode(array_merge(['ok'=>$ok], $data), JSON_UNESCAPED_UNICODE);
    exit;
}

$csrf = (string)($_GET['csrf'] ?? '');
if (empty($_SESSION['backup_csrf']) || !hash_equals($_SESSION['backup_csrf'], $csrf)) {
    status_out(false, ['message'=>'اعتبار امنیتی درخواست منقضی شده است.']);
}

$jobId = (string)($_GET['job'] ?? '');

if (!preg_match('/^[A-Za-z0-9_]+$/', $jobId)) {
    status_out(false, ['message'=>'شناسه عملیات نامعتبر است.']);
}

$jobFile = '/usr/local/backups/neal/jobs/' . $jobId . '.json';

if (!is_file($jobFile)) {
    status_out(false, ['message'=>'عملیات پیدا نشد.']);
}

$job = json_decode((string)@file_get_contents($jobFile), true);

if (!is_array($job)) {
    status_out(false, ['message'=>'اطلاعات عملیات قابل خواندن نیست.']);
}

status_out(true, ['job'=>$job]);
