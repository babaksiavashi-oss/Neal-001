<?php

require_once __DIR__ . '/auth/auth.php';
require_once __DIR__ . '/config/config.php';

check_login();

$db = new PDO('sqlite:' . __DIR__ . '/data/neal.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


/* =========================================================
   Labels
   ========================================================= */

$statusLabels = array(
    'new'          => 'جدید',
    'assigned'     => 'تخصیص داده شده',
    'in_progress'  => 'در حال بررسی',
    'waiting_user' => 'منتظر پاسخ کاربر',
    'resolved'     => 'حل شده',
    'closed'       => 'بسته شده',
    'cancelled'    => 'لغو شده'
);

$priorityLabels = array(
    'normal'    => 'عادی',
    'important' => 'مهم',
    'urgent'    => 'فوری',
    'critical'  => 'بحرانی'
);

$departmentLabels = array(
    'management'    => 'واحد مدیریت',
    'regulatory'    => 'واحد مسئول فنی و رگولاتوری',
    'administrative'=> 'واحد اداری',
    'engineering'   => 'واحد فنی مهندسی',
    'finance'       => 'واحد مالی',
    'planning'      => 'واحد برنامه ریزی و انبار',
    'quality'       => 'واحد آزمایشگاه کنترل کیفیت',
    'commercial'    => 'واحد بازرگانی',
    'production'    => 'واحد تولید',
    'hse'           => 'واحد ایمنی و بهداشت'
);


/* =========================================================
   Helpers
   ========================================================= */

function jalaliDate($datetime)
{
    if (empty($datetime)) {
        return '-';
    }

    $timestamp = strtotime($datetime);

    if ($timestamp === false) {
        return $datetime;
    }

    $gy = (int)date('Y', $timestamp);
    $gm = (int)date('n', $timestamp);
    $gd = (int)date('j', $timestamp);

    $g_d_m = array(
        0,
        31,
        59,
        90,
        120,
        151,
        181,
        212,
        243,
        273,
        304,
        334
    );

    if ($gy > 1600) {
        $jy = 979;
        $gy -= 1600;
    } else {
        $jy = 0;
        $gy -= 621;
    }

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;

    $days = (365 * $gy)
        + (int)(($gy2 + 3) / 4)
        - (int)(($gy2 + 99) / 100)
        + (int)(($gy2 + 399) / 400)
        - 80
        + $gd
        + $g_d_m[$gm - 1];

    $jy += 33 * (int)($days / 12053);
    $days %= 12053;

    $jy += 4 * (int)($days / 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return sprintf(
        '%04d/%02d/%02d - %s',
        $jy,
        $jm,
        $jd,
        date('H:i', $timestamp)
    );
}


function persianNumber($number)
{
    return strtr(
        (string)$number,
        array(
            '0' => '۰',
            '1' => '۱',
            '2' => '۲',
            '3' => '۳',
            '4' => '۴',
            '5' => '۵',
            '6' => '۶',
            '7' => '۷',
            '8' => '۸',
            '9' => '۹'
        )
    );
}


/* =========================================================
   Filters
   ========================================================= */

$search     = isset($_GET['search']) ? trim($_GET['search']) : '';
$status     = isset($_GET['status']) ? trim($_GET['status']) : '';
$priority   = isset($_GET['priority']) ? trim($_GET['priority']) : '';
$department = isset($_GET['department']) ? trim($_GET['department']) : '';


/* =========================================================
   Statistics
   ========================================================= */

$stats = array(
    'all'           => 0,
    'new'           => 0,
    'in_progress'   => 0,
    'waiting_user'  => 0,
    'resolved'      => 0,
    'closed'        => 0
);

$stmt = $db->query("
    SELECT status, COUNT(*) AS total
    FROM service_requests
    GROUP BY status
");

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

    $currentStatus = $row['status'];
    $total = (int)$row['total'];

    if (isset($stats[$currentStatus])) {
        $stats[$currentStatus] = $total;
    }

    $stats['all'] += $total;
}


/* =========================================================
   Ticket List Query
   ========================================================= */

$sql = "
    SELECT
        sr.id,
        sr.tracking_number,
        sr.jalali_year,
        sr.yearly_number,
        sr.requester_username,
        sr.fullname,
        sr.department,
        sr.priority,
        sr.subject,
        sr.status,
        sr.created_at,
        sr.updated_at,
        sr.assigned_to,

        GROUP_CONCAT(rt.name, '، ') AS request_types

    FROM service_requests sr

    LEFT JOIN service_request_types srt
        ON srt.request_id = sr.id

    LEFT JOIN request_types rt
        ON rt.id = srt.request_type_id

    WHERE 1 = 1
";

$params = array();


if ($search !== '') {

    $sql .= "
        AND (
            sr.tracking_number LIKE ?
            OR sr.subject LIKE ?
            OR sr.fullname LIKE ?
            OR sr.requester_username LIKE ?
        )
    ";

    $searchValue = '%' . $search . '%';

    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;
}


if ($status !== '' && isset($statusLabels[$status])) {

    $sql .= " AND sr.status = ? ";
    $params[] = $status;
}


if ($priority !== '' && isset($priorityLabels[$priority])) {

    $sql .= " AND sr.priority = ? ";
    $params[] = $priority;
}


if ($department !== '' && isset($departmentLabels[$department])) {

    $sql .= " AND sr.department = ? ";
    $params[] = $department;
}


$sql .= "
    GROUP BY sr.id
    ORDER BY sr.id DESC
";


$stmt = $db->prepare($sql);
$stmt->execute($params);

$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);


/* =========================================================
   Page Title
   ========================================================= */

$page_title = 'مدیریت درخواست‌های پشتیبانی';

?>


<?php require_once __DIR__ . '/includes/header.php'; ?>


<style>

/* =========================================================
   Ticket Management Page
   ========================================================= */

.ticket-page {
    width: 100%;
}

.ticket-page-title {
    margin-bottom: 20px;
}

.ticket-page-title h1 {
    margin: 0 0 7px 0;
    font-size: 25px;
}

.ticket-page-title p {
    margin: 0;
    color: #666;
    font-size: 14px;
}


/* Statistics */

.ticket-stats {
    display: grid;
    grid-template-columns: repeat(6, minmax(120px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}

.ticket-stat {
    background: #ffffff;
    border: 1px solid #dddddd;
    border-radius: 8px;
    padding: 15px;
    text-align: center;
    box-sizing: border-box;
}

.ticket-stat-number {
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 5px;
}

.ticket-stat-label {
    font-size: 13px;
    color: #666;
}


/* Filters */

.ticket-filters {
    background: #ffffff;
    border: 1px solid #dddddd;
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 20px;
}

.ticket-filters form {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr 1.5fr auto auto;
    gap: 10px;
    align-items: end;
}

.ticket-filter-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.ticket-filter-group label {
    font-size: 13px;
    color: #555;
}

.ticket-filter-group input,
.ticket-filter-group select {
    width: 100%;
    box-sizing: border-box;
    min-height: 38px;
    border: 1px solid #cccccc;
    border-radius: 5px;
    padding: 7px 10px;
    font-family: inherit;
    font-size: 13px;
    background: #fff;
}

.ticket-filter-button {
    min-height: 38px;
    border: none;
    border-radius: 5px;
    padding: 0 18px;
    cursor: pointer;
    font-family: inherit;
    font-size: 13px;
    background: #1f5f8b;
    color: #fff;
}

.ticket-filter-reset {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 38px;
    padding: 0 16px;
    border-radius: 5px;
    border: 1px solid #cccccc;
    background: #f5f5f5;
    color: #444;
    text-decoration: none;
    font-size: 13px;
}


/* Table */

.ticket-table-box {
    background: #ffffff;
    border: 1px solid #dddddd;
    border-radius: 8px;
    overflow-x: auto;
}

.ticket-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 1050px;
}

.ticket-table th {
    background: #f4f6f8;
    color: #444;
    font-size: 13px;
    font-weight: 700;
    padding: 12px 10px;
    border-bottom: 1px solid #dddddd;
    text-align: right;
    white-space: nowrap;
}

.ticket-table td {
    padding: 12px 10px;
    border-bottom: 1px solid #eeeeee;
    font-size: 13px;
    vertical-align: middle;
}

.ticket-table tr:last-child td {
    border-bottom: none;
}

.ticket-table tr:hover td {
    background: #fafafa;
}

.ticket-number {
    font-weight: 700;
    white-space: nowrap;
}

.ticket-subject {
    font-weight: 600;
    color: #333;
}

.ticket-requester {
    white-space: nowrap;
}

.ticket-date {
    white-space: nowrap;
    direction: rtl;
}


/* Badges */

.ticket-badge {
    display: inline-block;
    padding: 4px 9px;
    border-radius: 12px;
    font-size: 11px;
    white-space: nowrap;
}

.status-new {
    background: #e8f1ff;
    color: #1859a5;
}

.status-assigned {
    background: #eee8ff;
    color: #5d35a5;
}

.status-in_progress {
    background: #fff4d8;
    color: #8a6100;
}

.status-waiting_user {
    background: #fff0e5;
    color: #a24b00;
}

.status-resolved {
    background: #e4f7ea;
    color: #217a3a;
}

.status-closed {
    background: #eeeeee;
    color: #555;
}

.status-cancelled {
    background: #ffe7e7;
    color: #a00000;
}

.priority-normal {
    background: #eeeeee;
    color: #555;
}

.priority-important {
    background: #fff4d8;
    color: #8a6100;
}

.priority-urgent {
    background: #ffe7d6;
    color: #a63f00;
}

.priority-critical {
    background: #ffdede;
    color: #a00000;
    font-weight: 700;
}


/* View Button */

.ticket-view-button {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 5px;
    background: #1f5f8b;
    color: #fff;
    text-decoration: none;
    font-size: 12px;
    white-space: nowrap;
}

.ticket-view-button:hover {
    opacity: 0.9;
}


/* Empty */

.ticket-empty {
    padding: 45px 20px;
    text-align: center;
    color: #777;
    font-size: 14px;
}


/* Responsive */

@media (max-width: 1200px) {

    .ticket-stats {
        grid-template-columns: repeat(3, 1fr);
    }

    .ticket-filters form {
        grid-template-columns: repeat(2, 1fr);
    }

}

@media (max-width: 700px) {

    .ticket-stats {
        grid-template-columns: repeat(2, 1fr);
    }

    .ticket-filters form {
        grid-template-columns: 1fr;
    }

}

</style>


<div class="ticket-page">

    <div class="ticket-page-title">

        <h1>🎫 مدیریت درخواست‌های پشتیبانی</h1>

        <p>
            مشاهده، فیلتر و پیگیری درخواست‌های ثبت‌شده کاربران
        </p>

    </div>


    <!-- Statistics -->

    <div class="ticket-stats">

        <div class="ticket-stat">

            <div class="ticket-stat-number">
                <?php echo persianNumber($stats['all']); ?>
            </div>

            <div class="ticket-stat-label">
                کل درخواست‌ها
            </div>

        </div>


        <div class="ticket-stat">

            <div class="ticket-stat-number">
                <?php echo persianNumber($stats['new']); ?>
            </div>

            <div class="ticket-stat-label">
                جدید
            </div>

        </div>


        <div class="ticket-stat">

            <div class="ticket-stat-number">
                <?php echo persianNumber($stats['in_progress']); ?>
            </div>

            <div class="ticket-stat-label">
                در حال بررسی
            </div>

        </div>


        <div class="ticket-stat">

            <div class="ticket-stat-number">
                <?php echo persianNumber($stats['waiting_user']); ?>
            </div>

            <div class="ticket-stat-label">
                منتظر پاسخ کاربر
            </div>

        </div>


        <div class="ticket-stat">

            <div class="ticket-stat-number">
                <?php echo persianNumber($stats['resolved']); ?>
            </div>

            <div class="ticket-stat-label">
                حل شده
            </div>

        </div>


        <div class="ticket-stat">

            <div class="ticket-stat-number">
                <?php echo persianNumber($stats['closed']); ?>
            </div>

            <div class="ticket-stat-label">
                بسته شده
            </div>

        </div>

    </div>


    <!-- Filters -->

    <div class="ticket-filters">

        <form method="get" action="tickets.php">


            <div class="ticket-filter-group">

                <label>
                    جستجو
                </label>

                <input
                    type="text"
                    name="search"
                    value="<?php echo htmlspecialchars($search); ?>"
                    placeholder="شماره پیگیری، موضوع، نام یا نام کاربری"
                >

            </div>


            <div class="ticket-filter-group">

                <label>
                    وضعیت
                </label>

                <select name="status">

                    <option value="">
                        همه وضعیت‌ها
                    </option>

                    <?php foreach ($statusLabels as $key => $label): ?>

                        <option
                            value="<?php echo htmlspecialchars($key); ?>"
                            <?php echo ($status === $key) ? 'selected' : ''; ?>
                        >
                            <?php echo htmlspecialchars($label); ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="ticket-filter-group">

                <label>
                    اولویت
                </label>

                <select name="priority">

                    <option value="">
                        همه اولویت‌ها
                    </option>

                    <?php foreach ($priorityLabels as $key => $label): ?>

                        <option
                            value="<?php echo htmlspecialchars($key); ?>"
                            <?php echo ($priority === $key) ? 'selected' : ''; ?>
                        >
                            <?php echo htmlspecialchars($label); ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="ticket-filter-group">

                <label>
                    واحد
                </label>

                <select name="department">

                    <option value="">
                        همه واحدها
                    </option>

                    <?php foreach ($departmentLabels as $key => $label): ?>

                        <option
                            value="<?php echo htmlspecialchars($key); ?>"
                            <?php echo ($department === $key) ? 'selected' : ''; ?>
                        >
                            <?php echo htmlspecialchars($label); ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <button
                type="submit"
                class="ticket-filter-button"
            >
                🔎 جستجو
            </button>


            <a
                href="tickets.php"
                class="ticket-filter-reset"
            >
                پاک کردن
            </a>


        </form>

    </div>


    <!-- Tickets -->

    <div class="ticket-table-box">

        <?php if (empty($tickets)): ?>

            <div class="ticket-empty">

                هیچ درخواستی با این مشخصات پیدا نشد.

            </div>

        <?php else: ?>

            <table class="ticket-table">

                <thead>

                    <tr>

                        <th>
                            شماره پیگیری
                        </th>

                        <th>
                            درخواست‌کننده
                        </th>

                        <th>
                            موضوع
                        </th>

                        <th>
                            نوع درخواست
                        </th>

                        <th>
                            واحد
                        </th>

                        <th>
                            اولویت
                        </th>

                        <th>
                            وضعیت
                        </th>

                        <th>
                            تاریخ ثبت
                        </th>

                        <th>
                            عملیات
                        </th>

                    </tr>

                </thead>


                <tbody>

                <?php foreach ($tickets as $ticket): ?>

                    <tr>

                        <td>

                            <div class="ticket-number">
                                <?php
                                echo htmlspecialchars(
                                    $ticket['tracking_number']
                                );
                                ?>
                            </div>

                        </td>


                        <td>

                            <div class="ticket-requester">

                                <?php
                                echo htmlspecialchars(
                                    $ticket['fullname']
                                );
                                ?>

                                <br>

                                <small>
                                    <?php
                                    echo htmlspecialchars(
                                        $ticket['requester_username']
                                    );
                                    ?>
                                </small>

                            </div>

                        </td>


                        <td>

                            <div class="ticket-subject">

                                <?php
                                echo htmlspecialchars(
                                    $ticket['subject']
                                );
                                ?>

                            </div>

                        </td>


                        <td>

                            <?php
                            echo !empty($ticket['request_types'])
                                ? htmlspecialchars($ticket['request_types'])
                                : '-';
                            ?>

                        </td>


                        <td>

                            <?php
                            echo isset(
                                $departmentLabels[$ticket['department']]
                            )
                                ? htmlspecialchars(
                                    $departmentLabels[$ticket['department']]
                                )
                                : htmlspecialchars(
                                    $ticket['department']
                                );
                            ?>

                        </td>


                        <td>

                            <?php
                            $priorityClass =
                                'priority-' . $ticket['priority'];

                            $priorityText =
                                isset(
                                    $priorityLabels[$ticket['priority']]
                                )
                                    ? $priorityLabels[$ticket['priority']]
                                    : $ticket['priority'];
                            ?>

                            <span
                                class="ticket-badge <?php echo $priorityClass; ?>"
                            >
                                <?php
                                echo htmlspecialchars(
                                    $priorityText
                                );
                                ?>
                            </span>

                        </td>


                        <td>

                            <?php
                            $statusClass =
                                'status-' . $ticket['status'];

                            $statusText =
                                isset(
                                    $statusLabels[$ticket['status']]
                                )
                                    ? $statusLabels[$ticket['status']]
                                    : $ticket['status'];
                            ?>

                            <span
                                class="ticket-badge <?php echo $statusClass; ?>"
                            >
                                <?php
                                echo htmlspecialchars(
                                    $statusText
                                );
                                ?>
                            </span>

                        </td>


                        <td>

                            <div class="ticket-date">

                                <?php
                                echo htmlspecialchars(
                                    jalaliDate(
                                        $ticket['created_at']
                                    )
                                );
                                ?>

                            </div>

                        </td>


                        <td>

                            <a
                                href="ticket-view.php?id=<?php echo (int)$ticket['id']; ?>"
                                class="ticket-view-button"
                            >
                                مشاهده
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        <?php endif; ?>

    </div>

</div>


<?php require_once __DIR__ . '/includes/footer.php'; ?>
