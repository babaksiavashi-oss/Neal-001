<?php
declare(strict_types=1);

/*
 * این فایل فقط از backup-create.php و به‌صورت CLI اجرا می‌شود.
 * عمداً از مسیر عمومی وب قابل استفاده نیست.
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('CLI only.');
}

$jobId = (string)($argv[1] ?? '');

if (!preg_match('/^[A-Za-z0-9_]+$/', $jobId)) {
    exit(2);
}

$root = '/usr/local/www/apache24/data/neal';
$backupRoot = '/usr/local/backups/neal';
$jobsDir = $backupRoot . '/jobs';
$filesDir = $backupRoot . '/files';
$tmpRoot = $backupRoot . '/tmp';

$jobFile = $jobsDir . '/' . $jobId . '.json';

function worker_update(array $changes): void
{
    global $jobFile;

    $current = [];
    if (is_file($jobFile)) {
        $decoded = json_decode((string)@file_get_contents($jobFile), true);
        if (is_array($decoded)) {
            $current = $decoded;
        }
    }

    $current = array_merge($current, $changes);
    @file_put_contents(
        $jobFile,
        json_encode($current, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
        LOCK_EX
    );
}

function worker_fail(string $message): never
{
    worker_update([
        'status' => 'error',
        'stage' => 'error',
        'stage_label' => 'خطا',
        'progress' => 0,
        'message' => $message,
        'current_file' => ''
    ]);
    exit(1);
}

function worker_size(string $file): int
{
    $size = @filesize($file);
    return $size === false ? 0 : (int)$size;
}

function collect_files(string $root): array
{
    $result = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(
            $root,
            FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_FILEINFO
        ),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($iterator as $info) {
        if (!$info->isFile() || $info->isLink()) {
            continue;
        }

        $path = $info->getPathname();
        $relative = substr($path, strlen($root) + 1);
        $relative = str_replace(DIRECTORY_SEPARATOR, '/', $relative);

        /*
         * دیتابیس زنده، فایل‌های موقت و هر Backup قدیمی نباید داخل Backup سایت
         * قرار بگیرند. Backupها بیرون root هستند، ولی این شرط برای ایمنی اضافه است.
         */
        if ($relative === 'data/neal.db'
            || preg_match('#^data/neal\.db-(wal|shm)$#', $relative)
            || preg_match('#^backup-(tmp|job)#i', $relative)
            || preg_match('#^\.git(?:/|$)#', $relative)
        ) {
            continue;
        }

        $result[] = [
            'absolute' => $path,
            'relative' => $relative,
            'size' => worker_size($path)
        ];
    }

    usort($result, static function ($a, $b) {
        return strcmp($a['relative'], $b['relative']);
    });

    return $result;
}

function copy_recursive(string $source, string $destination): void
{
    if (!is_dir($destination) && !@mkdir($destination, 0750, true)) {
        throw new RuntimeException('ایجاد پوشه موقت ممکن نشد.');
    }

    $items = @scandir($source);
    if ($items === false) {
        throw new RuntimeException('خواندن پوشه موقت ممکن نشد.');
    }

    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }

        $src = $source . '/' . $item;
        $dst = $destination . '/' . $item;

        if (is_link($src)) {
            continue;
        }

        if (is_dir($src)) {
            copy_recursive($src, $dst);
        } elseif (is_file($src)) {
            if (!@copy($src, $dst)) {
                throw new RuntimeException('کپی فایل دیتابیس موقت انجام نشد.');
            }
        }
    }
}

function create_zip_with_cli(array $files, string $sourceRoot, string $zipFile, ?string $extraRoot = null): void
{
    $zipBinary = '';

    foreach (['/usr/bin/zip', '/usr/local/bin/zip'] as $candidate) {
        if (is_executable($candidate)) {
            $zipBinary = $candidate;
            break;
        }
    }

    if ($zipBinary === '') {
        $which = trim((string)@shell_exec('command -v zip 2>/dev/null'));
        if ($which !== '' && is_executable($which)) {
            $zipBinary = $which;
        }
    }

    if ($zipBinary === '') {
        throw new RuntimeException('برنامه zip روی سرور نصب نیست. ابتدا package مربوط به zip را نصب کنید.');
    }

    @unlink($zipFile);

    $total = 0;
    foreach ($files as $file) {
        $total += (int)$file['size'];
    }

    $done = 0;
    $count = count($files);

    foreach ($files as $index => $file) {
        $relative = str_replace('\\', '/', $file['relative']);
        $absolute = $file['absolute'];

        worker_update([
            'status' => 'running',
            'stage' => 'compressing',
            'stage_label' => 'در حال فشرده‌سازی',
            'message' => 'در حال افزودن فایل‌ها به ZIP...',
            'current_file' => $relative,
            'progress' => $total > 0
                ? min(94, 8 + (($done / $total) * 86))
                : min(94, 8 + (($index / max(1, $count)) * 86))
        ]);

        $cmd = 'cd ' . escapeshellarg($sourceRoot)
            . ' && ' . escapeshellarg($zipBinary)
            . ' -q -9 ' . escapeshellarg($zipFile)
            . ' ' . escapeshellarg($relative)
            . ' 2>&1';

        exec($cmd, $output, $code);

        if ($code !== 0) {
            throw new RuntimeException(
                'خطا در فشرده‌سازی فایل «' . $relative . '».'
            );
        }

        $done += (int)$file['size'];
    }

    if ($extraRoot !== null && is_dir($extraRoot)) {
        $extraFiles = [];
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($extraRoot, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($it as $info) {
            if (!$info->isFile() || $info->isLink()) {
                continue;
            }

            $absolute = $info->getPathname();
            $relative = 'database/' . str_replace(
                DIRECTORY_SEPARATOR,
                '/',
                substr($absolute, strlen($extraRoot) + 1)
            );

            $extraFiles[] = [
                'absolute' => $absolute,
                'relative' => $relative,
                'size' => worker_size($absolute)
            ];
        }

        foreach ($extraFiles as $file) {
            worker_update([
                'stage' => 'compressing',
                'stage_label' => 'در حال فشرده‌سازی دیتابیس',
                'message' => 'در حال افزودن نسخه دیتابیس...',
                'current_file' => $file['relative'],
                'progress' => 94
            ]);

            $tempRelative = str_replace('\\', '/', $file['relative']);
            $dbFile = $file['absolute'];

            /*
             * برای وارد کردن مسیر database/... به ZIP، از -j استفاده نمی‌کنیم؛
             * یک temp staging با ساختار database ایجاد می‌کنیم.
             */
            $staging = dirname($extraRoot) . '/zip_database_stage';
            @mkdir($staging . '/database', 0750, true);
            $target = $staging . '/' . $tempRelative;

            if (!@copy($dbFile, $target)) {
                throw new RuntimeException('کپی دیتابیس به staging انجام نشد.');
            }

            $cmd = 'cd ' . escapeshellarg($staging)
                . ' && ' . escapeshellarg($zipBinary)
                . ' -q -9 ' . escapeshellarg($zipFile)
                . ' ' . escapeshellarg($tempRelative)
                . ' 2>&1';

            exec($cmd, $output, $code);

            @unlink($target);
            @rmdir($staging . '/database');
            @rmdir($staging);

            if ($code !== 0) {
                throw new RuntimeException('افزودن دیتابیس به ZIP انجام نشد.');
            }
        }
    }
}

if (!is_file($jobFile)) {
    exit(3);
}

$job = json_decode((string)@file_get_contents($jobFile), true);
if (!is_array($job)) {
    exit(4);
}

$type = $job['type'] ?? '';

if (!in_array($type, ['files','database','full'], true)) {
    worker_fail('نوع پشتیبان‌گیری نامعتبر است.');
}

if (!is_dir($filesDir) && !@mkdir($filesDir, 0750, true)) {
    worker_fail('پوشه ذخیره Backup قابل ایجاد نیست.');
}
if (!is_dir($tmpRoot) && !@mkdir($tmpRoot, 0750, true)) {
    worker_fail('پوشه موقت Backup قابل ایجاد نیست.');
}

$zipFile = $filesDir . '/' . basename((string)$job['filename']);
$tmpDir = $tmpRoot . '/' . $jobId;
$dbStage = $tmpDir . '/database';

try {
    worker_update([
        'status' => 'running',
        'stage' => 'preparing',
        'stage_label' => 'در حال آماده‌سازی',
        'progress' => 3,
        'message' => 'در حال بررسی فایل‌ها و آماده‌سازی اطلاعات...',
        'current_file' => ''
    ]);

    if (is_dir($tmpDir)) {
        @exec('rm -rf ' . escapeshellarg($tmpDir));
    }
    @mkdir($tmpDir, 0750, true);

    $siteFiles = [];
    if ($type === 'files' || $type === 'full') {
        $siteFiles = collect_files($root);

        if (!$siteFiles) {
            throw new RuntimeException('هیچ فایل قابل پشتیبانی در پروژه پیدا نشد.');
        }
    }

    $dbStageRoot = null;

    if ($type === 'database' || $type === 'full') {
        $dbFile = $root . '/data/neal.db';

        if (!is_file($dbFile)) {
            throw new RuntimeException('فایل دیتابیس neal.db پیدا نشد.');
        }

        @mkdir($dbStage, 0750, true);
        $stagedDb = $dbStage . '/neal.db';

        worker_update([
            'stage' => 'database',
            'stage_label' => 'در حال آماده‌سازی دیتابیس',
            'progress' => 5,
            'message' => 'در حال تهیه نسخه سازگار از دیتابیس...',
            'current_file' => 'data/neal.db'
        ]);

        $sqlite = '/usr/local/bin/sqlite3';
        if (!is_executable($sqlite)) {
            $which = trim((string)@shell_exec('command -v sqlite3 2>/dev/null'));
            if ($which !== '') {
                $sqlite = $which;
            }
        }

        if (!is_executable($sqlite)) {
            throw new RuntimeException('برنامه sqlite3 روی سرور پیدا نشد.');
        }

        $cmd = escapeshellarg($sqlite)
            . ' ' . escapeshellarg($dbFile)
            . ' ' . escapeshellarg(".backup " . $stagedDb)
            . ' 2>&1';

        exec($cmd, $output, $code);

        if ($code !== 0 || !is_file($stagedDb) || worker_size($stagedDb) === 0) {
            /*
             * fallback برای سیستم‌هایی که .backup را قبول نمی‌کنند.
             */
            if (!@copy($dbFile, $stagedDb)) {
                throw new RuntimeException('تهیه نسخه پشتیبان دیتابیس انجام نشد.');
            }
        }

        $dbStageRoot = $dbStage;
    }

    worker_update([
        'stage' => 'compressing',
        'stage_label' => 'در حال فشرده‌سازی',
        'progress' => 8,
        'message' => 'در حال ساخت فایل ZIP...',
        'current_file' => ''
    ]);

    /*
     * برای Backup فایل‌ها، zip از داخل ریشه پروژه اجرا می‌شود.
     * برای Backup دیتابیس تنها، یک لیست کوچک از staging ساخته می‌شود.
     */
    if ($type === 'database') {
        $dbFiles = [[
            'absolute' => $dbStage . '/neal.db',
            'relative' => 'database/neal.db',
            'size' => worker_size($dbStage . '/neal.db')
        ]];

        create_zip_with_cli(
            $dbFiles,
            $dbStage . '/..',
            $zipFile,
            null
        );
    } elseif ($type === 'files') {
        create_zip_with_cli($siteFiles, $root, $zipFile, null);
    } else {
        create_zip_with_cli($siteFiles, $root, $zipFile, $dbStage);
    }

    worker_update([
        'stage' => 'finalizing',
        'stage_label' => 'در حال نهایی‌سازی',
        'progress' => 97,
        'message' => 'در حال بررسی فایل نهایی...',
        'current_file' => ''
    ]);

    if (!is_file($zipFile) || worker_size($zipFile) === 0) {
        throw new RuntimeException('فایل ZIP نهایی ایجاد نشد.');
    }

    $finalSize = worker_size($zipFile);

    worker_update([
        'status' => 'success',
        'stage' => 'done',
        'stage_label' => 'تکمیل شد',
        'progress' => 100,
        'message' => 'پشتیبان با موفقیت ایجاد شد.',
        'current_file' => basename($zipFile),
        'size' => $finalSize
    ]);

    @exec('rm -rf ' . escapeshellarg($tmpDir));
    exit(0);

} catch (Throwable $e) {
    @unlink($zipFile);
    @exec('rm -rf ' . escapeshellarg($tmpDir));

    worker_fail($e->getMessage());
}
