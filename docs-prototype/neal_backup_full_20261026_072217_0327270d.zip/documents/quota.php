<?php
declare(strict_types=1);
require_once __DIR__.'/common.php';
$actor=neal_docs_require_admin();
$db=neal_docs_db();
neal_docs_quota_ensure($db);
$error='';$success='';
$search=trim((string)($_GET['q']??''));
$page=max(1,(int)($_GET['page']??1));
$perPage=10;
if($_SERVER['REQUEST_METHOD']==='POST'){
  neal_docs_csrf_check();
  try{
    $userId=max(0,(int)($_POST['user_id']??0));
    $quotaRaw=trim((string)($_POST['quota_value']??''));
    $quotaUnit=(string)($_POST['quota_unit']??'GB');
    if($userId<1) throw new RuntimeException('کاربر انتخاب‌شده معتبر نیست.');
    if(!in_array($quotaUnit,['MB','GB'],true)) throw new RuntimeException('واحد سهمیه معتبر نیست؛ MB یا GB را انتخاب کنید.');
    if($quotaRaw==='' || !is_numeric($quotaRaw)) throw new RuntimeException('مقدار سهمیه را به MB یا GB وارد کنید؛ مقدار صفر یعنی بدون محدودیت.');
    $quotaValue=(float)$quotaRaw;
    $maxValue=$quotaUnit==='MB'?102400000:100000;
    if($quotaValue<0 || $quotaValue>$maxValue) throw new RuntimeException('مقدار سهمیه از محدوده مجاز بیشتر است.');
    $u=$db->prepare('SELECT id,username FROM users WHERE id=? AND is_active=1');$u->execute([$userId]);$user=$u->fetch();
    if(!$user) throw new RuntimeException('کاربر فعال پیدا نشد.');
    $multiplier=$quotaUnit==='MB' ? 1024*1024 : 1024*1024*1024;
    $bytes=(int)round($quotaValue*$multiplier);
    $q=$db->prepare('INSERT INTO document_user_quotas(user_id,quota_bytes,updated_by_admin_id,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET quota_bytes=excluded.quota_bytes,updated_by_admin_id=excluded.updated_by_admin_id,updated_at=CURRENT_TIMESTAMP');
    $q->execute([$userId,$bytes,$actor['id']]);
    neal_docs_audit($db,$actor,'quota.update','system',$userId,'success','quota_bytes='.$bytes);
    $success='سهمیه فضای کاربر «'.(string)$user['username'].'» ذخیره شد.';
  }catch(Throwable $e){$error=$e instanceof RuntimeException?$e->getMessage():'ذخیره سهمیه ناموفق بود.';}
}
$where=' WHERE is_active=1';
$params=[];
if($search!==''){
  $where.=' AND username LIKE ? COLLATE NOCASE';
  $params[]='%'.$search.'%';
}
$countStmt=$db->prepare('SELECT COUNT(*) FROM users'.$where);
$countStmt->execute($params);
$totalUsers=(int)$countStmt->fetchColumn();
$totalPages=max(1,(int)ceil($totalUsers/$perPage));
$page=min($page,$totalPages);
$offset=($page-1)*$perPage;
$userStmt=$db->prepare('SELECT id,username FROM users'.$where.' ORDER BY username COLLATE NOCASE LIMIT ? OFFSET ?');
$userStmt->execute([...$params,$perPage,$offset]);
$users=$userStmt->fetchAll();
$page_title='سهمیه فضای کاربران';$page_base_href='/neal/';$portal_mode=false;
require dirname(__DIR__).'/includes/header.php';
?>
<style>
.quota-page{max-width:1250px;margin:0 auto;padding:10px 24px 36px;color:#172b4d;font-family:Vazirmatn,Tahoma,sans-serif}.quota-hero{padding:25px 28px;border-radius:20px;background:linear-gradient(120deg,#102a43,#1769aa,#2a9d9f);color:white;display:flex;align-items:center;justify-content:space-between;gap:15px;flex-wrap:wrap;box-shadow:0 14px 32px #102a431b}.quota-hero h1{margin:6px 0;font-size:23px}.quota-hero p{margin:0;font-size:12px;line-height:1.9;color:#e1eff9}.quota-btn{display:inline-flex;align-items:center;justify-content:center;padding:9px 13px;border-radius:10px;text-decoration:none;border:0;background:#1769aa;color:#fff;font:700 12px Vazirmatn,Tahoma,sans-serif;cursor:pointer}.quota-panel{margin-top:18px;background:#fff;border:1px solid #e5eaf2;border-radius:17px;overflow:hidden}.quota-head{padding:17px 20px;border-bottom:1px solid #edf1f6}.quota-head h2{font-size:14px;margin:0}.quota-head p{font-size:11px;color:#6b7a90;margin:6px 0 0}.quota-tools{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:14px}.quota-search{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.quota-search input{width:240px;max-width:100%;padding:9px 11px;border:1px solid #dce4ee;border-radius:9px;font:12px Vazirmatn,Tahoma,sans-serif}.quota-secondary{background:#eef4f8;color:#344054}.quota-pagination{display:flex;align-items:center;justify-content:center;gap:6px;flex-wrap:wrap;padding:16px;border-top:1px solid #edf1f6}.quota-page-link{display:inline-flex;min-width:34px;height:34px;padding:0 10px;align-items:center;justify-content:center;border:1px solid #dce4ee;border-radius:9px;text-decoration:none;color:#344054;font-size:12px;background:#fff}.quota-page-link.active{background:#1769aa;color:#fff;border-color:#1769aa;font-weight:800}.quota-page-link.disabled{opacity:.4;pointer-events:none}.quota-table{width:100%;border-collapse:collapse}.quota-table th,.quota-table td{text-align:right;padding:13px 15px;border-bottom:1px solid #edf1f6;font-size:11px;vertical-align:middle}.quota-table th{background:#f8fafc;color:#667085;font-weight:800}.quota-table tr:last-child td{border-bottom:0}.quota-input{width:110px;max-width:100%;padding:8px;border:1px solid #dce4ee;border-radius:8px;font:12px Vazirmatn,Tahoma,sans-serif}.quota-muted{font-size:10px;color:#8996a8;margin-top:5px}.quota-bar{height:7px;background:#edf1f6;border-radius:99px;overflow:hidden;min-width:100px;margin-top:6px}.quota-bar span{display:block;height:100%;border-radius:99px;background:#2a9d9f}.quota-alert{padding:12px 15px;border-radius:11px;margin:14px 0;font-size:12px}.quota-error{background:#fff1f0;color:#b42318}.quota-success{background:#eaf8f0;color:#087443}.quota-table-wrap{overflow-x:auto}@media(max-width:700px){.quota-page{padding:8px 10px 24px}.quota-hero{padding:20px}.quota-table{min-width:720px}.quota-search{width:100%}.quota-search input{flex:1;min-width:150px;width:auto}}
</style>
<main class="quota-page">
<section class="quota-hero"><div><div style="font-size:10px;color:#c5e5f7;font-weight:800">NEAL PHARMED · STORAGE CONTROL</div><h1>سهمیه فضای اسناد کاربران</h1><p>برای هر کاربر سقف فضای مصرفی تعریف کنید. مقدار صفر یعنی بدون محدودیت؛ پس از تعیین سقف، بارگذاری و ذخیره ویرایش‌های بزرگ‌تر از فضای باقی‌مانده مسدود می‌شود.</p></div><a class="quota-btn" style="background:#fff;color:#164e7a" href="/neal/documents/index.php">← بازگشت به اسناد</a></section>
<?php if($error!==''):?><div class="quota-alert quota-error"><?=neal_docs_h($error)?></div><?php endif;?>
<?php if($success!==''):?><div class="quota-alert quota-success"><?=neal_docs_h($success)?></div><?php endif;?>
<section class="quota-panel"><div class="quota-head"><h2>کاربران فعال و مصرف فعلی</h2><p>مصرف محاسبه‌شده شامل فایل‌های فعال فعلی است که کاربر بارگذاری کرده یا در پوشه شخصی خودش قرار دارند؛ نسخه‌های تاریخی فایل‌ها در سهمیه منطقی محاسبه نمی‌شوند.</p>
<div class="quota-tools"><form class="quota-search" method="get" action="/neal/documents/quota.php"><input type="search" name="q" value="<?=neal_docs_h($search)?>" placeholder="جست‌وجوی نام کاربری…" aria-label="جست‌وجوی نام کاربری"><button class="quota-btn" type="submit">جست‌وجو</button><?php if($search!==''):?><a class="quota-btn quota-secondary" href="/neal/documents/quota.php">پاک‌کردن</a><?php endif;?></form><div style="font-size:11px;color:#667085">نمایش <?= $totalUsers>0 ? ($offset+1) : 0 ?> تا <?=min($offset+$perPage,$totalUsers)?> از <?=$totalUsers?> کاربر · صفحه <?=$page?> از <?=$totalPages?></div></div>
</div>
<div class="quota-table-wrap"><table class="quota-table"><thead><tr><th>کاربر</th><th>مصرف فعلی</th><th>سقف فعلی</th><th>فضای باقی‌مانده</th><th>تعیین سقف جدید (MB یا GB)</th><th>عملیات</th></tr></thead><tbody>
<?php foreach($users as $u): $uid=(int)$u['id'];$info=neal_docs_user_storage_info($db,$uid); ?>
<tr><td><strong><?=neal_docs_h((string)$u['username'])?></strong><div class="quota-muted">شناسه #<?=$uid?></div></td><td><?=neal_docs_h(neal_docs_bytes_label($info['used']))?><div class="quota-bar"><span style="width:<?=$info['quota']>0?(int)$info['percent']:0?>%;background:<?=$info['over_quota']?'#d92d20':($info['percent']>=85?'#f79009':'#2a9d9f')?>"></span></div></td><td><?=$info['quota']>0?neal_docs_h(neal_docs_bytes_label($info['quota'])):'بدون محدودیت'?></td><td><?=$info['quota']>0?neal_docs_h(neal_docs_bytes_label((int)$info['remaining'])):'نامحدود'?></td><td><form id="quota-form-<?=$uid?>" method="post" action="<?=neal_docs_h('/neal/documents/quota.php?'.http_build_query(['q'=>$search,'page'=>$page]))?>"></form><input form="quota-form-<?=$uid?>" type="hidden" name="_csrf" value="<?=neal_docs_h(neal_docs_csrf_token())?>"><input form="quota-form-<?=$uid?>" type="hidden" name="user_id" value="<?=$uid?>"><?php $unitForInput=($info['quota']>0 && $info['quota']<1073741824)?'MB':'GB'; $valueForInput=$info['quota']>0?($unitForInput==='MB'?$info['quota']/1048576:$info['quota']/1073741824):0; ?><div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap"><input form="quota-form-<?=$uid?>" class="quota-input" style="width:100px" type="number" name="quota_value" min="0" step="any" value="<?=number_format($valueForInput,2,'.','')?>" required><select form="quota-form-<?=$uid?>" name="quota_unit" aria-label="واحد سهمیه" style="padding:8px;border:1px solid #dce4ee;border-radius:8px;font:12px Vazirmatn,Tahoma,sans-serif"><option value="MB" <?=$unitForInput==='MB'?'selected':''?>>MB</option><option value="GB" <?=$unitForInput==='GB'?'selected':''?>>GB</option></select><div class="quota-muted" style="width:100%">۰ = بدون محدودیت · ۱ GB = ۱۰۲۴ MB</div></div></td><td><button form="quota-form-<?=$uid?>" class="quota-btn" type="submit">ذخیره سهمیه</button></td></tr>
<?php endforeach;?>
<?php if(!$users):?><tr><td colspan="6" style="text-align:center;padding:30px;color:#8996a8"><?php echo $search!==''?'کاربری با این عبارت پیدا نشد.':'کاربر فعالی پیدا نشد.'; ?></td></tr><?php endif;?>
</tbody></table></div>
<?php if($totalPages>1):?><nav class="quota-pagination" aria-label="صفحه‌بندی کاربران">
<a class="quota-page-link <?=$page<=1?'disabled':''?>" href="<?=neal_docs_h('/neal/documents/quota.php?'.http_build_query(['q'=>$search,'page'=>max(1,$page-1)]))?>" aria-label="صفحه قبل">قبلی</a>
<?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++):?><a class="quota-page-link <?=$p===$page?'active':''?>" href="<?=neal_docs_h('/neal/documents/quota.php?'.http_build_query(['q'=>$search,'page'=>$p]))?>" <?=$p===$page?'aria-current="page"':''?>><?=$p?></a><?php endfor;?>
<a class="quota-page-link <?=$page>=$totalPages?'disabled':''?>" href="<?=neal_docs_h('/neal/documents/quota.php?'.http_build_query(['q'=>$search,'page'=>min($totalPages,$page+1)]))?>" aria-label="صفحه بعد">بعدی</a>
</nav><?php endif;?></section>
</main>
<?php require dirname(__DIR__).'/includes/footer.php'; ?>
