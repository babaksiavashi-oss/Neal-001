-- Run once against the production DB after taking a verified backup.
CREATE TABLE IF NOT EXISTS document_file_versions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 file_id INTEGER NOT NULL REFERENCES document_files(id) ON DELETE RESTRICT,
 version INTEGER NOT NULL,
 storage_id TEXT NOT NULL UNIQUE,
 file_size INTEGER NOT NULL DEFAULT 0 CHECK(file_size>=0),
 mime_type TEXT NOT NULL,
 created_by_admin_id INTEGER NULL REFERENCES admins(id) ON DELETE RESTRICT,
 created_by_user_id INTEGER NULL REFERENCES users(id) ON DELETE RESTRICT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(file_id,version)
);
CREATE INDEX IF NOT EXISTS idx_doc_file_versions_file ON document_file_versions(file_id,version DESC);
CREATE TABLE IF NOT EXISTS document_edit_sessions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 session_key TEXT NOT NULL UNIQUE,
 file_id INTEGER NOT NULL REFERENCES document_files(id) ON DELETE CASCADE,
 actor_type TEXT NOT NULL CHECK(actor_type IN ('admin','user')),
 actor_id INTEGER NOT NULL,
 original_storage_id TEXT NOT NULL,
 expires_at TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','saved','expired','cancelled')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_doc_edit_sessions_active ON document_edit_sessions(session_key,file_id,status,expires_at);
