<?php
declare(strict_types=1);
require_once __DIR__.'/common.php';
header('Content-Type: application/json; charset=utf-8');
function oo_reply(int $code,array $data): never { http_response_code($code); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Allow: POST');oo_reply(405,['error'=>1]);}
$newStorageForCleanup=null;
try{
    $c=neal_docs_config();if($c['onlyoffice_outbox_secret']==='')throw new RuntimeException('Callback secret is not configured.');
    $auth=(string)($_SERVER['HTTP_AUTHORIZATION']??$_SERVER['REDIRECT_HTTP_AUTHORIZATION']??'');$jwt='';if(preg_match('/^Bearer\s+(.+)$/i',$auth,$m))$jwt=trim($m[1]);if($jwt===''){$raw=file_get_contents('php://input');$input=json_decode((string)$raw,true);if(is_array($input)&&isset($input['token']))$jwt=(string)$input['token'];}else{$raw=file_get_contents('php://input');$input=json_decode((string)$raw,true);}
    if(!is_array($input))oo_reply(400,['error'=>1]);$payload=$jwt!==''?neal_docs_jwt_decode($jwt,$c['onlyoffice_outbox_secret']):[];
    // ONLYOFFICE signs the callback payload; require the signed claims to match the callback body.
    if($jwt!=='' && isset($payload['payload']) && is_array($payload['payload']))$claims=$payload['payload'];else $claims=$payload;
    // Validate signed callback fields; url is not present in every status.
    foreach(['key','status'] as $k){
        if(!array_key_exists($k,$input)||!array_key_exists($k,$claims)||(string)$input[$k] !== (string)$claims[$k])oo_reply(403,['error'=>1]);
    }
    if(array_key_exists('url',$claims)){
        if(!array_key_exists('url',$input)||(string)$input['url'] !== (string)$claims['url'])oo_reply(403,['error'=>1]);
    }
    $key=(string)$input['key'];
    $status=(int)$input['status'];
    if(!preg_match('/^neal-(\d+)-([a-f0-9]{48})$/',$key,$m))oo_reply(400,['error'=>1]);
    $fileId=(int)$m[1];
    $sessionKey=$m[2];
    if(in_array($status,[2,6],true) && (empty($input['url']) || !array_key_exists('url',$claims))){
        error_log('NEAL ONLYOFFICE callback: missing signed download URL for save status '.$status);
        oo_reply(403,['error'=>1]);
    }
    $key=(string)$input['key'];$status=(int)$input['status'];if(!preg_match('/^neal-(\d+)-([a-f0-9]{48})$/',$key,$m))oo_reply(400,['error'=>1]);$fileId=(int)$m[1];$sessionKey=$m[2];
    if(!in_array($status,[2,6],true))oo_reply(200,['error'=>0]);
    $url=(string)$input['url'];$parsed=parse_url($url);$base=parse_url($c['onlyoffice_url']);if(!$parsed||!$base||empty($parsed['host'])||empty($base['host'])||strtolower($parsed['host'])!==strtolower($base['host'])||strtolower((string)($parsed['scheme']??''))!==strtolower((string)($base['scheme']??''))||(int)($parsed['port']??(($parsed['scheme']??'')==='https'?443:80))!==(int)($base['port']??(($base['scheme']??'')==='https'?443:80)))oo_reply(403,['error'=>1]);
    $db=neal_docs_db();$s=$db->prepare("SELECT * FROM document_edit_sessions WHERE session_key=? AND file_id=? AND status='open' AND expires_at>=datetime('now')");$s->execute([$sessionKey,$fileId]);$session=$s->fetch();if(!$session)oo_reply(200,['error'=>0]);
    $f=$db->prepare('SELECT * FROM document_files WHERE id=? AND is_deleted=0');$f->execute([$fileId]);$file=$f->fetch();if(!$file||(string)$file['storage_id']!==(string)$session['original_storage_id'])oo_reply(409,['error'=>1]);
    $ch=curl_init($url);$download='';$tooLarge=false;curl_setopt_array($ch,[CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>120,CURLOPT_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS,CURLOPT_WRITEFUNCTION=>function($ch,$chunk)use(&$download,&$tooLarge){if(strlen($download)+strlen($chunk)>100*1024*1024){$tooLarge=true;return 0;}$download.=$chunk;return strlen($chunk);}]);$ok=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$err=curl_error($ch);curl_close($ch);if($ok===false||$http!==200||$tooLarge||$download===''){error_log('NEAL ONLYOFFICE callback download failed: '.$err.' HTTP='.$http);oo_reply(502,['error'=>1]);}
    $actor=['type'=>$session['actor_type'],'id'=>(int)$session['actor_id']];
    $newSize=strlen($download);
    if($actor['type']==='user' && $newSize>(int)$file['file_size']) {
        $ownerQuery=$db->prepare("SELECT f.folder_type,f.owner_user_id,df.created_by_user_id FROM document_files df JOIN document_folders f ON f.id=df.folder_id WHERE df.id=?");
        $ownerQuery->execute([$fileId]);$attribution=$ownerQuery->fetch();
        $countsForActor=$attribution && ((int)($attribution['created_by_user_id']??0)===$actor['id'] || ($attribution['folder_type']==='personal' && (int)($attribution['owner_user_id']??0)===$actor['id']));
        if($countsForActor) {
            $quota=neal_docs_user_storage_quota($db,$actor['id']);
            if($quota>0) {
                $used=neal_docs_user_storage_usage($db,$actor['id']);
                if($used+($newSize-(int)$file['file_size'])>$quota) {
                    error_log('NEAL ONLYOFFICE save rejected: user quota exceeded for user '.$actor['id']);
                    oo_reply(409,['error'=>1,'message'=>'User storage quota exceeded']);
                }
            }
        }
    }
    $ext=strtolower((string)$file['extension']);$newStorage=bin2hex(random_bytes(24)).'.'.$ext;$newStorageForCleanup=$newStorage;$upload=neal_docs_storage_request('POST','/files',$download,['Content-Type: application/octet-stream','X-Document-Key: '.$newStorage]);if($upload['status']!==200)throw new RuntimeException('Storage upload failed HTTP '.$upload['status']);
    $db->beginTransaction();
    $v=$db->prepare('INSERT INTO document_file_versions(file_id,version,storage_id,file_size,mime_type,created_by_admin_id,created_by_user_id,created_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)');$v->execute([$fileId,(int)$file['version'],(string)$file['storage_id'],(int)$file['file_size'],(string)$file['mime_type'],$session['actor_type']==='admin'?(int)$session['actor_id']:null,$session['actor_type']==='user'?(int)$session['actor_id']:null]);
    $actor=['type'=>$session['actor_type'],'id'=>(int)$session['actor_id']];$u=$db->prepare('UPDATE document_files SET storage_id=?,file_size=?,version=version+1,updated_at=CURRENT_TIMESTAMP,updated_by_user_id=? WHERE id=? AND storage_id=? AND is_deleted=0');$u->execute([$newStorage,strlen($download),$actor['type']==='user'?$actor['id']:null,$fileId,$session['original_storage_id']]);if($u->rowCount()!==1)throw new RuntimeException('File changed concurrently; version not committed.');
    $db->prepare("UPDATE document_edit_sessions SET original_storage_id=?, status='open', expires_at=? WHERE session_key=?")->execute([$newStorage,date('Y-m-d H:i:s',time()+7200),$sessionKey]);neal_docs_audit($db,$actor,'file.edit.save','file',$fileId,'success','version='.(int)$file['version']+1);$db->commit();$newStorageForCleanup=null;oo_reply(200,['error'=>0]);
}catch(Throwable $e){if(isset($db)&&$db instanceof PDO&&$db->inTransaction())$db->rollBack();if(is_string($newStorageForCleanup)&&$newStorageForCleanup!==''){try{neal_docs_storage_request('DELETE','/files/'.$newStorageForCleanup);}catch(Throwable $cleanupError){error_log('NEAL ONLYOFFICE orphan cleanup failed: '.$cleanupError->getMessage());}}error_log('NEAL ONLYOFFICE callback: '.$e->getMessage());oo_reply(500,['error'=>1]);}
