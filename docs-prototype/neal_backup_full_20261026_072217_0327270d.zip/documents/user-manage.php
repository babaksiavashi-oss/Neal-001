<?php
declare(strict_types=1);
require_once __DIR__ . '/common.php';
$actor = neal_docs_actor();
if ($actor['type'] !== 'user') { http_response_code(403); exit('این مسیر فقط برای مدیریت اسناد شخصی کاربران است.'); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); header('Allow: POST'); exit('روش درخواست مجاز نیست.'); }
neal_docs_csrf_check();
$db = neal_docs_db();
$active = $db->prepare('SELECT 1 FROM users WHERE id=? AND is_active=1');
$active->execute([$actor['id']]);
if (!$active->fetchColumn()) { http_response_code(403); exit('حساب کاربری غیرفعال است.'); }
$action = (string)($_POST['action'] ?? '');
function neal_docs_user_fail(string $message, int $status=400): never { http_response_code($status); exit(neal_docs_h($message)); }
try {
    if ($action === 'rename_folder' || $action === 'delete_folder') {
        $id = max(0, (int)($_POST['folder_id'] ?? 0));
        $q = $db->prepare("SELECT id,name,parent_id,folder_type,owner_user_id FROM document_folders WHERE id=? AND is_deleted=0");
        $q->execute([$id]); $folder = $q->fetch();
        if (!$folder) neal_docs_user_fail('پوشه پیدا نشد.',404);
        if ($folder['folder_type'] !== 'personal' || (int)$folder['owner_user_id'] !== (int)$actor['id']) {
            neal_docs_audit($db,$actor,'folder.manage','folder',$id,'denied','not personal-folder owner');
            neal_docs_user_fail('فقط پوشه‌های فضای شخصی خودتان را می‌توانید مدیریت کنید.',403);
        }
        if ($action === 'rename_folder') {
            $name = trim((string)($_POST['name'] ?? ''));
            if ($name === '' || mb_strlen($name)>120 || str_contains($name,'/') || str_contains($name,chr(92)) || preg_match('/[\x00-\x1F\x7F]/u',$name)) neal_docs_user_fail('نام پوشه معتبر نیست.');
            $dup = $db->prepare("SELECT 1 FROM document_folders WHERE name=? AND id<>? AND is_deleted=0 AND ((parent_id IS NULL AND ? IS NULL) OR parent_id=?) AND folder_type='personal' AND owner_user_id=? LIMIT 1");
            $parent = $folder['parent_id'] === null ? null : (int)$folder['parent_id'];
            $dup->execute([$name,$id,$parent,$parent,(int)$actor['id']]);
            if ($dup->fetchColumn()) neal_docs_user_fail('پوشه‌ای با این نام در همین مسیر وجود دارد.');
            $s=$db->prepare('UPDATE document_folders SET name=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');$s->execute([$name,$id]);
            neal_docs_audit($db,$actor,'folder.rename','folder',$id,'success','user self-management');
            header('Location: index.php?folder='.$id.'&managed=1'); exit;
        }
        $s=$db->prepare('SELECT (SELECT COUNT(*) FROM document_folders WHERE parent_id=? AND is_deleted=0)+(SELECT COUNT(*) FROM document_files WHERE folder_id=? AND is_deleted=0)');$s->execute([$id,$id]);
        if ((int)$s->fetchColumn()>0) neal_docs_user_fail('برای حذف پوشه، ابتدا تمام فایل‌ها و زیرپوشه‌های داخل آن را حذف کنید.');
        $db->beginTransaction();
        $db->prepare('UPDATE document_folders SET is_deleted=1,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$id]);
        $db->prepare('DELETE FROM document_permissions WHERE folder_id=?')->execute([$id]);
        neal_docs_audit($db,$actor,'folder.delete','folder',$id,'success','user self-management; soft delete');
        $db->commit();
        $parent = $folder['parent_id'] === null ? 0 : (int)$folder['parent_id'];
        header('Location: '.($parent ? 'index.php?folder='.$parent.'&deleted=1' : 'index.php?deleted=1')); exit;
    }
    if ($action === 'rename_file' || $action === 'delete_file') {
        $id = max(0, (int)($_POST['file_id'] ?? 0));
        $q=$db->prepare("SELECT df.id,df.folder_id,df.display_name,df.extension,df.created_by_user_id,f.folder_type,f.owner_user_id FROM document_files df JOIN document_folders f ON f.id=df.folder_id WHERE df.id=? AND df.is_deleted=0 AND f.is_deleted=0");
        $q->execute([$id]); $file=$q->fetch();
        if (!$file) neal_docs_user_fail('فایل پیدا نشد.',404);
        $ownsFolder = $file['folder_type']==='personal' && (int)$file['owner_user_id']===(int)$actor['id'];
        $createdByUser = (int)($file['created_by_user_id'] ?? 0)===(int)$actor['id'];
        if (!$ownsFolder && !$createdByUser) {
            neal_docs_audit($db,$actor,'file.manage','file',$id,'denied','not file creator or personal-folder owner');
            neal_docs_user_fail('فقط فایل‌های متعلق به شما یا فایل‌هایی که خودتان ایجاد کرده‌اید قابل مدیریت هستند.',403);
        }
        if ($action === 'rename_file') {
            $name=trim((string)($_POST['name']??''));
            if ($name==='' || mb_strlen($name)>255 || str_contains($name,'/') || str_contains($name,chr(92)) || preg_match('/[\x00-\x1F\x7F]/u',$name)) neal_docs_user_fail('نام فایل معتبر نیست.');
            if (strtolower(pathinfo($name,PATHINFO_EXTENSION)) !== strtolower((string)$file['extension'])) neal_docs_user_fail('پسوند فایل را هنگام تغییر نام عوض نکنید.');
            $dup=$db->prepare('SELECT 1 FROM document_files WHERE folder_id=? AND id<>? AND display_name=? AND is_deleted=0 LIMIT 1');$dup->execute([(int)$file['folder_id'],$id,$name]);
            if ($dup->fetchColumn()) neal_docs_user_fail('فایلی با این نام در همین پوشه وجود دارد.');
            $s=$db->prepare('UPDATE document_files SET display_name=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');$s->execute([$name,$id]);
            neal_docs_audit($db,$actor,'file.rename','file',$id,'success','user self-management');
            header('Location: index.php?folder='.(int)$file['folder_id'].'&managed=1'); exit;
        }
        neal_docs_delete_file($db,$actor,$id,'user self-management');
        header('Location: index.php?folder='.(int)$file['folder_id'].'&deleted=1'); exit;
    }
    neal_docs_user_fail('عملیات نامعتبر است.');
} catch (Throwable $e) {
    if ($db->inTransaction()) $db->rollBack();
    error_log('NEAL document user management: '.$e->getMessage());
    if ($e instanceof RuntimeException) neal_docs_user_fail($e->getMessage());
    http_response_code(500); exit('مدیریت فایل یا پوشه انجام نشد.');
}
