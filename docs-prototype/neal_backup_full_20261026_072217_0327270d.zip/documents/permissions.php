<?php
declare(strict_types=1);
require_once __DIR__ . '/common.php';
require_once dirname(__DIR__) . '/includes/user-profile.php';
$actor=neal_docs_actor();$db=neal_docs_db();
if($actor['type']==='user'){ $active=$db->prepare('SELECT 1 FROM users WHERE id=? AND is_active=1');$active->execute([$actor['id']]);if(!$active->fetchColumn()){http_response_code(403);exit('حساب کاربری غیرفعال است.');} }
$folderId=max(0,(int)($_GET['folder_id']??$_POST['folder_id']??0));
$fileId=max(0,(int)($_GET['file_id']??$_POST['file_id']??0));
if(($folderId>0)==($fileId>0)){http_response_code(400);exit('پوشه یا فایل را مشخص کنید.');}
$target=null;$targetType=$folderId?'folder':'file';
if($folderId){$q=$db->prepare("SELECT id,name,folder_type,owner_user_id,created_by_user_id FROM document_folders WHERE id=? AND is_deleted=0");$q->execute([$folderId]);$target=$q->fetch();$isFolderOwner=$target && $actor['type']==='user' && ((int)($target['created_by_user_id']??0)===(int)$actor['id'] || ($target['folder_type']==='personal'&&(int)$target['owner_user_id']===(int)$actor['id']));if(!$target||($actor['type']==='admin'&&$target['folder_type']!=='shared')||($actor['type']==='user'&&!$isFolderOwner)){http_response_code(403);exit('فقط سازنده یا مالک همین پوشه می‌تواند دسترسی آن را مدیریت کند.');}}
else{$q=$db->prepare("SELECT f.id,f.display_name,f.folder_id,f.created_by_user_id,d.name AS folder_name,d.folder_type,d.owner_user_id FROM document_files f JOIN document_folders d ON d.id=f.folder_id WHERE f.id=? AND f.is_deleted=0 AND d.is_deleted=0");$q->execute([$fileId]);$target=$q->fetch();$isOwner=$target && $actor['type']==='user' && ((int)($target['created_by_user_id']??0)===(int)$actor['id'] || ($target['folder_type']==='personal'&&(int)$target['owner_user_id']===(int)$actor['id']));if(!$target||($actor['type']==='admin'&&$target['folder_type']!=='shared')||($actor['type']==='user'&&!$isOwner)){http_response_code(404);exit('فایل پیدا نشد یا اجازه مدیریت ندارید.');}}
$keys=['can_view','can_download','can_upload','can_edit','can_delete'];
$labels=['can_view'=>'مشاهده','can_download'=>'دانلود','can_upload'=>'بارگذاری','can_edit'=>'ویرایش آنلاین','can_delete'=>'حذف'];
$message='';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  neal_docs_csrf_check();
  try{
    $db->beginTransaction();
    $users=$db->query('SELECT id FROM users WHERE is_active=1')->fetchAll(PDO::FETCH_COLUMN);
    $grantingAdminId=(int)($actor['type']==='admin'?$actor['id']:$db->query('SELECT id FROM admins WHERE is_active=1 ORDER BY id LIMIT 1')->fetchColumn());
    if($grantingAdminId<1)throw new RuntimeException('برای ثبت مجوز، حساب مدیر فعالی در سامانه وجود ندارد.'); if($actor['type']==='user') $users=array_values(array_filter($users,fn($uid)=>(int)$uid!==(int)$actor['id']));
    foreach($users as $uid){
      $uid=(int)$uid;$input=$_POST['perms'][$uid]??[];
      $vals=[];foreach($keys as $k)$vals[$k]=isset($input[$k])?1:0;
      if(!$vals['can_view'])foreach(['can_download','can_upload','can_edit','can_delete'] as $k)$vals[$k]=0;
      if($folderId){
        $sql="INSERT INTO document_permissions(folder_id,file_id,user_id,can_view,can_download,can_upload,can_edit,can_delete,granted_by_admin_id) VALUES(?,NULL,?,?,?,?,?,?,?) ON CONFLICT(folder_id,user_id) WHERE folder_id IS NOT NULL DO UPDATE SET can_view=excluded.can_view,can_download=excluded.can_download,can_upload=excluded.can_upload,can_edit=excluded.can_edit,can_delete=excluded.can_delete,granted_by_admin_id=excluded.granted_by_admin_id,updated_at=CURRENT_TIMESTAMP";
        $s=$db->prepare($sql);$s->execute([$folderId,$uid,$vals['can_view'],$vals['can_download'],$vals['can_upload'],$vals['can_edit'],$vals['can_delete'],$actor['type']==='admin'?$actor['id']:null]);
      }else{
        $sql="INSERT INTO document_permissions(folder_id,file_id,user_id,can_view,can_download,can_upload,can_edit,can_delete,granted_by_admin_id) VALUES(NULL,?,?,?,?,?,?,?,?) ON CONFLICT(file_id,user_id) WHERE file_id IS NOT NULL DO UPDATE SET can_view=excluded.can_view,can_download=excluded.can_download,can_upload=excluded.can_upload,can_edit=excluded.can_edit,can_delete=excluded.can_delete,granted_by_admin_id=excluded.granted_by_admin_id,updated_at=CURRENT_TIMESTAMP";
        $s=$db->prepare($sql);$s->execute([$fileId,$uid,$vals['can_view'],$vals['can_download'],$vals['can_upload'],$vals['can_edit'],$vals['can_delete'],$actor['type']==='admin'?$actor['id']:null]);
      }
    }
    neal_docs_audit($db,$actor,'permission.save','permission',$folderId?:$fileId,'success',$targetType.' ACL saved for active users');
    $db->commit();$message='مجوزهای همه کاربران ذخیره شد.';
  }catch(Throwable $e){if($db->inTransaction())$db->rollBack();error_log('NEAL document permissions: '.$e->getMessage());$error='ذخیره مجوزها ناموفق بود.';}
}
$userColumns=[];foreach($db->query('PRAGMA table_info(users)')->fetchAll() as $c)$userColumns[(string)$c['name']]=true;
$labelExpr=isset($userColumns['fullname'])?"CASE WHEN TRIM(COALESCE(u.fullname,''))<>'' THEN u.fullname || ' — ' || u.username ELSE u.username END":"u.username";
$avatarExpr=isset($userColumns['avatar'])?"COALESCE(NULLIF(u.avatar,''),'default')":"'default'";
$hasDepartments=false;
try{$db->query('SELECT code,name FROM departments LIMIT 1');$hasDepartments=true;}catch(Throwable $e){}
$departmentJoin=$hasDepartments?' LEFT JOIN departments dep ON dep.code=u.department AND dep.is_active=1 ':'';
$departmentNameExpr=$hasDepartments?"COALESCE(dep.name,u.department,'')":"COALESCE(u.department,'')";
$users=$db->query("SELECT u.id,u.username,{$labelExpr} AS display_label,u.department,{$departmentNameExpr} AS department_name,{$avatarExpr} AS avatar FROM users u{$departmentJoin} WHERE u.is_active=1 ORDER BY u.username")->fetchAll();
$acl=[];
if($folderId){$s=$db->prepare('SELECT * FROM document_permissions WHERE folder_id=?');$s->execute([$folderId]);}else{$s=$db->prepare('SELECT * FROM document_permissions WHERE file_id=?');$s->execute([$fileId]);}
foreach($s->fetchAll() as $row)$acl[(int)$row['user_id']]=$row;
$token=neal_docs_csrf_token();$title=$folderId?'مجوزهای پوشه':'مجوزهای فایل';$name=$folderId?(string)$target['name']:(string)$target['display_name'];
$page_title=$title;$page_base_href='/neal/';$portal_mode=$actor['type']==='user';require dirname(__DIR__).'/includes/header.php';
?>
<style>
.acl-page{max-width:1400px;margin:0 auto;padding:8px 26px 35px;font-family:Vazirmatn,Tahoma,sans-serif;color:#172b4d}.acl-hero{padding:24px 28px;border-radius:19px;background:linear-gradient(120deg,#102a43,#1769aa 70%,#2a9d9f);color:white;display:flex;align-items:center;justify-content:space-between;gap:18px}.acl-hero small{font-size:10px;color:#c8e7f9;font-weight:800}.acl-hero h1{font-size:23px;margin:7px 0}.acl-hero p{font-size:12px;color:#e0effa;margin:0}.acl-btn{display:inline-flex;align-items:center;justify-content:center;padding:9px 13px;border-radius:9px;text-decoration:none;border:1px solid #d9eaf8;background:#edf6fd;color:#145b8f;font:700 11px Vazirmatn,Tahoma,sans-serif;cursor:pointer;white-space:nowrap}.acl-panel{margin-top:18px;background:#fff;border:1px solid #e5eaf2;border-radius:17px;overflow:hidden;box-shadow:0 4px 18px #172b4d08}.acl-tools{padding:15px 18px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;border-bottom:1px solid #edf1f6}.acl-search{flex:1;min-width:200px;padding:10px 12px;border:1px solid #dce4ee;border-radius:9px;font:12px Vazirmatn,Tahoma,sans-serif}.acl-table-wrap{overflow-x:auto}.acl-table{width:100%;border-collapse:collapse;min-width:850px}.acl-table th{background:#f7f9fc;color:#64748b;font-size:10px;padding:13px 10px;text-align:center;white-space:nowrap}.acl-table td{padding:13px 10px;border-top:1px solid #edf1f6;text-align:center;font-size:11px}.acl-table td:first-child,.acl-table th:first-child{text-align:right;padding-right:18px}.acl-user{display:flex;align-items:center;gap:10px;min-width:220px}.acl-avatar{width:35px;height:35px;flex:0 0 35px;object-fit:cover;background:#edf6fd;border:1px solid #e4edf6;border-radius:11px}.acl-user strong{display:block;font-size:11px;color:#243b53}.acl-user small{display:block;margin-top:4px;color:#8996a8;font-size:9px}.acl-check{appearance:auto;-webkit-appearance:checkbox;width:20px;height:20px;min-width:20px;accent-color:#1769aa;cursor:pointer;display:inline-block;opacity:1;visibility:visible;position:static;margin:3px}
.acl-select-all-wrap{display:flex;align-items:center;justify-content:center;flex-direction:column;gap:5px;padding:4px 2px;border:1px solid #cfe0f0;border-radius:8px;background:#edf6fd;color:#145b8f;font-size:10px;font-weight:800;min-width:64px}
.acl-table th .acl-select-all-wrap input{width:22px;height:22px}
.acl-table th .acl-select-all-wrap:has(input:checked){background:#d8f3e4;border-color:#8fd5ac;color:#087443}.acl-message{padding:12px 14px;margin:14px 0;border-radius:11px;font-size:12px}.acl-ok{background:#eaf8f0;color:#087443;border:1px solid #c9ecd8}.acl-error{background:#fff1f0;color:#b42318;border:1px solid #ffd6d2}.acl-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:17px 18px;border-top:1px solid #edf1f6}.acl-note{font-size:10px;line-height:1.8;color:#7b8798;max-width:680px}.acl-save{background:#1769aa;color:#fff;border:0;border-radius:10px;padding:11px 17px;font:700 12px Vazirmatn,Tahoma,sans-serif;cursor:pointer}@media(max-width:650px){.acl-page{padding:4px 12px 24px}.acl-hero{align-items:flex-start;flex-direction:column;padding:21px 18px}.acl-hero h1{font-size:20px}}
</style>
<main class="acl-page">
<section class="acl-hero"><div><small>NEAL PHARMED · ACCESS CONTROL</small><h1><?=$title?></h1><p><?=neal_docs_h($name)?> · تعیین مجوزهای دسترسی برای کاربران فعال</p></div><a class="acl-btn" href="documents/index.php?folder=<?= (int)($target['folder_id']??$folderId) ?>">بازگشت به اسناد</a></section>
<?php if($message!==''):?><div class="acl-message acl-ok"><?=neal_docs_h($message)?></div><?php endif;?><?php if($error!==''):?><div class="acl-message acl-error"><?=neal_docs_h($error)?></div><?php endif;?>
<form method="post" class="acl-panel" id="acl-form"><input type="hidden" name="_csrf" value="<?=neal_docs_h($token)?>"><?php if($folderId):?><input type="hidden" name="folder_id" value="<?=$folderId?>"><?php else:?><input type="hidden" name="file_id" value="<?=$fileId?>"><?php endif;?>
<div class="acl-tools">
<input class="acl-search" id="acl-search" type="search" placeholder="جست‌وجوی نام یا نام کاربری..." aria-label="جست‌وجوی کاربر">
<select id="acl-department" class="acl-search" style="flex:0 1 220px" aria-label="فیلتر واحد سازمانی"><option value="">همه واحدها</option><?php $departments=[];foreach($users as $du){$dep=trim((string)($du['department']??''));if($dep!=='')$departments[$dep]=trim((string)($du['department_name']??''))?:$dep;}asort($departments,SORT_NATURAL|SORT_FLAG_CASE);foreach($departments as $depCode=>$depLabel):?><option value="<?=neal_docs_h((string)$depCode)?>"><?=neal_docs_h((string)$depLabel)?></option><?php endforeach;?></select>
<label style="font-size:11px;color:#64748b;white-space:nowrap">۱۰ کاربر در هر صفحه؛ تیک کنار نام هر مجوز در سرستون، آن مجوز را برای همه کاربرانِ مطابق فیلتر و در تمام صفحه‌ها اعمال می‌کند.</label>
<button class="acl-btn" type="button" id="acl-all-view">فعال‌کردن «مشاهده» برای همه کاربران فیلترشده</button><button class="acl-btn" type="button" id="acl-none">پاک‌کردن مجوزهای همه کاربران فیلترشده</button>
</div>
<div id="acl-result-count" style="padding:0 18px 12px;font-size:11px;color:#64748b"></div>
<div class="acl-table-wrap"><table class="acl-table"><thead><tr><th>کاربر</th><?php foreach($labels as $key=>$label):?><th><div style="display:flex;align-items:center;justify-content:center;flex-direction:column;gap:7px"><span><?=$label?></span><label class="acl-select-all-wrap"><input class="acl-check acl-select-all" type="checkbox" data-select-permission="<?=$key?>" title="اعمال این مجوز برای همه کاربران مطابق فیلتر، در تمام صفحه‌ها"><span>همه کاربران</span></label></div></th><?php endforeach;?></tr></thead><tbody>
<?php foreach($users as $u):$uid=(int)$u['id'];$a=$acl[$uid]??[];?>
<tr data-user-row data-department="<?=neal_docs_h((string)($u['department']??''))?>" data-search="<?=neal_docs_h(mb_strtolower((string)$u['display_label'].' '.(string)$u['username'],'UTF-8'))?>"><td><div class="acl-user"><?php $avatarUrl=neal_avatar_url((string)($u['avatar']??'default')); ?><img class="acl-avatar" src="/neal/<?=neal_docs_h(ltrim((string)$avatarUrl,'/'))?>" alt="" loading="lazy" onerror="this.onerror=null;this.src='/neal/images/avatars/default.svg'"><div><strong><?=neal_docs_h((string)$u['display_label'])?></strong><small><?=neal_docs_h((string)$u['username'])?><?=!empty($u['department_name'])?' · '.neal_docs_h((string)$u['department_name']):''?></small></div></div></td>
<?php foreach($keys as $key):?><td><input class="acl-check" type="checkbox" name="perms[<?=$uid?>][<?=$key?>]" value="1" data-permission="<?=$key?>" aria-label="<?=neal_docs_h($labels[$key].' برای '.(string)$u['username'])?>" <?=!empty($a[$key])?'checked':''?>></td><?php endforeach;?></tr>
<?php endforeach;?>
<?php if(!$users):?><tr><td colspan="6">کاربر فعالی وجود ندارد.</td></tr><?php endif;?>
</tbody></table></div><div id="acl-pagination" style="display:flex;align-items:center;justify-content:center;gap:7px;flex-wrap:wrap;padding:14px;border-top:1px solid #edf1f6"></div><div class="acl-footer"><div class="acl-note">اگر «مشاهده» خاموش باشد، سایر مجوزها هنگام ذخیره غیرفعال می‌شوند. مجوز فایل می‌تواند مجوز همان فایل را نسبت به مجوز پوشه بازنویسی کند. مالک می‌تواند مجوز همین پوشه یا فایل را مدیریت کند؛ مدیر سامانه همیشه دسترسی مدیریتی دارد.</div><button class="acl-save" type="submit">ذخیره مجوزهای دسترسی</button></div></form>
</main>
<script>
(function(){
'use strict';
const search=document.getElementById('acl-search');
const department=document.getElementById('acl-department');
const rows=Array.from(document.querySelectorAll('[data-user-row]'));
const pager=document.getElementById('acl-pagination');
const count=document.getElementById('acl-result-count');
const pageSize=10;
let page=1;
function filteredRows(){
 const q=(search.value||'').trim().toLocaleLowerCase();
 const d=department.value||'';
 return rows.filter(r=>(!q||(r.dataset.search||'').includes(q))&&(!d||(r.dataset.department||'')===d));
}
function draw(){
 const matches=filteredRows();
 const pages=Math.max(1,Math.ceil(matches.length/pageSize));
 page=Math.min(page,pages);
 const shown=new Set(matches.slice((page-1)*pageSize,page*pageSize));
 rows.forEach(r=>{r.hidden=!shown.has(r);});
 count.textContent=matches.length+' کاربر مطابق فیلتر · صفحه '+page+' از '+pages;
 pager.replaceChildren();
 function btn(label,target,disabled,active){
  const b=document.createElement('button');b.type='button';b.textContent=label;
  b.className='acl-btn';b.disabled=disabled;
  if(active){b.style.background='#1769aa';b.style.color='#fff';}
  b.addEventListener('click',()=>{page=target;draw();});
  pager.appendChild(b);
 }
 btn('قبلی',Math.max(1,page-1),page===1,false);
 const from=Math.max(1,page-2),to=Math.min(pages,from+4);
 for(let n=from;n<=to;n++)btn(String(n),n,false,n===page);
 btn('بعدی',Math.min(pages,page+1),page===pages,false);
 syncHeaders(matches);
}
function syncHeaders(matches){
 document.querySelectorAll('[data-select-permission]').forEach(h=>{
  const key=h.dataset.selectPermission;
  const checks=matches.map(r=>r.querySelector('[data-permission="'+key+'"]')).filter(Boolean);
  h.checked=checks.length>0&&checks.every(c=>c.checked);
  h.indeterminate=checks.some(c=>c.checked)&&!h.checked;
 });
}
document.querySelectorAll('[data-select-permission]').forEach(h=>h.addEventListener('change',()=>{
 const key=h.dataset.selectPermission;
 // All filtered rows, including those on other pages, are updated.
 filteredRows().forEach(r=>{const c=r.querySelector('[data-permission="'+key+'"]');if(c)c.checked=h.checked;});
 draw();
}));
search.addEventListener('input',()=>{page=1;draw();});
department.addEventListener('change',()=>{page=1;draw();});
document.getElementById('acl-all-view').addEventListener('click',()=>{
 filteredRows().forEach(r=>{const c=r.querySelector('[data-permission="can_view"]');if(c)c.checked=true;});draw();
});
document.getElementById('acl-none').addEventListener('click',()=>{
 filteredRows().forEach(r=>r.querySelectorAll('input[data-permission]').forEach(c=>c.checked=false));draw();
});
rows.forEach(r=>{
 const view=r.querySelector('[data-permission="can_view"]');
 if(view)view.addEventListener('change',()=>{if(!view.checked)r.querySelectorAll('input[data-permission]:not([data-permission="can_view"])').forEach(c=>c.checked=false);draw();});
 r.querySelectorAll('input[data-permission]:not([data-permission="can_view"])').forEach(c=>c.addEventListener('change',draw));
});
draw();
})();
</script>
<?php require dirname(__DIR__).'/includes/footer.php'; ?>
