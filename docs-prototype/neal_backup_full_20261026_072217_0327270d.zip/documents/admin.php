<?php
declare(strict_types=1);
require_once __DIR__ . '/common.php';
$actor=neal_docs_require_admin();
$db=neal_docs_db();
$error=''; $success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  neal_docs_csrf_check();
  $action=(string)($_POST['action']??'');
  try{
    if($action==='create_folder'){
      $name=trim((string)($_POST['name']??'')); $parentId=max(0,(int)($_POST['parent_id']??0));
      if($name===''||mb_strlen($name)>120||str_contains($name,'/')||str_contains($name,chr(92))) throw new RuntimeException('نام پوشه معتبر نیست.');
      $type='shared'; $owner=null;
      if($parentId){
        $s=$db->prepare('SELECT id,folder_type,owner_user_id FROM document_folders WHERE id=? AND is_deleted=0');$s->execute([$parentId]);$parent=$s->fetch();
        if(!$parent)throw new RuntimeException('پوشه والد پیدا نشد.');
        $type=(string)$parent['folder_type'];$owner=$type==='personal'?(int)$parent['owner_user_id']:null;
      }
      $dup=$db->prepare("SELECT 1 FROM document_folders WHERE name=? AND is_deleted=0 AND ((parent_id IS NULL AND ?=0) OR parent_id=?) AND folder_type=? AND COALESCE(owner_user_id,0)=COALESCE(?,0)");
      $dup->execute([$name,$parentId,$parentId,$type,$owner]);if($dup->fetchColumn())throw new RuntimeException('پوشه‌ای با این نام در همین مسیر وجود دارد.');
      $s=$db->prepare('INSERT INTO document_folders(name,parent_id,folder_type,owner_user_id,created_by_admin_id) VALUES(?,?,?,?,?)');$s->execute([$name,$parentId?:null,$type,$owner,$actor['id']]);
      $id=(int)$db->lastInsertId();neal_docs_audit($db,$actor,'folder.create','folder',$id,'success',$type);$success='پوشه با موفقیت ایجاد شد.';
    }elseif($action==='convert_shared'){
      $id=max(0,(int)($_POST['folder_id']??0));
      $s=$db->prepare("SELECT id FROM document_folders WHERE id=? AND parent_id IS NULL AND folder_type='personal' AND is_deleted=0");$s->execute([$id]);
      if(!$s->fetchColumn())throw new RuntimeException('فقط پوشه شخصی ریشه را می‌توان به پوشه مشترک تبدیل کرد.');
      $db->beginTransaction();
      $db->exec("WITH RECURSIVE tree(id) AS (SELECT id FROM document_folders WHERE id=".(int)$id." UNION ALL SELECT f.id FROM document_folders f JOIN tree t ON f.parent_id=t.id WHERE f.is_deleted=0) UPDATE document_folders SET folder_type='shared',owner_user_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE id IN (SELECT id FROM tree)");
      neal_docs_audit($db,$actor,'folder.convert_shared','folder',$id,'success','converted subtree to shared');$db->commit();$success='پوشه و زیرپوشه‌های آن به ساختار مشترک تبدیل شدند؛ کاربران فقط پس از اعطای مجوز می‌توانند آن‌ها را ببینند.';
    }elseif($action==='rename_folder'){
      $id=max(0,(int)($_POST['folder_id']??0));$name=trim((string)($_POST['name']??''));
      if(!$id||$name===''||mb_strlen($name)>120||str_contains($name,'/')||str_contains($name,chr(92)))throw new RuntimeException('نام پوشه معتبر نیست.');
      $s=$db->prepare('SELECT id FROM document_folders WHERE id=? AND is_deleted=0');$s->execute([$id]);if(!$s->fetchColumn())throw new RuntimeException('پوشه پیدا نشد.');
      $s=$db->prepare('UPDATE document_folders SET name=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');$s->execute([$name,$id]);neal_docs_audit($db,$actor,'folder.rename','folder',$id,'success');$success='نام پوشه تغییر کرد.';
    }elseif($action==='delete_folder'){
      $id=max(0,(int)($_POST['folder_id']??0));
      $s=$db->prepare('SELECT id FROM document_folders WHERE id=? AND is_deleted=0');$s->execute([$id]);if(!$s->fetchColumn())throw new RuntimeException('پوشه پیدا نشد.');
      $s=$db->prepare('SELECT (SELECT COUNT(*) FROM document_folders WHERE parent_id=? AND is_deleted=0)+(SELECT COUNT(*) FROM document_files WHERE folder_id=? AND is_deleted=0)');$s->execute([$id,$id]);if((int)$s->fetchColumn()>0)throw new RuntimeException('این پوشه خالی نیست؛ ابتدا فایل‌ها و زیرپوشه‌ها را جابه‌جا یا حذف کنید.');
      $s=$db->prepare('UPDATE document_folders SET is_deleted=1,updated_at=CURRENT_TIMESTAMP WHERE id=?');$s->execute([$id]);$db->prepare('DELETE FROM document_permissions WHERE folder_id=?')->execute([$id]);neal_docs_audit($db,$actor,'folder.delete','folder',$id,'success','soft delete');$success='پوشه حذف شد.';
    }elseif($action==='rename_file'){
      $id=max(0,(int)($_POST['file_id']??0));$name=trim((string)($_POST['name']??''));
      if(!$id||$name===''||mb_strlen($name)>255||str_contains($name,'/')||str_contains($name,chr(92)))throw new RuntimeException('نام فایل معتبر نیست.');
      $s=$db->prepare('SELECT id,extension FROM document_files WHERE id=? AND is_deleted=0');$s->execute([$id]);$file=$s->fetch();if(!$file)throw new RuntimeException('فایل پیدا نشد.');
      $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));if($ext!==strtolower((string)$file['extension']))throw new RuntimeException('پسوند فایل را هنگام تغییر نام عوض نکنید.');
      $s=$db->prepare('UPDATE document_files SET display_name=?,updated_at=CURRENT_TIMESTAMP WHERE id=?');$s->execute([$name,$id]);neal_docs_audit($db,$actor,'file.rename','file',$id,'success');$success='نام فایل تغییر کرد.';
    }elseif($action==='delete_file'){
      $id=max(0,(int)($_POST['file_id']??0));
      neal_docs_delete_file($db,$actor,$id,'admin delete');
      $success='فایل و نسخه‌های ذخیره‌شده آن از مخزن حذف شدند.';
    }else{throw new RuntimeException('عملیات نامعتبر است.');}
  }catch(Throwable $e){if($db->inTransaction())$db->rollBack();error_log('NEAL documents admin action: '.$e->getMessage());$error=$e instanceof RuntimeException?$e->getMessage():'عملیات انجام نشد.';}
}
$folders=$db->query("SELECT f.id,f.name,f.parent_id,f.folder_type,f.owner_user_id,f.created_at,COALESCE(NULLIF(uc.username,''),NULLIF(ac.username,''),'نامشخص') AS creator_name,(SELECT COUNT(*) FROM document_files x WHERE x.folder_id=f.id AND x.is_deleted=0) file_count,(SELECT COUNT(*) FROM document_folders c WHERE c.parent_id=f.id AND c.is_deleted=0) child_count FROM document_folders f LEFT JOIN users uc ON uc.id=f.created_by_user_id LEFT JOIN admins ac ON ac.id=f.created_by_admin_id WHERE f.is_deleted=0 ORDER BY CASE WHEN f.parent_id IS NULL THEN 0 ELSE 1 END,f.parent_id,f.name")->fetchAll();
$users=$db->query("SELECT id,username FROM users WHERE is_active=1 ORDER BY username")->fetchAll();
$token=neal_docs_csrf_token();
$page_title='مدیریت اسناد';
$page_base_href='/neal/';
$portal_mode=false;
require dirname(__DIR__).'/includes/header.php';
?>
<style>
.docs-admin{--ink:#172b4d;--muted:#6b7a90;--line:#e5eaf2;max-width:1480px;margin:0 auto;padding:8px 26px 34px;font-family:Vazirmatn,Tahoma,sans-serif;color:var(--ink)}
.da-hero{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:25px 28px;border-radius:20px;color:#fff;background:linear-gradient(120deg,#102a43,#1769aa 65%,#2a9d9f);box-shadow:0 14px 34px #102a431c}.da-hero h1{font-size:24px;margin:7px 0}.da-hero p{font-size:12px;color:#e0effa;margin:0;line-height:1.8}.da-eyebrow{font-size:10px;color:#c3e4f8;font-weight:800;letter-spacing:.06em}
.da-grid{display:grid;grid-template-columns:minmax(280px,.75fr) minmax(0,1.6fr);gap:18px;align-items:start;margin-top:18px}.da-panel{background:#fff;border:1px solid var(--line);border-radius:17px;overflow:hidden;box-shadow:0 4px 18px #172b4d08}.da-head{padding:17px 20px;border-bottom:1px solid #edf1f6}.da-head h2{font-size:14px;margin:0}.da-head p{font-size:10px;color:var(--muted);margin:5px 0 0}.da-form{padding:19px}.da-form label{display:block;font-size:11px;font-weight:700;color:#475467;margin-bottom:7px}.da-form input,.da-form select{box-sizing:border-box;width:100%;padding:10px 11px;border:1px solid #dce4ee;border-radius:9px;background:#fbfcfe;font:12px Vazirmatn,Tahoma,sans-serif;margin-bottom:14px}.da-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:1px solid transparent;border-radius:9px;padding:8px 11px;font:700 11px Vazirmatn,Tahoma,sans-serif;text-decoration:none;cursor:pointer;white-space:nowrap}.da-primary{background:#1769aa;color:#fff}.da-soft{background:#edf6fd;color:#145b8f;border-color:#d9eaf8}.da-danger{background:#fff1f0;color:#b42318;border-color:#ffd6d2}.da-list{padding:7px 14px}.da-folder{padding:14px 5px;border-bottom:1px solid #f0f3f7}.da-folder:last-child{border-bottom:0}.da-folder-top{display:flex;align-items:center;gap:10px}.da-icon{width:40px;height:40px;display:grid;place-items:center;border-radius:12px;background:#fff6df;font-size:20px}.da-name{flex:1;min-width:0}.da-name strong{font-size:12px;display:block;overflow-wrap:anywhere}.da-meta{font-size:10px;color:#8996a8;margin-top:5px}.da-folder-actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px;padding-right:50px}.da-inline{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:10px}.da-inline input{flex:1;min-width:130px;padding:8px 9px;border:1px solid #dce4ee;border-radius:8px;font:11px Vazirmatn,Tahoma,sans-serif}.da-msg{padding:12px 14px;border-radius:11px;font-size:12px;margin:14px 0}.da-ok{background:#eaf8f0;color:#087443;border:1px solid #c9ecd8}.da-err{background:#fff1f0;color:#b42318;border:1px solid #ffd6d2}.da-help{padding:14px 16px;margin-top:14px;border-radius:12px;background:#f5f9fd;color:#65758b;font-size:10px;line-height:2}
@media(max-width:900px){.da-grid{grid-template-columns:1fr}.da-hero{align-items:flex-start;flex-direction:column}}@media(max-width:600px){.docs-admin{padding:4px 12px 24px}.da-hero{padding:21px 18px}.da-hero h1{font-size:20px}.da-folder-top{align-items:flex-start}.da-folder-actions{padding-right:0}}
</style>
<main class="docs-admin">
<section class="da-hero"><div><div class="da-eyebrow">NEAL PHARMED · ADMINISTRATION</div><h1>مدیریت اسناد سازمانی</h1><p>ساختار پوشه‌ها، نگهداری فایل‌ها و تعیین دقیق دسترسی کاربران را از یک صفحه مدیریت کنید.</p></div><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="da-btn" style="background:#fff;color:#164e7a" href="documents/quota.php">◫ سهمیه فضای کاربران</a><a class="da-btn" style="background:#fff;color:#164e7a" href="documents/index.php">← بازگشت به مرکز اسناد</a></div></section>
<?php if($success!==''): ?><div class="da-msg da-ok"><?=neal_docs_h($success)?></div><?php endif; ?><?php if($error!==''): ?><div class="da-msg da-err"><?=neal_docs_h($error)?></div><?php endif; ?>
<div class="da-grid">
<section class="da-panel"><div class="da-head"><h2>＋ ایجاد پوشه</h2><p>پوشه ریشه به‌صورت مشترک ساخته می‌شود؛ زیرپوشه نوع پوشه والد را به ارث می‌برد.</p></div>
<form class="da-form" method="post"><input type="hidden" name="_csrf" value="<?=neal_docs_h($token)?>"><input type="hidden" name="action" value="create_folder"><label for="da-name">نام پوشه</label><input id="da-name" name="name" maxlength="120" required placeholder="مثلاً دستورالعمل‌های سازمان"><label for="da-parent">پوشه والد</label><select id="da-parent" name="parent_id"><option value="0">ریشه اسناد مشترک</option><?php foreach($folders as $f):?><option value="<?=(int)$f['id']?>"><?=neal_docs_h(($f['folder_type']==='personal'?'[شخصی] ':'[مشترک] ').$f['name'].' (#'.$f['id'].')')?></option><?php endforeach;?></select><button class="da-btn da-primary" type="submit">ایجاد پوشه</button></form>
<div class="da-help">نکته: برای اینکه پوشه در حساب کاربر نمایش داده شود، پس از ساخت آن وارد «مدیریت دسترسی‌ها» شوید و مجوز «مشاهده» را برای کاربر موردنظر فعال کنید. مجوزهای دانلود، بارگذاری، ویرایش و حذف مستقل هستند.</div>
</section>
<section class="da-panel"><div class="da-head"><h2>ساختار پوشه‌ها</h2><p><?=count($folders)?> پوشه فعال · تغییر نام و حذف پوشه‌های خالی</p></div><div class="da-list">
<?php foreach($folders as $f):?>
<div class="da-folder"><div class="da-folder-top"><div class="da-icon">📁</div><div class="da-name"><strong><?=neal_docs_h((string)$f['name'])?></strong><div class="da-meta">شناسه <?=(int)$f['id']?> · <?=$f['folder_type']==='shared'?'مشترک':'شخصی'?> · <?= (int)$f['child_count']?> زیرپوشه · <?= (int)$f['file_count']?> فایل · ایجادکننده: <?=neal_docs_h((string)$f['creator_name'])?></div></div></div>
<div class="da-folder-actions"><?php if($f['folder_type']==='shared'):?><a class="da-btn da-soft" href="documents/permissions.php?folder_id=<?=(int)$f['id']?>">👥 مدیریت دسترسی‌ها</a><?php endif;?><a class="da-btn da-soft" href="documents/index.php?folder=<?=(int)$f['id']?>">مشاهده محتوا</a></div>
<?php if($f['folder_type']==='personal' && $f['parent_id']===null):?><form class="da-inline" method="post" onsubmit="return confirm('این پوشه و تمام زیرپوشه‌های آن به فضای مشترک تبدیل شوند؟ پس از تبدیل، هیچ کاربری بدون مجوز مشاهده به محتوا دسترسی نخواهد داشت.')"><input type="hidden" name="_csrf" value="<?=neal_docs_h($token)?>"><input type="hidden" name="action" value="convert_shared"><input type="hidden" name="folder_id" value="<?=(int)$f['id']?>"><button class="da-btn da-soft" type="submit">تبدیل به پوشه مشترک</button></form><?php endif;?>
<form class="da-inline" method="post"><input type="hidden" name="_csrf" value="<?=neal_docs_h($token)?>"><input type="hidden" name="action" value="rename_folder"><input type="hidden" name="folder_id" value="<?=(int)$f['id']?>"><input name="name" maxlength="120" required value="<?=neal_docs_h((string)$f['name'])?>" aria-label="نام جدید پوشه"><button class="da-btn da-soft" type="submit">ذخیره نام</button></form>
<?php if((int)$f['child_count']===0&&(int)$f['file_count']===0):?><form class="da-inline" method="post" onsubmit="return confirm('پوشه خالی حذف شود؟')"><input type="hidden" name="_csrf" value="<?=neal_docs_h($token)?>"><input type="hidden" name="action" value="delete_folder"><input type="hidden" name="folder_id" value="<?=(int)$f['id']?>"><button class="da-btn da-danger" type="submit">حذف پوشه</button></form><?php endif;?>
</div><?php endforeach;?><?php if(!$folders):?><div style="padding:30px;text-align:center;color:#8996a8;font-size:12px">هنوز پوشه‌ای ساخته نشده است.</div><?php endif;?></div></section>
</div>
<section class="da-panel" style="margin-top:18px"><div class="da-head"><h2>کاربران فعال</h2><p>مدیریت مجوزهای پوشه و فایل و تعیین سقف فضای هر کاربر از همین بخش‌های مدیریتی انجام می‌شود.</p></div><div class="da-list" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:6px"><?php foreach($users as $u):?><div style="padding:10px 8px;border-bottom:1px solid #f0f3f7;font-size:11px">👤 <?=neal_docs_h((string)$u['username'])?> <span style="color:#98a2b3">#<?=(int)$u['id']?></span></div><?php endforeach;?></div></section>
</main>
<?php require dirname(__DIR__).'/includes/footer.php'; ?>
