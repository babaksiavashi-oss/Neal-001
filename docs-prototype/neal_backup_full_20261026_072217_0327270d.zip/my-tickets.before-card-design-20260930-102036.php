<?php

$portal_mode = true;

require_once "auth/auth.php";
require_once "config/config.php";

check_login();

$page_title = "درخواست‌های من";

$db = new PDO(
    "sqlite:" . __DIR__ . "/data/neal.db"
);

$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$admin_id = (int)$_SESSION['admin_id'];


/*
 * آمار درخواست‌های کاربر
 */

$stmt = $db->prepare("
    SELECT
        COUNT(*) AS total,
        SUM(CASE
            WHEN status IN ('new', 'assigned', 'in_progress')
            THEN 1 ELSE 0
        END) AS in_progress,
        SUM(CASE
            WHEN status = 'waiting_user'
            THEN 1 ELSE 0
        END) AS waiting_user,
        SUM(CASE
            WHEN status IN ('closed', 'resolved')
            THEN 1 ELSE 0
        END) AS closed
    FROM service_requests
    WHERE requester_admin_id = ?
");

$stmt->execute([$admin_id]);

$stats = $stmt->fetch(PDO::FETCH_ASSOC);


/*
 * درخواست‌های کاربر
 */

$stmt = $db->prepare("
    SELECT
        sr.*,
        GROUP_CONCAT(rt.name, '، ') AS request_types
    FROM service_requests sr

    LEFT JOIN service_request_types srt
        ON srt.request_id = sr.id

    LEFT JOIN request_types rt
        ON rt.id = srt.request_type_id

    WHERE sr.requester_admin_id = ?

    GROUP BY sr.id

    ORDER BY sr.created_at DESC
");

$stmt->execute([$admin_id]);

$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<?php include "includes/header.php"; ?>


<div class="ticket-page">

    <div class="ticket-page-header">

        <div>
            <h1>درخواست‌های من</h1>

            <p>
                مشاهده و پیگیری درخواست‌های ثبت‌شده
            </p>
        </div>

        <a href="service-request.php" class="ticket-new-btn">
            ＋ درخواست جدید
        </a>

    </div>


    <!-- Statistics -->

    <div class="ticket-stats">

        <div class="ticket-stat">
            <div class="ticket-stat-icon">📥</div>

            <div>
                <span>کل درخواست‌ها</span>
                <strong><?php echo (int)$stats['total']; ?></strong>
            </div>
        </div>


        <div class="ticket-stat">
            <div class="ticket-stat-icon">🟡</div>

            <div>
                <span>در حال بررسی</span>
                <strong><?php echo (int)$stats['in_progress']; ?></strong>
            </div>
        </div>


        <div class="ticket-stat">
            <div class="ticket-stat-icon">🔵</div>

            <div>
                <span>منتظر پاسخ</span>
                <strong><?php echo (int)$stats['waiting_user']; ?></strong>
            </div>
        </div>


        <div class="ticket-stat">
            <div class="ticket-stat-icon">🟢</div>

            <div>
                <span>بسته‌شده</span>
                <strong><?php echo (int)$stats['closed']; ?></strong>
            </div>
        </div>

    </div>


    <!-- Tickets -->

    <div class="card ticket-list-card">

        <div class="ticket-list-header">

            <div>
                <h2>لیست درخواست‌ها</h2>

                <span>
                    درخواست‌های ثبت‌شده توسط شما
                </span>
            </div>

        </div>


        <?php if (count($tickets) === 0): ?>

    <div class="ticket-empty">

        <div class="ticket-empty-icon">
            🎫
        </div>

        <h3>
            هنوز درخواستی ثبت نشده است
        </h3>

        <p>
            اگر مشکلی دارید یا به خدمات واحد فناوری اطلاعات نیاز دارید،
            می‌توانید یک درخواست جدید ثبت کنید.
        </p>

        <a href="service-request.php" class="ticket-new-btn">
            ＋ ثبت درخواست جدید
        </a>

    </div>

<?php else: ?>

    <div class="ticket-list">

        <?php foreach ($tickets as $ticket): ?>

            <div class="ticket-item">

                <div class="ticket-item-main">

                    <div class="ticket-item-number">
                        <?php echo htmlspecialchars($ticket['tracking_number']); ?>
                    </div>

                    <h3>
                        <?php echo htmlspecialchars($ticket['subject']); ?>
                    </h3>

                    <div class="ticket-item-meta">

                        <span>
                            نوع درخواست:
                            <?php echo htmlspecialchars($ticket['request_types'] ?: '---'); ?>
                        </span>

                        <span>
                            تاریخ ثبت:
                            <?php echo htmlspecialchars($ticket['created_at']); ?>
                        </span>

                    </div>

                </div>


                <div class="ticket-item-side">

                    <span class="ticket-status">
                        <?php echo htmlspecialchars($ticket['status']); ?>
                    </span>

                    <span class="ticket-priority">
                        <?php echo htmlspecialchars($ticket['priority']); ?>
                    </span>

                    <a
                        href="ticket-view.php?id=<?php echo (int)$ticket['id']; ?>"
                        class="ticket-view-btn"
                    >
                        مشاهده
                    </a>

                </div>

            </div>

        <?php endforeach; ?>

    </div>

<?php endif; ?>

    </div>

</div>


<style>

.ticket-page {
    max-width: 1400px;
    margin: 0 auto;
}

.ticket-page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 25px;
}

.ticket-page-header h1 {
    margin: 0 0 8px 0;
}

.ticket-page-header p {
    margin: 0;
    color: #718096;
    font-size: 14px;
}


.ticket-new-btn {
    display: inline-block;
    background: #0b1f3a;
    color: white;
    text-decoration: none;
    padding: 11px 20px;
    border-radius: 8px;
    font-size: 14px;
    transition: .2s;
}

.ticket-new-btn:hover {
    background: #1b4965;
    transform: translateY(-1px);
}


.ticket-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-bottom: 25px;
}


.ticket-stat {
    background: white;
    border: 1px solid #e9eef5;
    border-radius: 12px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
    box-shadow: 0 3px 12px rgba(0,0,0,.04);
}


.ticket-stat-icon {
    width: 45px;
    height: 45px;
    border-radius: 10px;
    background: #f4f7fb;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 21px;
}


.ticket-stat span {
    display: block;
    color: #718096;
    font-size: 13px;
    margin-bottom: 6px;
}


.ticket-stat strong {
    display: block;
    color: #0b1f3a;
    font-size: 22px;
}


.ticket-list-card {
    min-height: 400px;
}


.ticket-list-header {
    border-bottom: 1px solid #edf1f5;
    padding-bottom: 18px;
    margin-bottom: 0;
}

.ticket-list-header h2 {
    margin: 0 0 6px 0;
}

.ticket-list-header span {
    color: #718096;
    font-size: 13px;
}


.ticket-empty {
    min-height: 330px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 40px;
}


.ticket-empty-icon {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    background: #f4f7fb;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 32px;
    margin-bottom: 18px;
}


.ticket-empty h3 {
    margin: 0 0 10px 0;
    color: #0b1f3a;
}


.ticket-empty p {
    max-width: 500px;
    color: #718096;
    line-height: 1.9;
    font-size: 14px;
    margin: 0 0 22px 0;
}


@media (max-width: 900px) {

    .ticket-stats {
        grid-template-columns: repeat(2, 1fr);
    }

}


@media (max-width: 600px) {

    .ticket-page-header {
        flex-direction: column;
        align-items: stretch;
    }

    .ticket-stats {
        grid-template-columns: 1fr;
    }

}

</style>


<?php include "includes/footer.php"; ?>
