<?php
declare(strict_types=1);
require_once __DIR__ . '/../auth/auth.php';

function neal_docs_db(): PDO
{
    $path = dirname(__DIR__) . '/data/neal.db';
    if (!is_file($path) || !is_readable($path)) throw new RuntimeException('پایگاه داده پرتال در دسترس نیست.');
    $db = new PDO('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);
    $db->exec('PRAGMA foreign_keys = ON');
    return $db;
}

function neal_docs_config(): array
{
    $path='/usr/local/etc/neal-documents.env';
    if (!is_file($path)||!is_readable($path)) throw new RuntimeException('تنظیمات امن سرویس اسناد نصب نشده است.');
    $values=parse_ini_file($path,false,INI_SCANNER_RAW);
    if (!is_array($values)) throw new RuntimeException('خواندن تنظیمات سرویس اسناد ناموفق بود.');
    $config=[
        'storage_url'=>rtrim((string)($values['NEAL_STORAGE_URL']??''),'/'),
        'storage_token'=>(string)($values['NEAL_STORAGE_TOKEN']??''),
        'onlyoffice_url'=>rtrim((string)($values['NEAL_ONLYOFFICE_URL']??''),'/'),
        'onlyoffice_browser_secret'=>(string)($values['NEAL_ONLYOFFICE_BROWSER_SECRET']??''),
        'onlyoffice_outbox_secret'=>(string)($values['NEAL_ONLYOFFICE_OUTBOX_SECRET']??''),
        'portal_public_url'=>rtrim((string)($values['NEAL_PORTAL_PUBLIC_URL']??''),'/'),
    ];
    if ($config['storage_url']===''||$config['storage_token']==='') throw new RuntimeException('تنظیمات سرویس ذخیره‌سازی ناقص است.');
    if (!function_exists('curl_init')) throw new RuntimeException('افزونه cURL در PHP فعال نیست.');
    return $config;
}

function neal_docs_actor(): array
{
    $adminId=(int)($_SESSION['admin_id']??0); $userId=(int)($_SESSION['user_id']??0);
    if (($adminId>0)===($userId>0)) { http_response_code(403); exit('دسترسی غیرمجاز است.'); }
    return $adminId>0?['type'=>'admin','id'=>$adminId]:['type'=>'user','id'=>$userId];
}
function neal_docs_require_admin(): array { $actor=neal_docs_actor(); if($actor['type']!=='admin'){http_response_code(403);exit('برای این عملیات دسترسی مدیر لازم است.');} return $actor; }
function neal_docs_csrf_token(): string { if(empty($_SESSION['neal_docs_csrf'])) $_SESSION['neal_docs_csrf']=bin2hex(random_bytes(32)); return (string)$_SESSION['neal_docs_csrf']; }
function neal_docs_csrf_check(): void { $sent=(string)($_POST['_csrf']??''); $known=(string)($_SESSION['neal_docs_csrf']??''); if($sent===''||$known===''||!hash_equals($known,$sent)){http_response_code(403);exit('درخواست معتبر نیست؛ صفحه را تازه‌سازی کنید.');} }
function neal_docs_audit(PDO $db,array $actor,string $action,string $targetType,?int $targetId,string $outcome,string $details=''): void
{
    $stmt=$db->prepare('INSERT INTO document_audit_log (admin_id,user_id,action,target_type,target_id,outcome,details) VALUES (:admin_id,:user_id,:action,:target_type,:target_id,:outcome,:details)');
    $stmt->execute([':admin_id'=>$actor['type']==='admin'?$actor['id']:null,':user_id'=>$actor['type']==='user'?$actor['id']:null,':action'=>substr($action,0,80),':target_type'=>$targetType,':target_id'=>$targetId,':outcome'=>$outcome,':details'=>substr($details,0,500)]);
}
function neal_docs_can(PDO $db,array $actor,int $folderId,?int $fileId,string $permission): bool
{
    if(!in_array($permission,['can_view','can_download','can_upload','can_edit','can_delete'],true)) return false;
    if($actor['type']==='admin'){$s=$db->prepare('SELECT 1 FROM admins WHERE id=? AND is_active=1');$s->execute([$actor['id']]);return (bool)$s->fetchColumn();}
    $s=$db->prepare('SELECT 1 FROM users WHERE id=? AND is_active=1');$s->execute([$actor['id']]);if(!$s->fetchColumn())return false;
    if($fileId!==null){$s=$db->prepare("SELECT {$permission} FROM document_permissions WHERE file_id=? AND user_id=? LIMIT 1");$s->execute([$fileId,$actor['id']]);$v=$s->fetchColumn();if($v!==false)return (int)$v===1;}
    $s=$db->prepare("SELECT {$permission} FROM document_permissions WHERE folder_id=? AND user_id=? LIMIT 1");$s->execute([$folderId,$actor['id']]);return (int)$s->fetchColumn()===1;
}
function neal_docs_storage_request(string $method,string $path,?string $body=null,array $extraHeaders=[]): array
{
    $c=neal_docs_config(); if(!preg_match('#^/(health|files(?:/[a-f0-9]{32,64}\.[A-Za-z0-9]+)?)$#',$path))throw new RuntimeException('مسیر سرویس ذخیره‌سازی نامعتبر است.');
    $ch=curl_init($c['storage_url'].$path);$headers=array_merge(['Authorization: Bearer '.$c['storage_token'],'Expect:'],$extraHeaders);
    curl_setopt_array($ch,[CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>180,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS]);if($body!==null)curl_setopt($ch,CURLOPT_POSTFIELDS,$body);
    $result=curl_exec($ch);$error=curl_error($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$type=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE);curl_close($ch);if($result===false)throw new RuntimeException('ارتباط با سرویس ذخیره‌سازی برقرار نشد: '.$error);return ['status'=>$status,'body'=>$result,'content_type'=>$type];
}

/**
 * Delete a document's physical blobs and mark its DB row deleted.
 * Historical versions are removed too. A blob still referenced by another file/version is preserved.
 * This function owns its transaction; callers must not start one around it.
 */
function neal_docs_delete_file(PDO $db, array $actor, int $fileId, string $auditDetails=''): void
{
    if ($fileId < 1) throw new RuntimeException('شناسه فایل معتبر نیست.');
    $db->beginTransaction();
    try {
        $s=$db->prepare("SELECT id,storage_id FROM document_files WHERE id=? AND is_deleted=0");
        $s->execute([$fileId]); $file=$s->fetch();
        if (!$file) throw new RuntimeException('فایل پیدا نشد.');

        // Cancel any open ONLYOFFICE sessions inside the same DB transaction.
        $db->prepare("UPDATE document_edit_sessions SET status='cancelled' WHERE file_id=? AND status='open'")->execute([$fileId]);

        $v=$db->prepare('SELECT storage_id FROM document_file_versions WHERE file_id=? ORDER BY version DESC');
        $v->execute([$fileId]); $keys=[];
        foreach ($v->fetchAll(PDO::FETCH_COLUMN) as $key) if (is_string($key) && $key!=='') $keys[]=$key;
        $keys[]=(string)$file['storage_id'];
        $keys=array_values(array_unique($keys));

        $deletedCount=0;
        // Historical versions first; current file last, so a failure is less likely to destroy the active copy.
        foreach ($keys as $key) {
            $refs=$db->prepare("SELECT 1 FROM document_files WHERE storage_id=? AND id<>?
                UNION ALL SELECT 1 FROM document_file_versions WHERE storage_id=? AND file_id<>? LIMIT 1");
            $refs->execute([$key,$fileId,$key,$fileId]);
            if ($refs->fetchColumn()) continue; // Another record still references this blob.

            $remote=neal_docs_storage_request('DELETE','/files/'.$key);
            if ($remote['status']!==200) {
                throw new RuntimeException('حذف فیزیکی فایل از مخزن ناموفق بود (HTTP '.$remote['status'].'). رکورد پرتال حذف نشد.');
            }
            $result=json_decode((string)$remote['body'],true);
            if (!is_array($result) || empty($result['ok'])) {
                throw new RuntimeException('پاسخ سرویس مخزن برای حذف فایل معتبر نیست. رکورد پرتال حذف نشد.');
            }
            $deletedCount++;
        }

        $u=$db->prepare("UPDATE document_files SET is_deleted=1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND is_deleted=0");
        $u->execute([$fileId]);
        if ($u->rowCount()!==1) throw new RuntimeException('وضعیت فایل هم‌زمان تغییر کرده است؛ حذف در پرتال ثبت نشد.');
        $db->prepare('DELETE FROM document_permissions WHERE file_id=?')->execute([$fileId]);
        $db->prepare('DELETE FROM document_file_versions WHERE file_id=?')->execute([$fileId]);
        neal_docs_audit($db,$actor,'file.delete','file',$fileId,'success','physical blobs deleted='.$deletedCount.($auditDetails!==''?'; '.$auditDetails:''));
        $db->commit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        throw $e;
    }
}

function neal_docs_signed_storage_url(string $storageId,int $ttl=1800): string
{
    $c=neal_docs_config();$exp=time()+max(60,min($ttl,3600));$sig=hash_hmac('sha256',$storageId.':'.$exp,$c['storage_token']);return $c['storage_url'].'/files/'.rawurlencode($storageId).'?exp='.$exp.'&sig='.$sig;
}
function neal_docs_b64url_encode(string $s): string { return rtrim(strtr(base64_encode($s),'+/','-_'),'='); }
function neal_docs_jwt_encode(array $payload,string $secret): string
{
    $head=neal_docs_b64url_encode(json_encode(['typ'=>'JWT','alg'=>'HS256'],JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR));$body=neal_docs_b64url_encode(json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));$sig=neal_docs_b64url_encode(hash_hmac('sha256',$head.'.'.$body,$secret,true));return $head.'.'.$body.'.'.$sig;
}
function neal_docs_jwt_decode(string $jwt,string $secret): array
{
    $p=explode('.',$jwt);if(count($p)!==3)throw new RuntimeException('توکن callback نامعتبر است.');$expected=neal_docs_b64url_encode(hash_hmac('sha256',$p[0].'.'.$p[1],$secret,true));if(!hash_equals($expected,$p[2]))throw new RuntimeException('امضای callback معتبر نیست.');$raw=base64_decode(strtr($p[1],'-_','+/').str_repeat('=',(4-strlen($p[1])%4)%4),true);$data=is_string($raw)?json_decode($raw,true):null;if(!is_array($data))throw new RuntimeException('محتوای callback نامعتبر است.');return $data;
}
function neal_docs_h(string $value): string { return htmlspecialchars($value,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }


/** Create the quota table safely; quota_bytes=0 means unlimited until configured by an administrator. */
function neal_docs_quota_ensure(PDO $db): void
{
    $db->exec("CREATE TABLE IF NOT EXISTS document_user_quotas (
        user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
        quota_bytes INTEGER NOT NULL DEFAULT 0 CHECK(quota_bytes >= 0),
        updated_by_admin_id INTEGER NULL REFERENCES admins(id) ON DELETE SET NULL,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )");
}

/** Current logical usage: active file versions only, attributed to the uploader or personal-folder owner. */
function neal_docs_user_storage_usage(PDO $db, int $userId): int
{
    neal_docs_quota_ensure($db);
    $s=$db->prepare("SELECT COALESCE(SUM(df.file_size),0)
        FROM document_files df JOIN document_folders f ON f.id=df.folder_id
        WHERE df.is_deleted=0 AND f.is_deleted=0
          AND (df.created_by_user_id=? OR (f.folder_type='personal' AND f.owner_user_id=?))");
    $s->execute([$userId,$userId]);
    return max(0,(int)$s->fetchColumn());
}

function neal_docs_user_storage_quota(PDO $db, int $userId): int
{
    neal_docs_quota_ensure($db);
    $s=$db->prepare('SELECT quota_bytes FROM document_user_quotas WHERE user_id=?');
    $s->execute([$userId]);
    $v=$s->fetchColumn();
    return $v===false ? 0 : max(0,(int)$v);
}

function neal_docs_bytes_label(int $bytes): string
{
    if($bytes<1024) return number_format($bytes).' بایت';
    $units=['کیلوبایت','مگابایت','گیگابایت','ترابایت']; $v=(float)$bytes/1024; $i=0;
    while($v>=1024 && $i<count($units)-1){$v/=1024;$i++;}
    return number_format($v, $v>=100?0:($v>=10?1:2)).' '.$units[$i];
}

function neal_docs_user_storage_info(PDO $db, int $userId): array
{
    $used=neal_docs_user_storage_usage($db,$userId); $quota=neal_docs_user_storage_quota($db,$userId);
    $remaining=$quota>0?max(0,$quota-$used):null;
    $percent=$quota>0?min(100,(int)floor(($used/$quota)*100)):0;
    return ['used'=>$used,'quota'=>$quota,'remaining'=>$remaining,'percent'=>$percent,'over_quota'=>$quota>0 && $used>$quota];
}
